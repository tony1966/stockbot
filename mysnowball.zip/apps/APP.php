<?php
/*-----------------------------------------------------------------------------
Title        : 應用程式
Translator   : Tony Huang (tony1966@ms5.hinet.net)
Version      : v1.0.0
Prototype    : 2015-01-05
Last Updated : 2015-01-05
Usage        : 應用程式的主要功能寫在此檔中
Note         : 
請根據安裝檔內寫入 tabs 的各頁籤 $tab 與各作業 $op 撰寫功能
Ajax/DataTable 的 url 格式 : 
$url="apps/app.php?op=get_xxxx";
$url="apps/app.php?op=list_xxxx";
$url="apps/app.php?op=add_xxxx";
$url="apps/app.php?op=remove_xxxx";
$url="apps/app.php?op=update_xxxx";
-----------------------------------------------------------------------------*/
session_start(); //必須啟動才能用 session
header('Content-Type: text/html;charset=UTF-8');
require_once("../db.php");           //匯入資料庫設定檔 (必須)
require_once("../lib/mysql.php");    //匯入資料庫模組   (必須)
require_once("../lib/tools.php");    //匯入工具模組     (選項)
require_once("../lib/parse.php");    //匯入剖析模組     (選項)
require_once("../lib/file.php");     //匯入file模組     (選項)
require_once("../lib/http.php");     //匯入http模組     (選項)
$op=$_REQUEST["op"];   //功能
switch ($op) { 
  case "TAB1" : { //for ajax (範例)
    echo "Hello TAB1! The time is ".date("Y-m-d H:i:s");
    break;
    } 
  case "TAB2" : { //for ajax (範例)
    echo "Hello TAB2! The time is ".date("Y-m-d H:i:s");
    break;
    } 
  case "home" : { //必要模組 
?>
    <div id="APP_tabs" class="easyui-tabs" data-options="fit:'true'">
<?php
    $SQL="SELECT * FROM APP_tabs WHERE tab_level<=".$_SESSION["user_level"].
         " ORDER BY tab_order"; //"APP" 要改
    $RS=run_sql($SQL);  
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
?>
      <div class="tab" title="<?php echo $RS[$i]["tab_label"] ?>" data-options="href:'<?php echo $RS[$i]["tab_link"] ?>'">
      </div>
<?php
        } //for
      } //if
?>
    </div>
<?php
    break;
    }
  default : { 
    echo "The time is ".date("Y-m-d H:i:s");
    } //default
  } //switch
?>