<?php
/*-----------------------------------------------------------------------------
Title        : 應用程式安裝檔
Author       : Tony Huang (tony1966@ms5.hinet.net)
Version      : v1.0.0
Prototype    : 2015-01-07
Last Updated : 2015-01-09
Usage        : 安裝應用程式所使用之資料表, 填入初始值
Note         : 
-----------------------------------------------------------------------------*/
/*=== 系統固定的部分 (勿修改) ===*/
session_start(); //啟動 session 功能
header('Content-type: text/html; charset=utf-8');
//檢查是否已登入, 否則回登入畫面
if (!isset($_SESSION["user_account"])) {header("Location: index.php");}
//設定台北時間
date_default_timezone_set("Asia/Taipei");
//匯入資料庫設定與函式庫
require_once("../db.php");           //匯入資料庫設定檔 (必須)
require_once("../lib/mysql.php");    //匯入資料庫模組   (必須)
//變數設定
$success=FALSE;   //整體成功或失敗旗標
$error=Array();   //儲存錯誤訊息用
$tabs=Array();    //儲存頁籤用
$tables=Array();  //儲存表單用

/*=== 應用程式頁籤範本 (只改 APP 名稱 & 複製修改) ===*/
//建立 APP_tabs 資料表 (必須)
$tables[]="APP_tabs";  //"APP" 要改
$data_array["id"]="smallint(6) NOT NULL AUTO_INCREMENT PRIMARY KEY";
$data_array["tab_name"]="varchar(255)";
$data_array["tab_label"]="varchar(255)";
$data_array["tab_link"]="varchar(255)";
$data_array["tab_level"]="tinyint(4)"; //1 (使用者) ~9 (管理者)
$data_array["tab_tip"]="varchar(255)";
$data_array["tab_order"]="tinyint(4)";
$result=create_table("APP_tabs",$data_array);    //"APP" 要改
if ($result===TRUE) {$success=TRUE;}
else {$error[]="建立資料表 APP_tabs ... 失敗!";} //"APP" 要改
$data_array=NULL;

//插入 APP_tabs (範本)
$tabs[]="TAB1";  //顯示頁籤標題用 
$data_array["tab_name"]="TAB1";
$data_array["tab_label"]="TAB1";
$data_array["tab_link"]="apps/APP.php?op=TAB1";  //"APP" 要改
$data_array["tab_level"]=1;
$data_array["tab_tip"]="TAB1";
$data_array["tab_order"]=1;
$result=insert("APP_tabs", $data_array);         //"APP" 要改
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 APP_tabs ... 失敗!";}  //"APP" 要改
$data_array=NULL;

//插入 APP_tabs (範本)
$tabs[]="TAB2";  //顯示頁籤標題用 
$data_array["tab_name"]="TAB2";
$data_array["tab_label"]="TAB2";
$data_array["tab_link"]="apps/APP.php?op=TAB2";  //"APP" 要改
$data_array["tab_level"]=1;
$data_array["tab_tip"]="TAB2";
$data_array["tab_order"]=1;
$result=insert("APP_tabs", $data_array);         //"APP" 要改
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 APP_tabs ... 失敗!";} //"APP" 要改
$data_array=NULL;

/*--- 新增其他頁籤請複製上面的 TAB1/TAB2 範本於此改寫 ---*/

/*=== 安裝其他資料表範本 (請複製修改, 完成後刪除範本) ===*/
//建立 APP_table1 資料表 (範本)
$tables[]="APP_table1"; //刪除 APP 時用到 (必須)
$data_array["id"]="int(10) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY";
$data_array["field1"]="varchar(255)"; 
$data_array["field2"]="char(1)"; 
$data_array["field3"]="text";         
$data_array["field4"]="date";  
$data_array["field5"]="datetime";  
$data_array["field6"]="smallint(6) unsigned NOT NULL DEFAULT '0'";   
$data_array["field7"]="tinyint(3) unsigned NOT NULL DEFAULT '10'";
$data_array["field8"]="int(10) unsigned";            
$data_array["field9"]="bigint(20) unsigned";                          
$data_array["field10"]="float unsigned";   
$result=create_table("APP_table1",$data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="建立資料表 APP_table1 ... 失敗!";} //"APP_table1" 要改
$data_array=NULL;

//插入 APP_table1 (AUTO_INCREMENT 不用填) (範本)
$SQL="INSERT INTO `app_table1` (".
     "`field1`,".
     "`field2`,".
     "`field3`,".
     "`field4`,".
     "`field5`,".
     "`field6`,".
     "`field7`,".
     "`field8`,".
     "`field9`,".
     "`field10`".
     "`) VALUES (".
     "'',".
     "'',".
     "'',".
     "'',".
     "'',".
     ",".
     ",".
     ",".
     ",".
     "".
     ")";
$result=run_sql($SQL);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 APP_table1 ... 失敗!";} //"APP_table1" 要改
$data_array=NULL;

/*--- 新增其他資料表請複製上面的 APP_table1 範本於此改寫 ---*/

/*=== 更新系統 sys_apps 資料表 (只改 APP 名稱)===*/
//更新系統 sys_apps 資料表的 app_name='程式名稱' 欄位
$data_array["installed"]="Y";                  //已安裝 "Y"/"N"
$data_array["show_tabs"]="Y";                  //顯示頁籤 "Y"/"N"
$data_array["tab_names"]=join(",",$tabs);      //儲存 tabs 以便產生頁籤   
$data_array["table_names"]=join(",",$tables);  //儲存 tables 以便刪除時清理
$data_array["remark"]="OK";                    //安裝結果
$result=update("sys_apps", $data_array, "app_name", "APP"); //"APP" 要改
if ($result===TRUE) {$success=TRUE;}
else {$error[]="更新資料表 sys_apps ... 失敗!";} 
$data_array=NULL;

//在 sys_header_links 插入應用程式入口超連結 
$data_array["title"]="APP";             //"APP" 要改              
$data_array["url"]="javascript:APP()";  //"APP" 要改                  
$data_array["target"]="_self"; 
$data_array["sequence"]=1; 
$data_array["hint"]="APP";              //"APP" 要改  
$result=insert("sys_header_links", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 sys_header_links ... 失敗!";} 
$data_array=NULL;

/*====== 輸出 JSON 格式之安裝結果 (不用改) ======*/
$arr["result"]=$success ? "success" : "failure";
$arr["error"]=join("<br>",$error);
echo json_encode($arr);
?>