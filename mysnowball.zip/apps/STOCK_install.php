<?php
/*-----------------------------------------------------------------------------
Title        : 台股分析系統安裝檔
Author       : Tony Huang (tony1966@ms5.hinet.net)
Version      : v1.0.0
Prototype    : 2015-01-27
Last Updated : 2015-01-27
Usage        : 安裝台股分析系統所使用之資料表, 填入初始值
Note         : 欄位備註前有 * 者為處理過的非原始資料
-----------------------------------------------------------------------------*/
/*=== 系統固定的部分 (勿修改) ===*/
session_start(); //啟動 session 功能
header('Content-type: text/html; charset=utf-8');
//檢查是否已登入, 否則回登入畫面
if (!isset($_SESSION["user_account"])) {header("Location: index.php");}
//設定台北時間
date_default_timezone_set("Asia/Taipei");
//匯入資料庫設定與函式庫
require_once("../db.php");           //匯入資料庫設定檔 (必須)
require_once("../lib/mysql.php");    //匯入資料庫模組   (必須)
//變數設定
$success=FALSE;   //整體成功或失敗旗標
$error=Array();   //儲存錯誤訊息用
$tabs=Array();    //儲存頁籤用
$tables=Array();  //儲存表單用

//* 建立 tabs 資料表 (必須)
$tables[]="tabs";  
$data_array["id"]="smallint(6) NOT NULL AUTO_INCREMENT PRIMARY KEY";
$data_array["tab_name"]="varchar(255)";
$data_array["tab_label"]="varchar(255)";
$data_array["tab_link"]="varchar(255)";
$data_array["tab_level"]="tinyint(4)"; //1 (使用者) ~9 (管理者)
$data_array["tab_tip"]="varchar(255)";
$data_array["tab_order"]="tinyint(4)";
$result=create_table("tabs",$data_array);  
if ($result===TRUE) {$success=TRUE;}
else {$error[]="建立資料表 tabs ... 失敗!";} 
$data_array=NULL;
//插入 tabs 資料表
$tabs[]="snowball";
$data_array["tab_name"]="snowball";
$data_array["tab_label"]="雪球股";
$data_array["tab_link"]="apps/STOCK.php?op=snowball";
$data_array["tab_level"]=1;
$data_array["tab_tip"]="雪球股";
$data_array["tab_order"]=1;
$result=insert("tabs", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 tabs ... 失敗!";}  
$data_array=NULL;
//插入 tabs 資料表
$tabs[]="snowball";
$data_array["tab_name"]="growth";
$data_array["tab_label"]="成長股";
$data_array["tab_link"]="apps/STOCK.php?op=growth";
$data_array["tab_level"]=1;
$data_array["tab_tip"]="成長股";
$data_array["tab_order"]=1;
$result=insert("tabs", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 tabs ... 失敗!";}  
$data_array=NULL;//插入 tabs 資料表
$tabs[]="stocks";
$data_array["tab_name"]="stocks";
$data_array["tab_label"]="個股";
$data_array["tab_link"]="apps/STOCK.php?op=stocks";
$data_array["tab_level"]=1;
$data_array["tab_tip"]="個股";
$data_array["tab_order"]=1;
$result=insert("tabs", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 tabs ... 失敗!";}  
$data_array=NULL;
//插入 tabs 資料表
$tabs[]="z0000";
$data_array["tab_name"]="z0000";
$data_array["tab_label"]="大盤";
$data_array["tab_link"]="apps/STOCK.php?op=z0000";
$data_array["tab_level"]=1;
$data_array["tab_tip"]="加權指數";
$data_array["tab_order"]=2;
$result=insert("tabs", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 tabs ... 失敗!";}  
$data_array=NULL;
//插入 tabs 資料表
$tabs[]="z0050";
$data_array["tab_name"]="z0050";
$data_array["tab_label"]="台灣 50";
$data_array["tab_link"]="apps/STOCK.php?op=z0050";
$data_array["tab_level"]=1;
$data_array["tab_tip"]="台灣 50";
$data_array["tab_order"]=3;
$result=insert("tabs", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 tabs ... 失敗!";}  
$data_array=NULL;
//插入 tabs 資料表
$tabs[]="international";
$data_array["tab_name"]="international";
$data_array["tab_label"]="國際股市";
$data_array["tab_link"]="apps/STOCK.php?op=international";
$data_array["tab_level"]=1;
$data_array["tab_tip"]="國際股市";
$data_array["tab_order"]=4;
$result=insert("tabs", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 tabs ... 失敗!";}  
$data_array=NULL;
//插入 tabs 資料表
$tabs[]="inventory";
$data_array["tab_name"]="inventory";
$data_array["tab_label"]="庫存股";
$data_array["tab_link"]="apps/STOCK.php?op=inventory";
$data_array["tab_level"]=1;
$data_array["tab_tip"]="庫存股";
$data_array["tab_order"]=5;
$result=insert("tabs", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 tabs ... 失敗!";}  
$data_array=NULL;
//插入 tabs 資料表
$tabs[]="tracking";
$data_array["tab_name"]="tracking";
$data_array["tab_label"]="個股追蹤";
$data_array["tab_link"]="apps/STOCK.php?op=tracking";
$data_array["tab_level"]=1;
$data_array["tab_tip"]="個股追蹤";
$data_array["tab_order"]=6;
$result=insert("tabs", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 tabs ... 失敗!";}  
$data_array=NULL;
//插入 tabs 資料表
$tabs[]="report";
$data_array["tab_name"]="report";
$data_array["tab_label"]="收盤報告";
$data_array["tab_link"]="apps/STOCK.php?op=report";
$data_array["tab_level"]=1;
$data_array["tab_tip"]="收盤報告";
$data_array["tab_order"]=7;
$result=insert("tabs", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 tabs ... 失敗!";}  
$data_array=NULL;
//插入 tabs 資料表
$tabs[]="compound_annuity";
$data_array["tab_name"]="compound_annuity";
$data_array["tab_label"]="複利表";
$data_array["tab_link"]="apps/STOCK.php?op=compound_annuity";
$data_array["tab_level"]=1;
$data_array["tab_tip"]="複利表";
$data_array["tab_order"]=8;
$result=insert("tabs", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 tabs ... 失敗!";}  
$data_array=NULL;//插入 tabs 資料表
$tabs[]="knowledge";
$data_array["tab_name"]="knowledge";
$data_array["tab_label"]="知識庫";
$data_array["tab_link"]="apps/STOCK.php?op=knowledge";
$data_array["tab_level"]=1;
$data_array["tab_tip"]="知識庫";
$data_array["tab_order"]=9;
$result=insert("tabs", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 tabs ... 失敗!";}  
$data_array=NULL;
//插入 tabs 資料表
$tabs[]="cron_log";
$data_array["tab_name"]="cron_log";
$data_array["tab_label"]="Cron";
$data_array["tab_link"]="apps/STOCK.php?op=cron_log";
$data_array["tab_level"]=10;
$data_array["tab_tip"]="Cron";
$data_array["tab_order"]=96;
$result=insert("tabs", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 tabs ... 失敗!";}  
$data_array=NULL;
//插入 tabs 資料表
$tabs[]="tabs";
$data_array["tab_name"]="tabs_admin";
$data_array["tab_label"]="頁籤管理";
$data_array["tab_link"]="apps/STOCK.php?op=tabs";
$data_array["tab_level"]=9;
$data_array["tab_tip"]="頁籤管理";
$data_array["tab_order"]=97;
$result=insert("tabs", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 tabs ... 失敗!";}  
$data_array=NULL;
//插入 tabs 資料表
$tabs[]="stock_settings";
$data_array["tab_name"]="stock_settings";
$data_array["tab_label"]="系統設定";
$data_array["tab_link"]="apps/STOCK.php?op=stock_settings";
$data_array["tab_level"]=9;
$data_array["tab_tip"]="設定";
$data_array["tab_order"]=97;
$result=insert("tabs", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 tabs ... 失敗!";}  
$data_array=NULL;

//* 建立 cron_log 資料表
$tables[]="cron_log";
$data_array["id"]="int(10) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY";  
$data_array["date_time"]="datetime";         //執行日期時間
$data_array["program_name"]="varchar(255)";  //cron 程式名稱
$data_array["cron_type"]="varchar(255)";     //cron 類型
$data_array["elapsed"]="float";              //執行所耗時間 (秒)
$data_array["remark"]="varchar(255)";        //備註
$result=create_table("cron_log",$data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="建立資料表 cron_log ... 失敗!";} 
$data_array=NULL;

//* 建立 report 資料表
$tables[]="report";
$data_array["id"]="int(10) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY";  
$data_array["date_time"]="datetime";         //日期時間
$data_array["summary"]="text";               //報告內容
$data_array["email_content"]="text";         //郵寄內容
$data_array["sms_content"]="text";           //SMS 內容
$data_array["emailed"]="char(1)";            //已郵寄
$result=create_table("report",$data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="建立資料表 report ... 失敗!";} 
$data_array=NULL;

//* 建立 stocks_list 資料表
$tables[]="stocks_list";
$data_array["stock_id"]="varchar(255) PRIMARY KEY"; //股號
$data_array["stock_name"]="varchar(255)";           //股名
$data_array["close"]="float";                       //收盤價
$data_array["delta"]="float";                       //漲跌差價
$data_array["delta_percent"]="float";               //漲跌幅
$data_array["PV"]="text";                           //峰谷值序列
$data_array["volumn"]="bigint(20)";                 //成交量 (元)
$data_array["PER1"]="tinyint(4)";                   //本益比
$data_array["turnover"]="float unsigned";           //成交量週轉率
$data_array["category"]="varchar(255)";             //類股
//以下存放自 2330.tw 擷取之股利政策 (fetch_2330.tw_dividend)
$data_array["D1"]="float";                          //前1年股息
$data_array["D2"]="float";                          //前2年股息
$data_array["D3"]="float";                          //前3年股息
$data_array["D4"]="float";                          //前4年股息
$data_array["D5"]="float";                          //前5年股息
$data_array["CDR1"]="float";                        //前1年現金配息率
$data_array["CDR2"]="float";                        //前2年現金配息率
$data_array["CDR3"]="float";                        //前3年現金配息率
$data_array["CDR4"]="float";                        //前4年現金配息率
$data_array["CDR5"]="float";                        //前5年現金配息率
$data_array["CDR_avg"]="float";                     //近5年平均現金配息率
$data_array["CDR_over80"]="char(1)";                //近5年現金配息率均>80%
$data_array["PDR1"]="float";                        //前1年股利發放率
$data_array["PDR2"]="float";                        //前2年股利發放率
$data_array["PDR3"]="float";                        //前3年股利發放率
$data_array["PDR4"]="float";                        //前4年股利發放率
$data_array["PDR5"]="float";                        //前5年股利發放率
$data_array["PDR_avg"]="float";                     //近5年平均股利發放率
$data_array["dividend_avg"]="float";                //*五年平均股息
$data_array["dividend_std"]="float";                //*五年平均股息標準差
$data_array["CV"]="float";                          //*五年平均股息變異係數
$data_array["cheap_price"]="float";                 //*便宜價
$data_array["reason_price"]="float";                //*合理價
$data_array["expensive_price"]="float";             //*昂貴價
$data_array["dividend_update"]="datetime";          //股利政策更新時間
//以下存放自 2330.tw 擷取之個股基本資料 (fetch_2330.tw_basic)
$data_array["capital"]="float";                     //股本 (億)
$data_array["yield"]="float";                       //殖利率
$data_array["PER"]="float";                         //本益比
$data_array["PBR"]="float";                         //股價淨值比
$data_array["market_value"]="float";                //*市值(億)=股本*收盤/10
$data_array["listed_years"]="float";                //*上市年數 (四捨五入)
$data_array["basic_update"]="datetime";             //基本資料更新時間
//以下存放自 2330.tw 擷取之損益表季報資料 (fetch_2330.tw_profit)
$data_array["IC_8QS"]="varchar(255)";               //近8季營收(計算IIR用)
$data_array["income_value_ratio"]="float";          //*營收市值比 (%)
$data_array["EPS_YOY_1Q"]="int(10)";                //*前1季 EPS 年增率 (%)
$data_array["EPS_YOY_2Q"]="int(10)";                //*前2季 EPS 年增率 (%)
$data_array["EPS_YOY_3Q"]="int(10)";                //*前3季 EPS 年增率 (%)
$data_array["EPS_YOY_4Q"]="int(10)";                //*前4季 EPS 年增率 (%)
$data_array["EPS_YOY_last2Q_plus"]="char(1)";       //*近2季 EPS 年增率為正Y/N
$data_array["OPM_8QS"]="varchar(255)";              //*近8季營益率[0],~[7]
$data_array["OPM_avg"]="float";                     //*近8季營益率平均值
$data_array["OPM_CV"]="int(10)";                    //*近8季營益率變異係數CV
$data_array["OPM_plus"]="char(1)";                  //*近3季營益率為正
$data_array["OPM_over20"]="char(1)";                //*近3季營益率>20%
$data_array["OPM_increase"]="char(1)";              //*近3季營益率遞增
$data_array["OPM_decrease"]="char(1)";              //*近3季營益率遞減
$data_array["OPM_turnplus"]="char(1)";              //*近3季營益率負轉正
$data_array["OPM_turnminus"]="char(1)";             //*近3季營益率正轉負
$data_array["OPM_down30p"]="char(1)";               //*近1季營益率下降3成以上
$data_array["ATNI_4Y_plus"]="char(1)";              //*近4年稅後淨利為正
$data_array["profit_update"]="datetime";            //損益表更新時間
//以下存放自 2330.tw 擷取之營業收入月報資料 (fetch_2330.tw_income)
$data_array["income_YOY_1M"]="float";               //前1月月營收年增率(%)
$data_array["income_YOY_2M"]="float";               //前2月月營收年增率(%)
$data_array["income_YOY_3M"]="float";               //前3月月營收年增率(%)
$data_array["income_YOY_plus"]="char(1)";           //近3月月營收年增率為正
$data_array["income_YOY_over20"]="char(1)";         //近3月月營收年增率>20%
$data_array["income_YOY_increase"]="char(1)";       //近3月月營收年增率遞增
$data_array["income_YOY_decrease"]="char(1)";       //近3月月營收年增率遞減
$data_array["income_YOY_turnplus"]="char(1)";       //近3月月營收年增率負轉正
$data_array["income_YOY_turnminus"]="char(1)";      //近3月月營收年增率正轉負
$data_array["income_update"]="datetime";            //月營收更新時間
//以下存放自 2330.tw 擷取之資產負債表季報資料 (fetch_2330.tw_balance)
$data_array["IV_8QS"]="varchar(255)";               //近8季存貨(計算IIR用)
$data_array["equity"]="float";                      //最近一季淨值 (億)
$data_array["value_equity_ratio"]="float";          //*市值淨值比(%)
$data_array["balance_update"]="datetime";           //資產負債表更新時間
//以下存放自 2330.tw 擷取之現金流量表年報資料 (fetch_2330.tw_cash)
$data_array["freecash_1Y"]="float";                 //*近1年累積自由現金 (億)
$data_array["freecash_3Y"]="float";                 //*近3年累積自由現金 (億)
$data_array["freecash_5Y"]="float";                 //*近5年累積自由現金 (億)
$data_array["freecash_8Y"]="float";                 //*近8年累積自由現金 (億)
$data_array["opcash_netincome_ratio_1Y"]="int(6)";  //*近1年營運現金占稅後淨利
$data_array["opcash_netincome_ratio_3Y"]="int(6)";  //*近3年營運現金占稅後淨利
$data_array["opcash_netincome_ratio_5Y"]="int(6)";  //*近5年營運現金占稅後淨利
$data_array["opcash_netincome_ratio_8Y"]="int(6)";  //*近8年營運現金占稅後淨利
$data_array["freecash_netincome_ratio_1Y"]="int(6)"; //*近1年自由現金占稅後淨利
$data_array["freecash_netincome_ratio_3Y"]="int(6)"; //*近3年自由現金占稅後淨利
$data_array["freecash_netincome_ratio_5Y"]="int(6)"; //*近5年自由現金占稅後淨利
$data_array["freecash_netincome_ratio_8Y"]="int(6)"; //*近8年自由現金占稅後淨利
$data_array["freecash_capital_ratio_1Y"]="float";   //*近1年自由現金占股本
$data_array["freecash_capital_ratio_3Y"]="float";   //*近3年自由現金占股本
$data_array["freecash_capital_ratio_5Y"]="float";   //*近5年自由現金占股本
$data_array["freecash_capital_ratio_8Y"]="float";   //*近8年自由現金占股本
$data_array["freecash_plus_years"]="tinyint(2)";    //*近8年自由現金為正年數>5
$data_array["cashflow_type_8Y"]="varchar(255)";     //*近8年現金流量類型字串
$data_array["cashflow_type_8A"]="char(1)";          //*近8年現金流量8A類型:Y/N
$data_array["cashflow_type_AB"]="char(1)";          //*近8年現金流量A/B類型:Y/N
$data_array["cashflow_type_358"]="varchar(255)";    //*短中長現金流量類型字串
$data_array["cashflow_update"]="datetime";          //現金流量表更新時間
//以下存放自 2330.tw 擷取之財務分析表年報資料 (fetch_2330.tw_analysis)
$data_array["IT_3Q_decrease"]="char(1)";            //*近3季存貨周轉率下降
$data_array["ART_3Q_decrease"]="char(1)";           //*近3季應收帳款週轉率下降
$data_array["ART_CV"]="float";                      //*近10季應收帳款週轉率CV
$data_array["IIR"]="varchar(255)";                  //*近8季存貨營收比字串
$data_array["IIR_1Q"]="float";                      //*近1季存貨營收比
$data_array["IIR_3Q_decrease"]="char(1)";           //*近3季存貨營收比遞降
$data_array["IIR_3Q_increase"]="char(1)";           //*近3季存貨營收比遞增
$data_array["IIR_avg"]="float";                     //*近8季存貨營收比平均
$data_array["IIR_CV"]="float";                      //*近8季存貨營收比變異係數
$data_array["ROE_5Y_avg"]="float";                  //*近5年平均 ROE
$data_array["ROE_8Y_avg"]="float";                  //*近8年平均 ROE
$data_array["ROE_5Y_CV"]="float";                   //*近5年平均ROE變異係數
$data_array["ROE_8Y_CV"]="float";                   //*近8年平均ROE變異係數
$data_array["ROE_1Y_GT15"]="char(1)";               //*近1年ROE > 15 (Y/N)
$data_array["ROE_5Y_GT15"]="char(1)";               //*近5年ROE > 15 (Y/N)
$data_array["GVI"]="float";                         //*成長價值指標
$data_array["analysis_update"]="datetime";          //財務分析表表更新時間
//其他
$data_array["remark"]="varchar(255)";               //備註
$data_array["status"]="char(1)";                    //N:新股 X:下市 O:舊股
$result=create_table("stocks_list",$data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="建立資料表 report ... 失敗!";} 
$data_array=NULL;

//* 建立 z0000 資料表 (大盤:加權指數)
$tables[]="z0000";
$data_array["trade_date"]="date";                   //交易日
$data_array["close"]="float unsigned";              //收盤指數
$data_array["volumn"]="bigint(20) unsigned";        //成交量 (億) 
$data_array["delta"]="float";                       //漲跌 (元) 
$data_array["delta_percent"]="float";               //漲跌百分比 
$data_array["rise"]="int(10) unsigned";             //漲家數 
$data_array["fall"]="int(10) unsigned";             //跌家數 
$data_array["even"]="int(10) unsigned";             //平家數 
$data_array["rise_fall_ratio"]="float";             //漲跌家數比 
$result=create_table("z0000",$data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="建立資料表 z0000 ... 失敗!";} 
$data_array=NULL;

//* 建立 z0050 資料表 (台灣50)
$tables[]="z0050";
$data_array["id"]="smallint(6) NOT NULL AUTO_INCREMENT PRIMARY KEY";
$data_array["trade_date"]="date";                   //交易日
$data_array["close"]="float unsigned";              //收盤價
$data_array["high"]="float unsigned";               //最高價
$data_array["low"]="float unsigned";                //最低價
$data_array["volumn"]="bigint(20) unsigned";        //成交量 (張)
$data_array["high9d"]="float unsigned";             //近9日最高價
$data_array["low9d"]="float unsigned";              //近9日最低價
$data_array["RSV"]="float unsigned";                //未成熟隨機震盪值
$data_array["K9"]="float unsigned";                 //9日K值
$data_array["D9"]="float unsigned";                 //9日D值
$data_array["OBV"]="bigint(20)";                    //累積籌碼OBV
$result=create_table("z0050",$data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="建立資料表 z0050 ... 失敗!";} 
$data_array=NULL;

//* 建立 z0051 資料表 (台灣中型100)
$tables[]="z0051";
$data_array["id"]="smallint(6) NOT NULL AUTO_INCREMENT PRIMARY KEY";
$data_array["trade_date"]="date";                   //交易日
$data_array["close"]="float unsigned";              //收盤價
$data_array["high"]="float unsigned";               //最高價
$data_array["low"]="float unsigned";                //最低價
$data_array["volumn"]="bigint(20) unsigned";        //成交量 (張)
$data_array["high9d"]="float unsigned";             //近9日最高價
$data_array["low9d"]="float unsigned";              //近9日最低價
$data_array["RSV"]="float unsigned";                //未成熟隨機震盪值
$data_array["K9"]="float unsigned";                 //9日K值
$data_array["D9"]="float unsigned";                 //9日D值
$data_array["OBV"]="bigint(20)";                    //累積籌碼OBV
$result=create_table("z0051",$data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="建立資料表 z0051 ... 失敗!";} 
$data_array=NULL;

//* 建立 z0056 資料表 (高股息)
$tables[]="z0056";
$data_array["id"]="smallint(6) NOT NULL AUTO_INCREMENT PRIMARY KEY";
$data_array["trade_date"]="date";                   //交易日
$data_array["close"]="float unsigned";              //收盤價
$data_array["high"]="float unsigned";               //最高價
$data_array["low"]="float unsigned";                //最低價
$data_array["volumn"]="bigint(20) unsigned";        //成交量 (張)
$data_array["high9d"]="float unsigned";             //近9日最高價
$data_array["low9d"]="float unsigned";              //近9日最低價
$data_array["RSV"]="float unsigned";                //未成熟隨機震盪值
$data_array["K9"]="float unsigned";                 //9日K值
$data_array["D9"]="float unsigned";                 //9日D值
$data_array["OBV"]="bigint(20)";                    //累積籌碼OBV
$result=create_table("z0056",$data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="建立資料表 z0056 ... 失敗!";} 
$data_array=NULL;

//* 建立 category 資料表
$tables[]="category";
$data_array["category"]="varchar(255)";      //類股名稱
$result=create_table("category",$data_array);
if ($result===FALSE) {$success=FALSE;$error[]="category";}
$data_array=NULL;
//插入 category
$SQL="INSERT INTO `category` (`category`) VALUES ('指數'),('水泥'),".
     "('食品'),('塑膠'),('紡織'),('電機'),('電器'),('化生'),('化學'),".
     "('生技'),('玻璃'),('紙類'),('鋼鐵'),('橡膠'),('汽車'),('電子'),".
     "('半導'),('電腦'),('光電'),('通信'),('電零'),('通路'),('資服'),".
     "('他電'),('營建'),('航運'),('觀光'),('金融'),('貿易'),('油電'),".
     "('憑證'),('綜合'),('其他'),('全額')";
$result=run_sql($SQL);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="建立資料表 category ... 失敗!";} 
$data_array=NULL;

//* 建立 stock_settings 資料表
$tables[]="stock_settings";
//測試模式:Y/N
$data_array["test_mode"]="char(1)"; 
//測試日期:例 2013-06-21
$data_array["test_date"]="date";    
//最近擷取之交易日期 (fetch_twse_daily_close.php 會更新此欄位)
$data_array["twse_trade_date"]="varchar(255)"; 
//2330_tw 股息下載指標
$data_array["dividend_pointer_2330"]="smallint(6) unsigned NOT NULL DEFAULT '0'"; 
//2330_tw 股息下載筆數
$data_array["dividend_offset_2330"]="tinyint(3) unsigned NOT NULL DEFAULT '10'";  
//2330_tw 基本資料下載指標
$data_array["basic_pointer_2330"]="smallint(6) unsigned NOT NULL DEFAULT '0'";
//2330_tw 基本資料下載筆數
$data_array["basic_offset_2330"]="tinyint(4) unsigned NOT NULL DEFAULT '10'";
//2330_tw 損益表下載指標
$data_array["profit_pointer_2330"]="smallint(6) unsigned NOT NULL DEFAULT '0'";
//2330_tw 損益表下載筆數
$data_array["profit_offset_2330"]="tinyint(4) unsigned NOT NULL DEFAULT '10'";
//2330_tw 月營收下載指標
$data_array["income_pointer_2330"]="smallint(6) unsigned NOT NULL DEFAULT '0'";
//2330_tw 月營收下載筆數
$data_array["income_offset_2330"]="tinyint(4) unsigned NOT NULL DEFAULT '10'";
//2330_tw 資產負債表下載指標
$data_array["balance_pointer_2330"]="smallint(6) unsigned NOT NULL DEFAULT '0'";
//2330_tw 資產負債表下載筆數
$data_array["balance_offset_2330"]="tinyint(4) unsigned NOT NULL DEFAULT '10'";
//2330_tw 現金流量表下載指標
$data_array["cash_pointer_2330"]="smallint(6) unsigned NOT NULL DEFAULT '0'";
//2330_tw 現金流量表下載筆數
$data_array["cash_offset_2330"]="tinyint(4) unsigned NOT NULL DEFAULT '10'";
//2330_tw 財務分析表下載指標
$data_array["analysis_pointer_2330"]="smallint(6) unsigned NOT NULL DEFAULT '0'";
//2330_tw 財務分析表下載筆數
$data_array["analysis_offset_2330"]="tinyint(4) unsigned NOT NULL DEFAULT '10'";
//Yahoo 個股查詢 URL (fetch_yahoo_dividend.php 使用)
$data_array["yahoo"]="varchar(256)";  
//財報狗個股查詢 URL (fetch_statementdog.php 使用)
$data_array["statementdog"]="varchar(256)";  
//台股觀察站個股查詢 URL (fetch_2330.tw_basic.php 使用)
$data_array["www2333tw"]="varchar(256)";
//玉山證券個股查詢 URL (fetch_esun_global.php 使用)
$data_array["esun"]="varchar(256)"; 
//公開資訊觀測站 URL 
$data_array["twse"]="varchar(256)"; 
$result=create_table("stock_settings",$data_array);
if ($result===FALSE) {$success=FALSE;$error[]="stock_settings(create)";}
$data_array=NULL;
//插入 stock_settings
$SQL="INSERT INTO `stock_settings` (".
     "`test_mode`,".
     "`test_date`,".
     "`twse_trade_date`,".
     "`dividend_pointer_2330`,".
     "`dividend_offset_2330`,".
     "`basic_pointer_2330`,".
     "`basic_offset_2330`,".
     "`profit_pointer_2330`,".
     "`profit_offset_2330`,".
     "`income_pointer_2330`,".
     "`income_offset_2330`,".
     "`balance_pointer_2330`,".
     "`balance_offset_2330`,".
     "`cash_pointer_2330`,".
     "`cash_offset_2330`,".
     "`yahoo`,".
     "`statementdog`,".
     "`www2333tw`,".
     "`esun`".
     ") VALUES (".
     "'N',".
     "'',".
     "'',".
     "0,".
     "10,".
     "0,".
     "10,".
     "0,".
     "10,".
     "0,".
     "10,".
     "0,".
     "10,".
     "0,".
     "10,".
     "'http://tw.stock.yahoo.com/q/q?s=',". "'http://statementdog.com/stock-analysis.php?stockid=',". 
     "'http://2330.tw/Stock_Quote.aspx?id=',".
     "'http://www.esunsec.com.tw/stock/b-1.asp?stock_no=',";
     "'http://mops.twse.com.tw/mops/web/index')";
$result=run_sql($SQL);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="建立資料表 stock_settings ... 失敗!";} 
$data_array=NULL;

/*=== 更新系統 sys_apps 資料表 (只改 APP 名稱)===*/
//更新系統 sys_apps 資料表的 app_name='程式名稱' 欄位
$data_array["installed"]="Y";                  //已安裝 "Y"/"N"
$data_array["show_tabs"]="Y";                  //顯示頁籤 "Y"/"N"
$data_array["tab_names"]=join(",",$tabs);      //儲存 tabs 以便產生頁籤   
$data_array["table_names"]=join(",",$tables);  //儲存 tables 以便刪除時清理
$data_array["remark"]="OK";                    //安裝結果
$result=update("sys_apps", $data_array, "app_name", "STOCK"); 
if ($result===TRUE) {$success=TRUE;}
else {$error[]="更新資料表 sys_apps ... 失敗!";} 
$data_array=NULL;

//在 sys_header_links 插入應用程式入口超連結 
$data_array["title"]="STOCK";                             
$data_array["url"]="javascript:STOCK()";                      
$data_array["target"]="_self"; 
$data_array["sequence"]=1; 
$data_array["hint"]="STOCK";                  
$result=insert("sys_header_links", $data_array);
if ($result===TRUE) {$success=TRUE;}
else {$error[]="插入資料表 sys_header_links ... 失敗!";} 
$data_array=NULL;

//插入 sys_nav_blocks 之連結
$data_array["title"]="STOCK"; 
$data_array["sequence"]=2;    
$data_array["display"]="Y";    
$data_array["app"]="STOCK";    
$result=insert("sys_nav_blocks", $data_array);
$data_array=NULL;

//插入 sys_nav_blocks 之連結
$data_array["title"]="BROKER"; 
$data_array["sequence"]=3;    
$data_array["display"]="Y";    
$data_array["app"]="STOCK";    
$result=insert("sys_nav_blocks", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="台股觀測站";               
$data_array["url"]="https://2330.tw/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=0; 
$data_array["block_id"]=2; 
$data_array["hint"]="台股觀測站";    
$data_array["app"]="STOCK";    
$result=insert("sys_nav_links", $data_array);
$data_array=NULL; 

//插入 sys_nav_links 之連結
$data_array["title"]="Yahoo 股市";               
$data_array["url"]="https://tw.finance.yahoo.com/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=1; 
$data_array["block_id"]=2; 
$data_array["hint"]="Yahoo 股市";    
$data_array["app"]="STOCK";    
$result=insert("sys_nav_links", $data_array);
$data_array=NULL; 

//插入 sys_nav_links 之連結
$data_array["title"]="財報狗";               
$data_array["url"]="http://statementdog.com/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=2; 
$data_array["block_id"]=2; 
$data_array["hint"]="財報狗";      
$data_array["app"]="STOCK";  
$result=insert("sys_nav_links", $data_array);
$data_array=NULL; 

//插入 sys_nav_links 之連結
$data_array["title"]="公開資訊觀測站";               
$data_array["url"]="http://mops.twse.com.tw/mops/web/index";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=3; 
$data_array["block_id"]=2; 
$data_array["hint"]="公開資訊觀測站";  
$data_array["app"]="STOCK";      
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="蕃薯藤財經";               
$data_array["url"]="http://yamstock.megatime.com.tw/asp/stockinfo/".
                   "GetReport.asp";                  
$data_array["target"]="_blank"; 
$data_array["sequence"]=4; 
$data_array["block_id"]=2; 
$data_array["hint"]="蕃薯藤財經";      
$data_array["app"]="STOCK";  
$result=insert("sys_nav_links", $data_array);
$data_array=NULL; 

//插入 sys_nav_links 之連結
$data_array["title"]="證交所網站";               
$data_array["url"]="http://www.twse.com.tw/ch/index.php";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=5; 
$data_array["block_id"]=2; 
$data_array["hint"]="證交所網站";      
$data_array["app"]="STOCK";  
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="CMoney";               
$data_array["url"]="http://www.cmoney.tw/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=6; 
$data_array["block_id"]=2; 
$data_array["hint"]="CMoney";     
$data_array["app"]="STOCK";   
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="聚財網";               
$data_array["url"]="http://www.wearn.com/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=7; 
$data_array["block_id"]=2; 
$data_array["hint"]="聚財網";   
$data_array["app"]="STOCK";     
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="鉅亨網";               
$data_array["url"]="http://www.cnyes.com/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=8; 
$data_array["block_id"]=2; 
$data_array["hint"]="鉅亨網";     
$data_array["app"]="STOCK";   
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="台灣股市資訊網";               
$data_array["url"]="http://www.goodinfo.tw/StockInfo/index.asp";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=9; 
$data_array["block_id"]=2; 
$data_array["hint"]="台灣股市資訊網";    
$data_array["app"]="STOCK";    
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="撿股站";               
$data_array["url"]="http://stock.wespai.com/pick";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=10; 
$data_array["block_id"]=2; 
$data_array["hint"]="撿股站";      
$data_array["app"]="STOCK";  
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="NLOG 股市分析";               
$data_array["url"]="http://stock.nlog.cc/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=11; 
$data_array["block_id"]=2; 
$data_array["hint"]="NLOG 股市分析";     
$data_array["app"]="STOCK";   
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="玩股網";               
$data_array["url"]="http://www.wantgoo.com/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=12; 
$data_array["block_id"]=2; 
$data_array["hint"]="玩股網";    
$data_array["app"]="STOCK";    
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="玩股網";               
$data_array["url"]="http://www.wantgoo.com/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=12; 
$data_array["block_id"]=2; 
$data_array["hint"]="玩股網";    
$data_array["app"]="STOCK";    
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="萬寶周刊";               
$data_array["url"]="http://estock.marbo.com.tw/asp/databank.asp";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=13; 
$data_array["block_id"]=2; 
$data_array["hint"]="萬寶周刊";   
$data_array["app"]="STOCK";     
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="芭樂園";               
$data_array["url"]="http://www.guavafield.com/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=13; 
$data_array["block_id"]=2; 
$data_array["hint"]="芭樂園";   
$data_array["app"]="STOCK";     
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="凱基證券";               
$data_array["url"]="http://www.kgieworld.com.tw/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=0; 
$data_array["block_id"]=3; 
$data_array["hint"]="凱基證券";   
$data_array["app"]="STOCK";     
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="元富證券";               
$data_array["url"]="http://www.masterlink.com.tw/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=1; 
$data_array["block_id"]=3; 
$data_array["hint"]="元富證券";  
$data_array["app"]="STOCK";      
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="台銀證券";               
$data_array["url"]="http://www.twfhcsec.com.tw/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=2; 
$data_array["block_id"]=3; 
$data_array["hint"]="台銀證券";   
$data_array["app"]="STOCK";     
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="新光證券";               
$data_array["url"]="https://w.sk88.com.tw";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=3; 
$data_array["block_id"]=3; 
$data_array["hint"]="新光證券";   
$data_array["app"]="STOCK";     
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="群益證券";               
$data_array["url"]="https://www.capital.com.tw/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=4; 
$data_array["block_id"]=3; 
$data_array["hint"]="群益證券";   
$data_array["app"]="STOCK";     
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="元大寶來證券";               
$data_array["url"]="http://www.yuanta.com.tw/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=5; 
$data_array["block_id"]=3; 
$data_array["hint"]="元大寶來證券";   
$data_array["app"]="STOCK";     
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

//插入 sys_nav_links 之連結
$data_array["title"]="玉山證券";               
$data_array["url"]="http://www.esunsec.com.tw/";                   
$data_array["target"]="_blank"; 
$data_array["sequence"]=6; 
$data_array["block_id"]=3; 
$data_array["hint"]="玉山證券";      
$data_array["app"]="STOCK";  
$result=insert("sys_nav_links", $data_array);
$data_array=NULL;

/*====== 輸出 JSON 格式之安裝結果 (不用改) ======*/
$arr["result"]=$success ? "success" : "failure";
$arr["error"]=join("<br>",$error);
echo json_encode($arr);
?>