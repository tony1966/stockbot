<?php
/*-----------------------------------------------------------------------------
Title        : 台股分析系統 (結果呈現)
Translator   : Tony Huang (tony1966@ms5.hinet.net)
Version      : v1.0.0
Prototype    : 2015-01-05
Last Updated : 2015-01-27
Usage        : 應用程式的主要功能寫在此檔中
Note         : 
請根據安裝檔內寫入 tabs 的各頁籤 $tab 與各作業 $op 撰寫功能
Ajax/DataTable 的 url 格式 : 
$url="apps/app.php?op=get_xxxx";
$url="apps/app.php?op=list_xxxx";
$url="apps/app.php?op=add_xxxx";
$url="apps/app.php?op=remove_xxxx";
$url="apps/app.php?op=update_xxxx";
-----------------------------------------------------------------------------*/
session_start(); //必須啟動才能用 session
header('Content-Type: text/html;charset=UTF-8');
require_once("../db.php");           //匯入資料庫設定檔 (必須)
require_once("../lib/mysql.php");    //匯入資料庫模組   (必須)
require_once("../lib/tools.php");    //匯入工具模組     (選項)
require_once("../lib/parse.php");    //匯入剖析模組     (選項)
require_once("../lib/file.php");     //匯入file模組     (選項)
require_once("../lib/http.php");     //匯入http模組     (選項)
$op=$_REQUEST["op"];   //功能
switch ($op) { 
  case "home" : { //for ajax
?>
    <div id="STOCK_tabs" class="easyui-tabs" data-options="fit:'true'">
<?php
    $SQL="SELECT * FROM tabs WHERE tab_level<=".$_SESSION["user_level"].
         " ORDER BY tab_order";
    $RS=run_sql($SQL);  //
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
?>
      <div class="tab" title="<?php echo $RS[$i]["tab_label"] ?>" data-options="href:'<?php echo $RS[$i]["tab_link"] ?>'">
      </div>
<?php
        } //for
      } //if
?>
    </div>
<?php
    break;
    }
 
  case "snowball" : {
?>
<div class="tab" title="雪球股">
  <!--雪球股列表-->
  <table id="snowball" title="雪球股"  data-options="tools:'#snowball_tools',toolbar:'#snowball_search_bar'"></table>
  <div id="snowball_tools">
    <a href="#" id="reload_snowball" class="icon-reload" title="重新載入"></a>
  </div>
  <div id="snowball_search_bar" style="text-align:right;padding:2px;">
    <select id="snowball_search_field" class="easyui-combobox" data-options="panelHeight:90">
      <option value="stock_id">股號</option>
      <option value="stock_name">公司</option>
      <option value="category">類股</option
    </select>
    <input id="snowball_search_what" class="easyui-textbox">
  </div>
</div>
<script>
  $(function(){
    $('#snowball').datagrid({
      columns:[[
        {field:'stock_id',title:'股號',sortable:true},
        {field:'stock_name',title:'公司',sortable:true},
        {field:'dividend_avg',title:'5年平均股息',sortable:true},
        {field:'CV',title:'變異係數',sortable:true},
        {field:'market_value',title:'市值(億)',sortable:true},
        {field:'close',title:'收盤價',sortable:true},
        {field:'cheap_price',title:'便宜價',sortable:true},
        {field:'reason_price',title:'合理價',sortable:true},
        {field:'expensive_price',title:'昂貴價',sortable:true},
        {field:'yield',title:'殖利率',sortable:true},
        {field:'PER',title:'本益比',sortable:true},
        {field:'PBR',title:'股淨比',sortable:true},
        {field:'income_value_ratio',title:'營收市值比',sortable:true}
        ]],
      url:"apps/STOCK.php",
      queryParams:{op:"list_snowball"},
      fitColumns:true,
      singleSelect:true,
      pagination:true,
      pageSize:10,
      rownumbers:true
      });
    $("#snowball_search_what").textbox({
      icons:[{
        iconCls:"icon-search",
        handler:function(e){
          $('#snowball').datagrid("load",{
            op:"list_snowball",
            search_field:$("#snowball_search_field").combobox("getValue"),
            search_what:$("#snowball_search_what").textbox("getValue")
            });          
          }
        }]
      });
    $("#reload_snowball").bind("click",function(){
      $("#snowball").datagrid("load",{op:"list_snowball"});
      });
    });
</script>
<?php
    break;
    }
  case "list_snowball" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $sort=isset($_REQUEST['sort']) ? $_REQUEST['sort'] : 'dividend_avg';
    $order=isset($_REQUEST['order']) ? $_REQUEST['order'] : 'desc';
    if (isset($_REQUEST['search_field'])) { //有 search
      $where="WHERE ".$_REQUEST['search_field']." LIKE '%".
             $_REQUEST['search_what']."%'";
      }
    else { //無 search
      $where="WHERE `yield` > 3.125 ".
             "AND `close` <= `cheap_price` ".
             "AND `dividend_avg` >= 2 ".
             "AND `close` > 20 ".
             "AND `CV` <= 30 ".                  //5年平均股息變異係數
             "AND `income_YOY_plus` = 'Y' ".     //近3月營收年增率為正
             "AND `freecash_3Y` > 0 ".           //近3年自由現金流
             "AND `EPS_YOY_last2Q_plus` = 'Y'";  //近3季EPS年增率
      } 
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    //紀錄總筆數
    $SQL="SELECT COUNT(*) FROM `stocks_list` ".$where;
    $RS=run_sql($SQL);
    $total=$RS[0][0]; 
    //讀取系統設定
    $RS=search("stock_settings");
    $yahoo=$RS[0]["yahoo"];
    $statementdog=$RS[0]["statementdog"];
    $www2333two=$RS[0]["www2333tw"];
    $SQL="SELECT * FROM `stocks_list` ".$where." ORDER BY ".
         $sort." ".$order." LIMIT ".$start.",".$rows; 
    $RS=run_sql($SQL);
    $rows=Array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
        $stock_id_link="<a href='".$yahoo.$RS[$i]["stock_id"].
                       "' target='_blank' title='Yahoo'>".
                       $RS[$i]["stock_id"]."</a>";
        $stock_name_link="<a href='".$statementdog.$RS[$i]["stock_id"].
                         "' target='_blank' title='財報狗'>".
                         $RS[$i]["stock_name"]."</a>";
        $rows[$i]=Array("stock_id" => $stock_id_link,
                        "stock_name" => $stock_name_link,
                        "dividend_avg" => $RS[$i]["dividend_avg"],
                        "CV" => $RS[$i]["CV"],
                        "market_value" => round($RS[$i]["market_value"]),
                        "close" => $RS[$i]["close"],
                        "cheap_price" => $RS[$i]["cheap_price"],
                        "reason_price" => $RS[$i]["reason_price"],
                        "expensive_price" => $RS[$i]["expensive_price"],
                        "yield" => $RS[$i]["yield"],
                        "PER" => $RS[$i]["PER"],
                        "PBR" => $RS[$i]["PBR"],
                        "ROE" => $RS[$i]["ROE"],
                        "income_value_ratio" => $RS[$i]["income_value_ratio"].
                        "%"
                        );
        }
      }
    $arr=array("total" => $total, "rows" => $rows);
    echo json_encode($arr);
    break;
    } 
 
  case "growth" : {
?>
<div class="tab" title="成長股">
  <!--成長股列表-->
  <table id="growth" title="成長股"  data-options="tools:'#growth_tools',toolbar:'#growth_search_bar'"></table>
  <div id="growth_tools">
    <a href="#" id="help" class="icon-help" title="協助"></a>
    <a href="#" id="reload_growth" class="icon-reload" title="重新載入"></a>
  </div>
  <div id="growth_search_bar" style="text-align:right;padding:2px;">
    <select id="growth_search_field" class="easyui-combobox" data-options="panelHeight:90">
      <option value="stock_id">股號</option>
      <option value="stock_name">公司</option>
      <option value="category">類股</option
    </select>
    <input id="growth_search_what" class="easyui-textbox">
  </div>
</div>
<script>
  $(function(){
    $('#growth').datagrid({
      columns:[[
        {field:'stock_id',title:'股號',sortable:true},
        {field:'stock_name',title:'公司',sortable:true},
        {field:'dividend_avg',title:'5年平均股息',sortable:true},
        {field:'CV',title:'變異係數',sortable:true},
        {field:'close',title:'收盤價',sortable:true},
        {field:'cheap_price',title:'便宜價',sortable:true},
        {field:'reason_price',title:'合理價',sortable:true},
        {field:'expensive_price',title:'昂貴價',sortable:true},
        {field:'yield',title:'殖利率',sortable:true},
        {field:'PER',title:'本益比',sortable:true},
        {field:'PBR',title:'股淨比',sortable:true},
        {field:'value_equity_ratio',title:'市值淨值比',sortable:true},
        {field:'income_value_ratio',title:'營收市值比',sortable:true},
        {field:'IIR_1Q',title:'存貨營收 比',sortable:true}
        ]],
      url:"apps/STOCK.php",
      queryParams:{op:"list_growth"},
      fitColumns:true,
      singleSelect:true,
      pagination:true,
      pageSize:10,
      rownumbers:true
      });
    $("#growth_search_what").textbox({
      icons:[{
        iconCls:"icon-search",
        handler:function(e){
          $('#growth').datagrid("load",{
            op:"list_growth",
            search_field:$("#growth_search_field").combobox("getValue"),
            search_what:$("#growth_search_what").textbox("getValue")
            });          
          }
        }]
      });
    $("#reload_growth").bind("click",function(){
      $("#growth").datagrid("load",{op:"list_growth"});
      });
    });
</script>
<?php
    break;
    }
  case "list_growth" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $sort=isset($_REQUEST['sort']) ? $_REQUEST['sort'] : 'close';
    $order=isset($_REQUEST['order']) ? $_REQUEST['order'] : 'desc';
    if (isset($_REQUEST['search_field'])) { //有 search
      $where="WHERE ".$_REQUEST['search_field']." LIKE '%".
             $_REQUEST['search_what']."%'";
      }
    else { //無 search
      $where="WHERE `listed_years` >= 2 ".        //2:上市兩年以上
             "AND `stock_name` NOT LIKE 'F%' ".   //2:去除F-股
             "AND `ATNI_4Y_plus` = 'Y' ".         //3:近4年稅後淨利均為正
             "AND `OPM_plus` = 'Y' ".             //4:近3季營益率均為正
             "AND `OPM_down30p` = 'N' ".          //4:近1季營益率未降3成以上
             "AND `OPM_increase` = 'Y' ".         //4:近3季營益率遞增
             "AND `OPM_CV` < 30 ".                //4:近8季營益率變異係數
             "AND `freecash_3Y` > 0 ".            //5:近3年現金流量均為正
             "AND `income_YOY_plus` = 'Y' ".      //6:近3月營收年增率均為正
             //"AND `income_YOY_over20` = 'Y' ".    //6:近3月營收年增率>20%
             "AND `market_value` >= 50 ".         //8:市值超過50億
             "AND `IT_3Q_decrease` = 'N' ".       //9:近3季存貨周轉率未遞減
             "AND `EPS_YOY_last2Q_plus` = 'Y'".   //12:近2季EPS年增率為正
             "AND `IIR_3Q_increase` = 'N' ".      //X:近3季存貨營收比遞增
             "AND `IIR_CV` <= 20 ".               //X:近8季存貨營收比CV
             "AND `IIR_1Q` < 0.5 ".               //X:近1季存貨營收比
             "AND `ART_3Q_decrease` = 'N' ".      //X:近3季應收帳周轉率遞減
             "AND `income_value_ratio` > 20 ".    //X:營收市值比
             "AND `income_value_ratio` < 180 ";   //X:營收市值比
      } 
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    //紀錄總筆數
    $SQL="SELECT COUNT(*) FROM `stocks_list` ".$where;
    $RS=run_sql($SQL);
    $total=$RS[0][0]; 
    //讀取系統設定
    $RS=search("stock_settings");
    $yahoo=$RS[0]["yahoo"];
    $statementdog=$RS[0]["statementdog"];
    $www2333two=$RS[0]["www2333tw"];
    $SQL="SELECT * FROM `stocks_list` ".$where." ORDER BY ".
         $sort." ".$order." LIMIT ".$start.",".$rows; 
    $RS=run_sql($SQL);
    $rows=Array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
        $stock_id_link="<a href='".$yahoo.$RS[$i]["stock_id"].
                       "' target='_blank' title='Yahoo'>".
                       $RS[$i]["stock_id"]."</a>";
        $stock_name_link="<a href='".$statementdog.$RS[$i]["stock_id"].
                         "' target='_blank' title='財報狗'>".
                         $RS[$i]["stock_name"]."</a>";
        $rows[$i]=Array("stock_id" => $stock_id_link,
                        "stock_name" => $stock_name_link,
                        "dividend_avg" => $RS[$i]["dividend_avg"],
                        "CV" => $RS[$i]["CV"],
                        "close" => $RS[$i]["close"],
                        "cheap_price" => $RS[$i]["cheap_price"],
                        "reason_price" => $RS[$i]["reason_price"],
                        "expensive_price" => $RS[$i]["expensive_price"],
                        "yield" => $RS[$i]["yield"],
                        "PER" => $RS[$i]["PER"],
                        "PBR" => $RS[$i]["PBR"],
                        "value_equity_ratio" => $RS[$i]["value_equity_ratio"],
                        "income_value_ratio" => $RS[$i]["income_value_ratio"].
                        "%",
                        "IIR_1Q" => $RS[$i]["IIR_1Q"],          
                        "GVI" => $RS[$i]["GVI"]         
                        );
        }
      }
    $arr=array("total" => $total, "rows" => $rows);
    echo json_encode($arr);
    break;
    }  
  case "stocks" : {
?>
<div class="tab" title="個股">
  <!--個股列表-->
  <table id="stocks" title="個股"  data-options="tools:'#stocks_tools',toolbar:'#stocks_search_bar'"></table>
  <div id="stocks_tools">
    <a href="#" id="help" class="icon-help" title="協助"></a>
    <a href="#" id="reload_stocks" class="icon-reload" title="重新載入"></a>
  </div>
  <div id="stocks_search_bar" style="text-align:right;padding:2px;">
    <a href="#" id="load_snowball" class="easyui-linkbutton">雪球股</a>
    <a href="#" id="load_growth" class="easyui-linkbutton">成長股</a>
    <a href="#" id="load_GVI" class="easyui-linkbutton">GVI</a>
    <select id="stocks_search_field" class="easyui-combobox" data-options="panelHeight:90">
      <option value="stock_id">股號</option>
      <option value="stock_name">公司</option>
      <option value="category">類股</option
    </select>
    <input id="stocks_search_what" class="easyui-textbox">
  </div>
  <div id="stock_dialog" class="easyui-dialog" title="個股明細" style="width:700px;height:400px;" data-options="closed:'true'">
    <table id="stock_propertygrid" class="easyui-propertygrid"></table>
  </div>
</div>
<script>
  $(function(){
    $('#stocks').datagrid({
      columns:[[
        {field:'stock_id',title:'股號',sortable:true},
        {field:'stock_name',title:'公司',sortable:true},
        {field:'dividend_avg',title:'5年平均股息',sortable:true},
        {field:'CV',title:'變異係數',sortable:true},
        {field:'close',title:'收盤價',sortable:true},
        {field:'cheap_price',title:'便宜價',sortable:true},
        {field:'reason_price',title:'合理價',sortable:true},
        {field:'expensive_price',title:'昂貴價',sortable:true},
        {field:'yield',title:'殖利率',sortable:true},
        {field:'PER',title:'本益比',sortable:true},
        {field:'PBR',title:'股淨比',sortable:true},
        {field:'value_equity_ratio',title:'市值淨值比',sortable:true},
        {field:'income_value_ratio',title:'營收市值比',sortable:true},
        {field:'IIR_1Q',title:'存貨營收比',sortable:true},
        {field:'GVI',title:'GVI',sortable:true}
        ]],
      url:"apps/STOCK.php",
      queryParams:{op:"list_stocks"},
      fitColumns:true,
      singleSelect:true,
      pagination:true,
      pageSize:10,
      rownumbers:true,
      onDblClickRow:function(index,row){
        $("#stock_dialog").dialog("open");
        var s=row.stock_id.indexOf(">");
        var e=row.stock_id.indexOf("</a>");
        var id=row.stock_id.substring(s+1,e); //從 yahoo link 取出股號
        var url="apps/STOCK.php?op=get_stock&stock_id=" + id;
        $("#stock_propertygrid").propertygrid({
          url:url,
          loadMsg:"載入中 ..."
          });
        }
      });
    $('#stock_propertygrid').propertygrid({
      columns:[[
        {field:'name',title:'欄位',sortable:true},
        {field:'value',title:'值',editor:'text'}
        ]],
      fit:true,
      fitColumns:true,
      singleSelect:true,
      scrollbarSize:0
      });
    $("#stocks_search_what").textbox({
      icons:[{
        iconCls:"icon-search",
        handler:function(e){
          $('#stocks').datagrid("load",{
            op:"list_stocks",
            search_field:$("#stocks_search_field").combobox("getValue"),
            search_what:$("#stocks_search_what").textbox("getValue")
            });          
          }
        }]
      });
    $("#reload_stocks").bind("click",function(){
      $("#stocks").datagrid("load",{op:"list_stocks"});
      });
    $("#load_snowball").bind("click",function(){
      $("#stocks").datagrid("load",{op:"list_snowball"});
      });
    $("#load_growth").bind("click",function(){
      $("#stocks").datagrid("load",{op:"list_growth"});
      });
    $("#load_GVI").bind("click",function(){
      $("#stocks").datagrid("load",{op:"list_GVI"});
      });
    });
</script>
<?php
    break;
    }
  case "list_GVI" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $sort=isset($_REQUEST['sort']) ? $_REQUEST['sort'] : 'GVI';
    $order=isset($_REQUEST['order']) ? $_REQUEST['order'] : 'desc';
    if (isset($_REQUEST['search_field'])) { //有 search
      $where="WHERE ".$_REQUEST['search_field']." LIKE '%".
             $_REQUEST['search_what']."%'";
      }
    else { //無 search
      $where="WHERE `freecash_3Y` > 0 ";         //近3年自由現金流為正
             //"AND `income_YOY_plus` = 'Y' ".     //近3月營收年增率為正
             //"AND `EPS_YOY_last2Q_plus` = 'Y'";  //近3季EPS年增率為正
      } 
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    //紀錄總筆數
    $SQL="SELECT COUNT(*) FROM `stocks_list` ".$where;
    $RS=run_sql($SQL);
    $total=$RS[0][0]; 
    //讀取系統設定
    $RS=search("stock_settings");
    $yahoo=$RS[0]["yahoo"];
    $statementdog=$RS[0]["statementdog"];
    $www2333two=$RS[0]["www2333tw"];
    $SQL="SELECT * FROM `stocks_list` ".$where." ORDER BY ".
         $sort." ".$order." LIMIT ".$start.",".$rows; 
    $RS=run_sql($SQL);
    $rows=Array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
        $stock_id_link="<a href='".$yahoo.$RS[$i]["stock_id"].
                       "' target='_blank' title='Yahoo'>".
                       $RS[$i]["stock_id"]."</a>";
        $stock_name_link="<a href='".$statementdog.$RS[$i]["stock_id"].
                         "' target='_blank' title='財報狗'>".
                         $RS[$i]["stock_name"]."</a>";
        $rows[$i]=Array("stock_id" => $stock_id_link,
                        "stock_name" => $stock_name_link,
                        "dividend_avg" => $RS[$i]["dividend_avg"],
                        "CV" => $RS[$i]["CV"],
                        "close" => $RS[$i]["close"],
                        "cheap_price" => $RS[$i]["cheap_price"],
                        "reason_price" => $RS[$i]["reason_price"],
                        "expensive_price" => $RS[$i]["expensive_price"],
                        "yield" => $RS[$i]["yield"],
                        "PER" => $RS[$i]["PER"],
                        "PBR" => $RS[$i]["PBR"],
                        "value_equity_ratio" => $RS[$i]["value_equity_ratio"],
                        "income_value_ratio" => $RS[$i]["income_value_ratio"].
                        "%",
                        "IIR_1Q" => $RS[$i]["IIR_1Q"],          
                        "GVI" => $RS[$i]["GVI"]          
                        );
        }
      }
    $arr=array("total" => $total, "rows" => $rows);
    echo json_encode($arr);
    break;
    }  
  case "list_stocks" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $sort=isset($_REQUEST['sort']) ? $_REQUEST['sort'] : 'stock_id';
    $order=isset($_REQUEST['order']) ? $_REQUEST['order'] : 'asc';
    if (isset($_REQUEST['search_field'])) { //有 search
      $where="WHERE ".$_REQUEST['search_field']." LIKE '%".
             $_REQUEST['search_what']."%'";
      }
    else { //無 search
      $where="";   
      } 
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    //紀錄總筆數
    $SQL="SELECT COUNT(*) FROM `stocks_list` ".$where;
    $RS=run_sql($SQL);
    $total=$RS[0][0]; 
    //讀取系統設定
    $RS=search("stock_settings");
    $yahoo=$RS[0]["yahoo"];
    $statementdog=$RS[0]["statementdog"];
    $www2333two=$RS[0]["www2333tw"];
    $SQL="SELECT * FROM `stocks_list` ".$where." ORDER BY ".
         $sort." ".$order." LIMIT ".$start.",".$rows; 
    $RS=run_sql($SQL);
    $rows=Array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
        $stock_id_link="<a href='".$yahoo.$RS[$i]["stock_id"].
                       "' target='_blank' title='Yahoo'>".
                       $RS[$i]["stock_id"]."</a>";
        $stock_name_link="<a href='".$statementdog.$RS[$i]["stock_id"].
                         "' target='_blank' title='財報狗'>".
                         $RS[$i]["stock_name"]."</a>";
        $rows[$i]=Array("stock_id" => $stock_id_link,
                        "stock_name" => $stock_name_link,
                        "dividend_avg" => $RS[$i]["dividend_avg"],
                        "CV" => $RS[$i]["CV"],
                        "close" => $RS[$i]["close"],
                        "cheap_price" => $RS[$i]["cheap_price"],
                        "reason_price" => $RS[$i]["reason_price"],
                        "expensive_price" => $RS[$i]["expensive_price"],
                        "yield" => $RS[$i]["yield"],
                        "PER" => $RS[$i]["PER"],
                        "PBR" => $RS[$i]["PBR"],
                        "value_equity_ratio" => $RS[$i]["value_equity_ratio"],
                        "income_value_ratio" => $RS[$i]["income_value_ratio"].
                        "%",
                        "IIR_1Q" => $RS[$i]["IIR_1Q"],          
                        "GVI" => $RS[$i]["GVI"]          
                        );
        }
      }
    $arr=array("total" => $total, "rows" => $rows);
    echo json_encode($arr);
    break;
    }  
  case "get_stock" : {
    $stock_id=$_REQUEST["stock_id"];
    $RS=search("stocks_list","stock_id",$stock_id);
    $fields=get_fields("stocks_list");
    $rows=array();
    for ($i=0; $i<count($fields);$i++) {
      $rows[$i]=Array("name" => $fields[$i],"value" => $RS[0][$fields[$i]]);
      }
    $arr=array("total" => count($fields), "rows" => $rows);
    echo json_encode($arr);
    break;
    }
  case "z0000" : {
?>
<div class="tab" title="加權指數">
  <!--加權指數列表-->
  <table id="z0000" title="加權指數"  data-options="tools:'#z0000_tools',toolbar:'#z0000_search_bar'"></table>
  <div id="z0000_tools">
    <a href="#" id="reload_z0000" class="icon-reload" title="重新載入"></a>
  </div>
  <div id="z0000_search_bar" style="text-align:right;padding:2px;">
    <select id="z0000_search_field" class="easyui-combobox" data-options="panelHeight:90">
      <option value="trade_date">日期</option>
    </select>
    <input id="z0000_search_what" class="easyui-textbox">
  </div>
</div>
<script>
  $(function(){
    $('#z0000').datagrid({
      columns:[[
        {field:'trade_date',title:'日期',sortable:true},
        {field:'close',title:'收盤指數',sortable:true},
        {field:'volumn',title:'成交量(億)',sortable:true},
        {field:'delta',title:'漲跌',sortable:true},
        {field:'delta_percent',title:'漲跌幅',sortable:true},
        {field:'rise',title:'漲家數',sortable:true},
        {field:'fall',title:'跌家數',sortable:true},
        {field:'even',title:'平家數',sortable:true},
        {field:'rise_fall_ratio',title:'漲跌家數比',sortable:true}
        ]],
      url:"apps/STOCK.php",
      queryParams:{op:"list_z0000"},
      fitColumns:true,
      singleSelect:true,
      pagination:true,
      pageSize:10,
      rownumbers:true
      });
    $("#z0000_search_what").textbox({
      icons:[{
        iconCls:"icon-search",
        handler:function(e){
          $('#z0000').datagrid("load",{
            op:"list_z0000",
            search_field:$("#z0000_search_field").combobox("getValue"),
            search_what:$("#z0000_search_what").textbox("getValue")
            });          
          }
        }]
      });
    $("#reload_z0000").bind("click",function(){
      $("#z0000").datagrid("load",{op:"list_z0000"});
      });
    });
</script>
<?php
    break;
    }
  case "list_z0000" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $sort=isset($_REQUEST['sort']) ? $_REQUEST['sort'] : 'trade_date';
    $order=isset($_REQUEST['order']) ? $_REQUEST['order'] : 'desc';
    if (isset($_REQUEST['search_field'])) { //有 search
      $where="WHERE ".$_REQUEST['search_field']." LIKE '%".
             $_REQUEST['search_what']."%'";
      }
    else {$where="";} //無 search
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    $SQL="SELECT COUNT(*) FROM `z0000`";
    $RS=run_sql($SQL);
    $total=$RS[0][0]; //紀錄總筆數
    $SQL="SELECT * FROM z0000 ".$where." ORDER BY ".
         $sort." ".$order." LIMIT ".$start.",".$rows; 
    $RS=run_sql($SQL);
    $rows=Array();
    if (is_array($RS)) { //有找到資料的話
        for ($i=0; $i<count($RS); $i++) { //走訪紀錄集陣列
             $rows[$i]=array(
               "trade_date" => $RS[$i]["trade_date"],
               "close" => $RS[$i]["close"],
               "volumn" => round($RS[$i]["volumn"]/100000000,0),
               "delta" => $RS[$i]["delta"],
               "delta_percent" => $RS[$i]["delta_percent"],
               "rise" => $RS[$i]["rise"],
               "fall" => $RS[$i]["fall"],
               "even" => $RS[$i]["even"],
               "rise_fall_ratio" => $RS[$i]["rise_fall_ratio"]
               );
             } //end of for
        } //end of if
    $arr=array("total" => $total, "rows" => $rows);
    echo json_encode($arr);
    break;
    }   
  case "compound_annuity" : {
?>
<div class="tab" title="Cron">
  <!--複利與年金列表-->
  <table id="compound" title="複利終值表"></table><br>
  <table id="compound_annuity" title="年金複利終值表"></table>
</div>
<script>
  $(function(){
    //compound_annuity
    $('#compound').datagrid({
      columns:[[
        {field:'0',title:'年'},
        {field:'1',title:'1%'},
        {field:'2',title:'2%'},
        {field:'3',title:'3%'},
        {field:'4',title:'4%'},
        {field:'5',title:'5%'},
        {field:'6',title:'6%'},
        {field:'7',title:'7%'},
        {field:'8',title:'8%'},
        {field:'9',title:'9%'},
        {field:'10',title:'10%'},
        {field:'11',title:'11%'},
        {field:'12',title:'12%'},
        {field:'13',title:'13%'},
        {field:'14',title:'14%'},
        {field:'15',title:'15%'}
        ]],
      url:"apps/STOCK.php",
      queryParams:{op:"list_compound"},
      fitColumns:true,
      singleSelect:true
      });
    $('#compound_annuity').datagrid({
      columns:[[
        {field:'0',title:'年'},
        {field:'1',title:'1%'},
        {field:'2',title:'2%'},
        {field:'3',title:'3%'},
        {field:'4',title:'4%'},
        {field:'5',title:'5%'},
        {field:'6',title:'6%'},
        {field:'7',title:'7%'},
        {field:'8',title:'8%'},
        {field:'9',title:'9%'},
        {field:'10',title:'10%'},
        {field:'11',title:'11%'},
        {field:'12',title:'12%'},
        {field:'13',title:'13%'},
        {field:'14',title:'14%'},
        {field:'15',title:'15%'}
        ]],
      url:"apps/STOCK.php",
      queryParams:{op:"list_compound_annuity"},
      fitColumns:true,
      singleSelect:true
      });
    });
</script>
<?php
    break;
    }    
  case "list_compound" : {
    //製作複利表
    $r=Array();
    for ($i=1; $i<=50; $i++) {    //列=年
      $c=Array();
      for ($j=0; $j<=15; $j++) {   //行=利息
        if ($j==0) {$c["0"]=$i;}
        else {$c["$j"]=round(pow(1 + $j/100,$i),3);}
        }
      $r[$i]=json_encode($c);
      $c=null;
      }
    echo '{"total":750,"rows":['.join(',',$r).']}';
    break;
    }  
  case "list_compound_annuity" : {
    //製作複利表
    $r=Array();
    for ($i=1; $i<=50; $i++) {    //列=年
      $c=Array();
      for ($j=0; $j<=15; $j++) {   //行=利息
        if ($j==0) {$c["0"]=$i;}
        else {$c["$j"]=round((pow(1 + $j/100,$i)-1)/($j/100),2);}
        }
      $r[$i]=json_encode($c);
      $c=null;
      }
    echo '{"total":750,"rows":['.join(',',$r).']}';
    break;
    }        
  case "cron_log" : {
?>
<div class="tab" title="Cron">
  <!--Cron 執行紀錄列表-->
  <table id="cron_log" title="Cron 執行紀錄列表"  data-options="tools:'#cron_log_tools',toolbar:'#cron_log_search_bar'"></table>
  <div id="cron_log_tools">
    <a href="#" id="clear_cron_log" class="icon-remove" title="刪除全部 Cron 紀錄"></a>
    <a href="#" id="reload_cron_log" class="icon-reload" title="重新載入"></a>
  </div>
  <div id="cron_log_search_bar" style="text-align:right;padding:2px;">
    <select id="cron_log_search_field" class="easyui-combobox" data-options="panelHeight:100">
      <option value="date_time">日期時間</option>
      <option value="program_name">程式名稱</option>
      <option value="cron_type">Cron 類別</option>
    </select>
    <input id="cron_log_search_what" class="easyui-textbox">
  </div>
</div>
<script>
  $(function(){
    //cron
    $('#cron_log').datagrid({
      columns:[[
        {field:'id',title:'id',sortable:true},
        {field:'date_time',title:'日期時間',sortable:true},
        {field:'program_name',title:'程式名稱',sortable:true},
        {field:'cron_type',title:'類型',sortable:true},
        {field:'elapsed',title:'耗費時間',sortable:true},
        {field:'remark',title:'備註',sortable:true}
        ]],
      url:"apps/STOCK.php",
      queryParams:{op:"list_cron_log"},
      fitColumns:true,
      singleSelect:true,
      pagination:true,
      pageSize:10,
      rownumbers:true
      });
    $("#cron_log_search_what").textbox({
      icons:[{
        iconCls:"icon-search",
        handler:function(e){
          $('#cron_log').datagrid("load",{
            op:"list_cron_log",
            search_field:$("#cron_log_search_field").combobox("getValue"),
            search_what:$("#cron_log_search_what").textbox("getValue")
            });          
          }
        }]
      });
    $("#reload_cron_log").bind("click",function(){
      $("#cron_log").datagrid("load",{op:"list_cron_log",order:"desc"});
      });
    $("#clear_cron_log").bind("click",function(){
      $.messager.confirm("確認","確定要刪除全部 cron 執行紀錄嗎?",function(btn){
        if (btn){
          var params={op:"clear_cron_log"};
          var callback=function(data){
            if (data.status==="success"){
              $("#cron_log").datagrid("reload",{op:"list_cron_log"});
              }
            else {$.messager.alert("訊息","刪除 cron 紀錄失敗!","error");}            
            };                
          $.post("./apps/STOCK.php",params,callback,"json");
          }
        });
      });
    });
</script>
<?php
    break;
    }
  case "list_cron_log" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $sort=isset($_REQUEST['sort']) ? $_REQUEST['sort'] : 'date_time';
    $order=isset($_REQUEST['order']) ? $_REQUEST['order'] : 'desc';
    if (isset($_REQUEST['search_field'])) { //有 search
      $where="WHERE ".$_REQUEST['search_field']." LIKE '%".
             $_REQUEST['search_what']."%'";
      }
    else {$where="";} //無 search
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    $SQL="SELECT COUNT(*) FROM `cron_log`";
    $RS=run_sql($SQL);
    $total=$RS[0][0]; //紀錄總筆數
    $SQL="SELECT * FROM cron_log ".$where." ORDER BY ".
         $sort." ".$order." LIMIT ".$start.",".$rows; 
    $RS=run_sql($SQL);
    $rows=Array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
        $rows[$i]=Array("id" => $RS[$i]["id"],
                        "date_time" => $RS[$i]["date_time"],
                        "program_name" => $RS[$i]["program_name"],
                        "cron_type" => $RS[$i]["cron_type"],
                        "elapsed" => $RS[$i]["elapsed"],
                        "remark" => $RS[$i]["remark"]
                        );
        }
      }
    $arr=array("total" => $total, "rows" => $rows);
    echo json_encode($arr);
    break;
    }    
  case "clear_cron_log" : {
    $result=delete_record_all("cron_log");
    if ($result===TRUE) {$status="success";}
    else {$status="failure";}
    $arr["status"]=$status;
    echo json_encode($arr);
    break;
    }
  case "stock_settings" : { 
    //查詢系統設定表     
    $RS=search("stock_settings");
    //取得設定值
    $test_mode=$RS[0]["test_mode"];                    //測試模式:Y/N
    $test_date=$RS[0]["test_date"];                    //欲測試之交易日期
    $twse_trade_date=$RS[0]["twse_trade_date"];        //最近擷取之交易日期
    $dividend_pointer=$RS[0]["dividend_pointer_2330"]; //股息下載指標
    $dividend_offset=$RS[0]["dividend_offset_2330"];   //股息下載筆數
    $basic_pointer=$RS[0]["basic_pointer_2330"];       //基本資料下載指標
    $basic_offset=$RS[0]["basic_offset_2330"];         //基本資料下載筆數
    $profit_pointer=$RS[0]["profit_pointer_2330"];     //損益表下載指標
    $profit_offset=$RS[0]["profit_offset_2330"];       //損益表下載筆數
    $income_pointer=$RS[0]["income_pointer_2330"];     //營業收入下載指標
    $income_offset=$RS[0]["income_offset_2330"];       //營業收入下載筆數
    $balance_pointer=$RS[0]["balance_pointer_2330"];   //資產負債表下載指標
    $balance_offset=$RS[0]["balance_offset_2330"];     //資產負債表下載筆數
    $cash_pointer=$RS[0]["cash_pointer_2330"];         //現金流量表下載指標
    $cash_offset=$RS[0]["cash_offset_2330"];           //現金流量表下載筆數
    $analysis_pointer=$RS[0]["analysis_pointer_2330"]; //財務分析表下載指標
    $analysis_offset=$RS[0]["analysis_offset_2330"];   //財務分析表下載筆數
    $yahoo=$RS[0]["yahoo"];                            //Yahoo 個股查詢 URL
    $statementdog=$RS[0]["statementdog"];              //財報狗個股查詢 URL
    $www2333tw=$RS[0]["www2333tw"];                    //台股觀察站個股查詢 URL
    $esun=$RS[0]["esun"];                              //玉山證券個股查詢 URL
    $twse=$RS[0]["twse"];                              //公開資訊觀測站 URL
?>
<div class="tab" title="系統設定">
  <!--系統設定表單-->
  <div id="stock_settings" class="easyui-panel" title="系統設定" style="width:auto;padding:5px;" data-options="tools:'#stock_settings_tools'">
    <form id="stock_settings_form" style="padding:5px">
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">切換至測試模式 : </label>
        <select name="test_mode" class="easyui-combobox" data-options="panelMinHeight:30">
          <option value="N">N</option>
          <option value="Y">Y</option>
        </select>
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">欲測試之交易日期 : </label>
        <input name="test_date" type="text" class="easyui-textbox">
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">最近擷取之交易日期 : </label>
        <input name="twse_trade_date" type="text" class="easyui-textbox"> 
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">股息下載指標 : </label>
        <input name="dividend_pointer" type="text" class="easyui-textbox">
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">股息下載筆數 : </label>
        <input name="dividend_offset" type="text" class="easyui-textbox"> 
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">基本資料下載指標 : </label>
        <input name="basic_pointer" type="text" class="easyui-textbox"> 
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">基本資料下載筆數 : </label>
        <input name="basic_offset" type="text" class="easyui-textbox">
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">損益表下載指標 : </label>
        <input name="profit_pointer" type="text" class="easyui-textbox"> 
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">損益表下載筆數 : </label>
        <input name="profit_offset" type="text" class="easyui-textbox"> 
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">營業收入下載指標 : </label>
        <input name="income_pointer" type="text" class="easyui-textbox">
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">營業收入下載筆數 : </label>
        <input name="income_offset" type="text" class="easyui-textbox">
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">資產負債表下載指標 : </label>
        <input name="balance_pointer" type="text" class="easyui-textbox">
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">資產負債表下載筆數 : </label>
        <input name="balance_offset" type="text" class="easyui-textbox">
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">現金流量表下載指標 : </label>
        <input name="cash_pointer" type="text" class="easyui-textbox">
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">現金流量表下載筆數 : </label>
        <input name="cash_offset" type="text" class="easyui-textbox"> 
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">財務分析表下載指標 : </label>
        <input name="analysis_pointer" type="text" class="easyui-textbox">
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">財務分析表下載筆數 : </label>
        <input name="analysis_offset" type="text" class="easyui-textbox"> 
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">Yahoo 個股查詢 URL : </label>
        <input name="yahoo" type="text" class="easyui-textbox" style="width:500px;">
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">財報狗個股查詢 URL : </label>
        <input name="statementdog" type="text" class="easyui-textbox"   style="width:500px;">
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">台股觀察站個股查詢 URL : </label>
        <input name="www2333tw" type="text" class="easyui-textbox" style="width:500px;">
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">玉山證券個股查詢 URL : </label>
        <input name="esun" type="text" class="easyui-textbox" style="width:500px;">
      </div>
      <div style="margin:10px">
        <label style="width:200px;display:inline-block;">公開資訊觀測站 URL : </label>
        <input name="twse" type="text" class="easyui-textbox" style="width:500px;">
      </div>
    </form>
  </div>
  <div id="stock_settings_tools">
    <a href="#" id="save_stock_settings" class="icon-save" title="儲存"></a>
  </div>
</div>
<script>
  $(document).ready(function(){
    $("#stock_settings").panel({height:$("#center").height()-80});
    //使用者設定 stock_settings
    $("#stock_settings_form").form("load",
      {test_mode:"<?php echo $test_mode ?>",
       test_date:"<?php echo $test_date ?>",
       twse_trade_date:"<?php echo $twse_trade_date ?>",
       dividend_pointer:"<?php echo $dividend_pointer ?>",
       dividend_offset:"<?php echo $dividend_offset ?>",
       basic_pointer:"<?php echo $basic_pointer ?>",
       basic_offset:"<?php echo $basic_offset ?>",
       profit_pointer:"<?php echo $profit_pointer ?>",
       profit_offset:"<?php echo $profit_offset ?>",
       income_pointer:"<?php echo $income_pointer ?>",
       income_offset:"<?php echo $income_offset ?>",
       balance_pointer:"<?php echo $balance_pointer ?>",
       balance_offset:"<?php echo $balance_offset ?>",
       cash_pointer:"<?php echo $cash_pointer ?>",
       cash_offset:"<?php echo $cash_offset ?>",
       analysis_pointer:"<?php echo $analysis_pointer ?>",
       analysis_offset:"<?php echo $analysis_offset ?>",
       yahoo:"<?php echo $yahoo ?>",
       statementdog:"<?php echo $statementdog ?>",
       www2333tw:"<?php echo $www2333tw ?>",
       esun:"<?php echo $esun ?>",
       twse:"<?php echo $twse ?>"
       });
    $('#save_stock_settings').bind('click',function(){
      $("#stock_settings_form").form("submit",{
        url:"./apps/STOCK.php",
        method:"post",
        queryParams:{op:"update_stock_settings"},
        success:function(data){
          var data=eval('(' + data + ')');
          if (data.status==='success'){
            $.messager.alert('訊息','系統設定更新成功!',"info"); 
            }
          else {$.messager.alert('訊息','系統設定更新失敗!',"error");}
          }
        });
      });
    $('#reload_stock_settings').bind('click',function(){
      $('#stock_settings').panel('open').panel('refresh');
      });
    });
</script>  
<?php
    break;
    }
  case "update_stock_settings" : {
    $data_array["test_mode"]=$_REQUEST["test_mode"];
    $data_array["test_date"]=$_REQUEST["test_date"];
    $data_array["dividend_pointer_2330"]=$_REQUEST["dividend_pointer"];
    $data_array["dividend_offset_2330"]=$_REQUEST["dividend_offset"];
    $data_array["basic_pointer_2330"]=$_REQUEST["basic_pointer"];
    $data_array["basic_offset_2330"]=$_REQUEST["basic_offset"];
    $data_array["profit_pointer_2330"]=$_REQUEST["profit_pointer"];
    $data_array["profit_offset_2330"]=$_REQUEST["profit_offset"];
    $data_array["income_pointer_2330"]=$_REQUEST["income_pointer"];
    $data_array["income_offset_2330"]=$_REQUEST["income_offset"];
    $data_array["balance_pointer_2330"]=$_REQUEST["balance_pointer"];
    $data_array["balance_offset_2330"]=$_REQUEST["balance_offset"];
    $data_array["cash_pointer_2330"]=$_REQUEST["cash_pointer"];
    $data_array["cash_offset_2330"]=$_REQUEST["cash_offset"];
    $data_array["analysis_pointer_2330"]=$_REQUEST["analysis_pointer"];
    $data_array["analysis_offset_2330"]=$_REQUEST["analysis_offset"];
    $data_array["yahoo"]=$_REQUEST["yahoo"];
    $data_array["statementdog"]=$_REQUEST["statementdog"];
    $data_array["www2333tw"]=$_REQUEST["www2333tw"];
    $data_array["esun"]=$_REQUEST["esun"];
    $data_array["twse"]=$_REQUEST["twse"];
    $result=update_all("stock_settings", $data_array);
    if ($result===TRUE) {$status="success";}
    else {$status="failure";}
    $arr["status"]=$status;
    echo json_encode($arr);
    break;
    }
  case "tabs" : { //for ajax
?>
<div class="tab" title="頁籤列表">
  <!--標頭連結 tabs 列表-->
  <table id="tabs" title="頁籤列表" style="width:auto" data-options="tools:'#tabs_tools'"></table>
  <div id="tabs_tools">    
    <a href="#" id="add_tab" class="icon-add" title="新增"></a>
    <a href="#" id="edit_tab" class="icon-edit" title="編輯"></a>
    <a href="#" id="remove_tab" class="icon-remove" title="刪除"></a>
    <a href="#" id="reload_tabs" class="icon-reload" title="重新載入"></a>
  </div>
  <!--新增&編輯 tabs 表單對話框-->
  <div id="tabs_dialog" class="easyui-dialog" title="新增頁籤" style="width:370px;height:270px;"  data-options="closed:'true',buttons:'#tabs_buttons'">
    <form id="tabs_form" style="padding:10px">
      <div style="margin:5px">
        <label style="width:70px;display:inline-block;">頁籤名稱 : </label>
        <input name="tab_name" type="text" class="easyui-textbox"  data-options="missingMessage:'此欄位為必填',required:true" style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:70px;display:inline-block;">頁籤標題 : </label>
        <input name="tab_label" type="text" class="easyui-textbox"  data-options="missingMessage:'此欄位為必填',required:true" style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:70px;display:inline-block;">頁籤連結 : </label>
        <input name="tab_link" type="text" class="easyui-textbox"  data-options="missingMessage:'此欄位為必填',required:true" style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:70px;display:inline-block;">頁籤層次 : </label>
        <input name="tab_level" id="tab_level" class="easyui-numberspinner" data-options="missingMessage:'此欄位為必填',required:true" style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:70px;display:inline-block;">頁籤提示 : </label>
        <input name="tab_tip" type="text" class="easyui-textbox"  data-options="missingMessage:'此欄位為必填',required:true" style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:70px;display:inline-block;">頁籤順序 : </label>
        <input name="tab_order" id="tab_order" class="easyui-numberspinner" data-options="missingMessage:'此欄位為必填',required:true" style="width:230px">
        <input type="hidden" id="tab_op" value="">
        <input type="hidden" id="tab_id" value="">
      </div>
    </form>
  </div>
  <div id="tabs_buttons" style="padding-right:15px;">
    <a href="#" id="clear_tab" class="easyui-linkbutton" iconCls="icon-clear" style="width:90px">重設</a>
    <a href="#" id="save_tab" class="easyui-linkbutton" iconCls="icon-ok" style="width:90px">確定</a>
  </div>
</div>
<script>
  $(function(){
    //頁籤 tabs
    $('#tabs').datagrid({
      columns:[[
        {field:'id',title:'id',sortable:true},
        {field:'tab_name',title:'頁籤名稱',sortable:true},
        {field:'tab_label',title:'頁籤標題',sortable:true},
        {field:'tab_link',title:'頁籤連結',sortable:true},
        {field:'tab_level',title:'頁籤層次',sortable:true},
        {field:'tab_tip',title:'頁籤提示',sortable:true},
        {field:'tab_order',title:'頁籤順序',sortable:true}
        ]],
      url:"apps/STOCK.php",
      queryParams:{op:"list_tabs"},
      fitColumns:true,
      singleSelect:true,
      pagination:true,
      pageSize:10,
      rownumbers:true
      });
    $("#tab_level").numberspinner({
      min:1,
      max:9,
      increment:1,
      value:"1",
      required:true,
      missingMessage:'此欄位為必填'
      });
    $("#tab_order").numberspinner({
      min:1,
      max:100,
      increment:1,
      value:"1",
      required:true,
      missingMessage:'此欄位為必填'
      });
    $("#clear_tab").bind("click",function(){
      $("#tabs_form")[0].reset();
      });
    $("#save_tab").bind("click",function(){
      var op=$("#tab_op").val();
      var id=$("#tab_id").val();
      $("#tabs_form").form("submit",{
        url:"apps/STOCK.php",
        method:"post",
        queryParams:{op:op,id:id},
        success:function(data){
          var data=eval('(' + data + ')');
          $("#tabs_dialog").dialog("close");
          if (data.status==="success") {
            $("#tabs").datagrid("reload",{op:"list_tabs"});
            }
          else {$.messager.alert("訊息",data.msg,"error");}          
          }
        });
      });
    $("#add_tab").bind("click",function(){
      $("#tabs_dialog").dialog("open").dialog("setTitle","新增頁籤");
      $("#tabs_form").form("clear");
      $("#tab_op").val("add_tab");
      });
    $("#edit_tab").bind("click",function(){
      var row=$("#tabs").datagrid("getSelected");
      if (row) {
        $("#tabs_dialog").dialog("open").dialog("setTitle","編輯頁籤");
        $("#tabs_form").form("load",row);
        }
      $("#tab_op").val("update_tab");
      $("#tab_id").val(row.id);
      });
    $("#remove_tab").bind("click",function(){
      var row=$("#tabs").datagrid("getSelected");
      if (row) {
        $.messager.confirm("確認","確定要刪除這個頁籤嗎?",function(btn){
          if (btn){
            var params={op:"remove_tab",id:row.id};
            var callback=function(data){
              if (data.status==="success"){
                $("#tabs").datagrid("reload",{op:"list_tabs"});
                }
              else {$.messager.alert("訊息","刪除頁籤失敗!","error");}            
              };                
            $.post("apps/STOCK.php",params,callback,"json");
            }
          })
        }
      });
    $("#reload_tabs").bind("click",function(){
      $("#tabs").datagrid("load",{op:"list_tabs"});
      });
    });
</script>
<?php
    break;
    }
  case "list_tabs" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $sort=isset($_REQUEST['sort']) ? $_REQUEST['sort'] : 'id';
    $order=isset($_REQUEST['order']) ? $_REQUEST['order'] : 'asc';
    if (isset($_REQUEST['search_field'])) { //有 search
      $where="WHERE ".$_REQUEST['search_field']." LIKE '%".
             $_REQUEST['search_what']."%'";
      }
    else {$where="";} //無 search
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    $SQL="SELECT COUNT(*) FROM `tabs`";
    $RS=run_sql($SQL);
    $total=$RS[0][0]; //紀錄總筆數
    $SQL="SELECT * FROM tabs ".$where." ORDER BY ".
         $sort." ".$order." LIMIT ".$start.",".$rows; 
    $RS=run_sql($SQL);
    $rows=Array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
        $rows[$i]=Array("id" => $RS[$i]["id"],
                        "tab_name" => $RS[$i]["tab_name"],
                        "tab_label" => $RS[$i]["tab_label"],
                        "tab_link" => $RS[$i]["tab_link"],
                        "tab_level" => $RS[$i]["tab_level"],
                        "tab_tip" => $RS[$i]["tab_tip"],
                        "tab_order" => $RS[$i]["tab_order"]
                        );
        }
      }
    $arr=array("total" => $total, "rows" => $rows);
    echo json_encode($arr);
    break;
    }  
  case "add_tab" : {
    $data_array["tab_name"]=$_REQUEST["tab_name"];
    $data_array["tab_label"]=$_REQUEST["tab_label"];
    $data_array["tab_link"]=$_REQUEST["tab_link"];
    $data_array["tab_level"]=$_REQUEST["tab_level"];
    $data_array["tab_tip"]=$_REQUEST["tab_tip"];
    $data_array["tab_order"]=$_REQUEST["tab_order"];
    $result=insert("tabs", $data_array);
    if ($result===TRUE) {
      $status="success";
      $msg="ok";
      }
    else {
      $status="failure";
      $msg="資料新增錯誤!";
      }
    $arr["status"]=$status;
    $arr["msg"]=$msg;
    echo json_encode($arr);
    break;
    }    
  case "update_tab" : {
    $id=$_REQUEST["id"];
    $data_array["tab_name"]=$_REQUEST["tab_name"];
    $data_array["tab_label"]=$_REQUEST["tab_label"];
    $data_array["tab_link"]=$_REQUEST["tab_link"];
    $data_array["tab_level"]=$_REQUEST["tab_level"];
    $data_array["tab_tip"]=$_REQUEST["tab_tip"];
    $data_array["tab_order"]=$_REQUEST["tab_order"];
    $result=update("tabs", $data_array, "id", $id);
    if ($result===TRUE) {
      $status="success";
      $msg="ok";
      }
    else {
      $status="failure";
      $msg="資料更新錯誤!";
      }
    $arr["status"]=$status;
    $arr["msg"]=$msg;
    echo json_encode($arr);
    break;
    }
  case "remove_tab" : {
    $id=$_REQUEST["id"];
    $result=delete_record("tabs", "id", $id);
    if ($result===TRUE) {$status="success";}
    else {$status="failure";}
    $arr["status"]=$status;
    echo json_encode($arr);
    break;
    }
  default : { 
    echo "The time is ".date("Y-m-d H:i:s"); 
    } //default
  } //switch
?>