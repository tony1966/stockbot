<?php
define('MYSQL_ADDRESS','mysql.1freehosting.com');
define('MYSQL_USERNAME','u818828578_stock');
define('MYSQL_PASSWORD','u818828578_stock');
define('DATABASE','a5572056');
?>