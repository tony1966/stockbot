<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>擷取 2330.tw 現金流量表</title>
</head>
<body>
<P>擷取 2330.tw 現金流量表</P>
<?php
/*-----------------------------------------------------------------------------
用途 : 擷取 2330.tw 現金流量表
作者 : 黃耀煌
日期 : 2013-07-15 
說明 : 擷取 2330.tw 現金流量表 http://2330.tw/Stock_Cash.aspx?id=2330
       擷取以下資訊存入 stocks_list 資料表 :
       最近 8 年自由現金流量 (營運現金+投資現金) -> 計算市值淨值比  
注意 : 擷取目標為年報, 下面實際抓到的資料單位是千, 但網頁顯示單位為億,
       即往左再取五位, 每一列對應網頁的一欄, 
       擷取對象 :
       本期淨利 :(計算自由現金流量占淨利比, 每欄第一個數字) 
       營業活動之現金流量 : 第二個
       投資活動之現金流量 : 第三個
       取得數據須再除以 100000 轉成以億為單位. 
       <div id="history"> 
       165964000,289064000,-273196000,-13811000,-62000,143411000,2012|
       134201000,247587000,-182523000,-67858000,-4415000,143472000,2011|
       161605009,229475766,-202086182,-48637706,-23389386,147886955,2010|
       ....
       </div>
-----------------------------------------------------------------------------*/
#設定時區以使 cron_log 紀錄台灣時間
@ini_set('date.timezone','ASIA/Taipei');  //不一定有效
@ini_set("max_execution_time","120");     //不一定有效
date_default_timezone_set("Asia/Taipei"); 
echo date_default_timezone_get()."<br>";
$start_time=time(); //開始處理時間
//載入 webbot 函式庫
include_once("../db.php");           //匯入資料庫設定檔 (必須)
include_once("../lib/mysql.php");    //匯入資料庫模組   (必須)
include_once("../lib/parse.php");    //匯入剖析模組     (必須)
include_once("../lib/http.php");     //匯入http模組     (必須)
//取得 stock_settings 設定
$RS=search("stock_settings");
$pointer=$RS[0]["cash_pointer_2330"]; //目前指標
$offset=$RS[0]["cash_offset_2330"];   //下載股數
echo "目前指標 $pointer<br>";
echo "下載股數 $offset<br>";
//計算有基本資料之總筆數(非 0XXX)
$SQL="SELECT `stock_id` FROM `stocks_list` WHERE NOT `stock_id` LIKE '0%'";
$RS=run_sql($SQL);
if (count($RS)==0) { //若 stock_list 資料表還是空的, 先去擷取收盤資料
    header('Location: fetch_twse_daily_close.php');
    } //end of if
echo "stocks_list 之總筆數 : ".count($RS)."<br>";
if ($pointer > count($RS)-1) {$pointer=0;} //超過最後一筆指標歸零
//搜尋本次要下載的股號
if (empty($_REQUEST["id"])) { //工作模式 (url 沒有傳入 id 參數)
    $SQL="SELECT `stock_id`,`stock_name`,`capital` FROM `stocks_list` ".
         "WHERE NOT `stock_id` LIKE '0%' ORDER BY `stock_id` LIMIT ".
         $pointer.",".$offset;
    } //end of if
else { //測試模式:網址列指定參數xxx.php?id=股號
    $SQL="SELECT `stock_id`,`stock_name`,`capital` FROM `stocks_list` ".
         "WHERE `stock_id`='".$_REQUEST["id"]."'";
    } //end of else
$RS=run_sql($SQL);
$last_stock_id="";
for ($i=0; $i<count($RS); $i++) { //拜訪這一組各股
    //===下載現金流量表年報頁面===
		$target="http://2330.tw/Stock_Cash.aspx?id=".$RS[$i]['stock_id'];
		echo "<a href='$target' target='_blank'>$target ".$RS[$i]['stock_name'].
         "</a><br>";
		$ref="";
		$web_page=http_get($target,$ref);
    //擷取現金流量表年報
		$start='<div id="history">'; //唯一標示開頭
    $end="</div>";
		$data=return_between($web_page['FILE'], $start, $end, EXCL);
		$data=preg_replace("/([\s]{2,})/","",$data); //去除多餘空格 >1
		//echo $data."<br>";
		//擷取近10年現金流量表之淨利,營運與投資現金流量 (現金流量要看長期)
		$arr=explode("|",$data);  //先以管線拆分各季
    $netincome_1Y=0;          //近1年稅後淨利     (億)
    $netincome_3Y=0;          //近3年累積稅後淨利 (億)
    $netincome_5Y=0;          //近5年累積稅後淨利 (億)
    $netincome_8Y=0;          //近8年累積營運現金 (億)
    $operatingcash_1Y=0;      //近1年營運現金     (億)
    $operatingcash_3Y=0;      //近3年累積營運現金 (億)
    $operatingcash_5Y=0;      //近5年累積營運現金 (億)
    $operatingcash_8Y=0;      //近8年累積營運現金 (億)
    $investingcash_1Y=0;      //近1年投資現金     (億)
    $investingcash_3Y=0;      //近3年累積投資現金 (億)
    $investingcash_5Y=0;      //近5年累積投資現金 (億)
    $investingcash_8Y=0;      //近8年累積投資現金 (億)
    $financingcash_1Y=0;      //近1年理財現金     (億)
    $financingcash_3Y=0;      //近3年累積理財現金 (億)
    $financingcash_5Y=0;      //近5年累積理財現金 (億)
    $financingcash_8Y=0;      //近8年累積理財現金 (億)
    $freecash_1Y=0;           //近1年自由現金     (億)
    $freecash_3Y=0;           //近3年累積自由現金 (億)
    $freecash_5Y=0;           //近5年累積自由現金 (億)
    $freecash_8Y=0;           //近8年累積自由現金 (億)
    $freecash_plus_years=0;   //近8年自由現金為正年數
    $type=array();            //儲存近8年現金流型態 A/B/C/D
    $cashflow_type_8A="Y";    //近8年現金流型態 8A
    $cashflow_type_AB="Y";    //近8年現金流型態 AB
    $out='<table border=1><tr><td>年</td><td>稅後淨利(億)</td>'.
         '<td>營運現金(億)</td><td>投資現金(億)</td><td>自由現金(億)</td>'.
         '<td>理財現金(億)</td><td>類型</td><td>營運/淨利(%)</td>'.
         '<td>自由/淨利(%)</td></tr>';
    for ($j=0; $j<8; $j++) { //拜訪前 8 年
         $arr1=explode(",",$arr[$j]);            //以逗號分拆本年現金流量資料
         $net_income=(float)$arr1[0]/100000;     //本期稅後淨利, 單位轉成億
         //計算三項現金流,轉成億
         $operating_cash=(float)$arr1[1]/100000; //營運活動現金, 單位轉成億
         $investing_cash=(float)$arr1[2]/100000; //投資活動現金, 單位轉成億
         $financing_cash=(float)$arr1[3]/100000; //融資活動現金, 單位轉成億
         $free_cash=round($operating_cash + $investing_cash,2); //自由現金流
         if ($j==0) { //近一年現金流量 (雖然意義不大,但為了完整性...)
             $netincome_1Y=$net_income;         //近1年稅後淨利
             $operatingcash_1Y=$operating_cash; //近1年營運現金
             $investingcash_1Y=$investing_cash; //近1年投資現金
             $financingcash_1Y=$financing_cash; //近1年理財現金
             $freecash_1Y=$free_cash;           //近1年理財現金
             } //end of if
         //分辨現金流型態 (三者不會同時為真)
         $typeA=$operating_cash > 0 && $investing_cash < 0 &&
                $financing_cash < 0; //營運成長,財務穩健,適合保守投資人
         $typeB=$operating_cash > 0 && $investing_cash < 0 &&
                $financing_cash > 0; //營運成長,積極投資,適合積極投資人
         $typeC=$operating_cash < 0 && $investing_cash < 0 &&
                $financing_cash > 0; //本業趨緩,積極投資,不適合任何投資人
         if ($typeA) {$type[$j]="A";}    //A類公司值得投資
         else if ($typeB) {              //B類公司小心投資
                  $type[$j]="B";
                  $cashflow_type_8A="N"; //不是 8A 公司
                  } //end of if
         else if ($typeC) {              //C,D類公司:不要投資
                  $type[$j]="C";
                  $cashflow_type_8A="N"; //不是 8A 公司
                  $cashflow_type_AB="N"; //不是 AB 公司
                  } //end of if
         else { //不是 A/B/C 類的公司
               $type[$j]="D";
               $cashflow_type_8A="N";    //不是 8A 公司
               $cashflow_type_AB="N";    //不是 AB 公司         
               }
         //計算淨利含金量:營運現金占稅後淨利比>100%, 自由占比>50%
         if ($net_income > 0) { //可除 (淨利為正才有意義)
             $opcash_netincome_ratio=round($operating_cash/$net_income*100);
             $freecash_netincome_ratio=round($free_cash/$net_income*100);
             } //end of if
         else { //無法計算比值
             $opcash_netincome_ratio=NULL;
             $freecash_netincome_ratio=NULL;
             } //end of else
         //計算累積稅後淨利,營運現金,自由現金
         if ($j < 3) { //近 3 年累計
             $netincome_3Y += $net_income; 
             $investingcash_3Y += $investing_cash;
             $operatingcash_3Y += $operating_cash;
             $financingcash_3Y += $financing_cash;
             $freecash_3Y += $free_cash;
             } //end of if
         if ($j < 5) { //近 5 年累計
             $netincome_5Y += $net_income; 
             $investingcash_5Y += $investing_cash;
             $operatingcash_5Y += $operating_cash;
             $financingcash_5Y += $financing_cash;
             $freecash_5Y += $free_cash;
             } //end of if
         //近8年稅後淨利,營運現金,投資現金,自由現金累計
         $netincome_8Y += $net_income;          //近8年稅後淨利累計
         $operatingcash_8Y += $operating_cash;  //近8年營運現金累計
         $investingcash_8Y += $investing_cash;  //近8年投資現金累計
         $financingcash_8Y += $financing_cash;  //近8年理財現金累計
         $freecash_8Y += $free_cash;
         //計算近8年自由現金為正年數
         if ($free_cash > 0) {++$freecash_plus_years;} 
         //輸出年度資料
         $out .= "<tr><td>前 ".($j+1)." 年</td><td>$net_income</td>".
                 "<td>$operating_cash</td><td>$investing_cash</td>".
                 "<td>$free_cash</td><td>$financing_cash</td>".
                 "<td>$type[$j]</td><td>$opcash_netincome_ratio</td>".
                 "<td>$freecash_netincome_ratio</td></tr>";
         } //end of for  
    $cashflow_type_8Y=join(",",$type); //8年類型合併成字串
    //判斷近3年累積現金類型
    $type_358=array(); //儲存短中長 3,5,8 累積現金類型
    $typeA=$operatingcash_3Y > 0 && $investingcash_3Y < 0 &&
           $financingcash_3Y < 0; //營運成長,財務穩健,適合保守投資人
    $typeB=$operatingcash_3Y > 0 && $investingcash_3Y < 0 &&
           $financingcash_3Y > 0; //營運成長,積極投資,適合積極投資人
    $typeC=$operatingcash_3Y < 0 && $investingcash_3Y < 0 &&
           $financingcash_3Y > 0; //本業趨緩,積極投資,不適合任何投資人
    if ($typeA) {$type_3Y="A";}       //A類公司值得投資
    else if ($typeB) {$type_3Y="B";}  //B類公司小心投資
    else if ($typeC) {$type_3Y="C";}  //C,D類公司不要投資
    else {$type_3Y="D";}
    $type_358[]=$type_3Y; //放入陣列
    //判斷近5年累積現金類型
    $typeA=$operatingcash_5Y > 0 && $investingcash_5Y < 0 &&
           $financingcash_5Y < 0; //營運成長,財務穩健,適合保守投資人
    $typeB=$operatingcash_5Y > 0 && $investingcash_5Y < 0 &&
           $financingcash_5Y > 0; //營運成長,積極投資,適合積極投資人
    $typeC=$operatingcash_5Y < 0 && $investingcash_5Y < 0 &&
           $financingcash_5Y > 0; //本業趨緩,積極投資,不適合任何投資人
    if ($typeA) {$type_5Y="A";}       //A類公司值得投資
    else if ($typeB) {$type_5Y="B";}  //B類公司小心投資
    else if ($typeC) {$type_5Y="C";}  //C,D類公司不要投資
    else {$type_5Y="D";}
    $type_358[]=$type_5Y; //放入陣列
    //判斷近8年累積現金類型
    $typeA=$operatingcash_8Y > 0 && $investingcash_8Y < 0 &&
           $financingcash_8Y < 0; //營運成長,財務穩健,適合保守投資人
    $typeB=$operatingcash_8Y > 0 && $investingcash_8Y < 0 &&
           $financingcash_8Y > 0; //營運成長,積極投資,適合積極投資人
    $typeC=$operatingcash_8Y < 0 && $investingcash_8Y < 0 &&
           $financingcash_8Y > 0; //本業趨緩,積極投資,不適合任何投資人
    if ($typeA) {$type_8Y="A";}       //A類公司值得投資
    else if ($typeB) {$type_8Y="B";}  //B類公司小心投資
    else if ($typeC) {$type_8Y="C";}  //C,D類公司不要投資
    else {$type_8Y="D";}
    $type_358[]=$type_8Y; //放入陣列
    //計算近1年營運現金,自由現金占稅後淨利比 (>100%,>50%)
    if ($netincome_1Y > 0) { //可除 (淨利為正才有意義)
        $opcash_netincome_ratio_1Y=round($operatingcash_1Y/$netincome_1Y*100);
        $freecash_netincome_ratio_1Y=round($freecash_1Y/$netincome_1Y*100);
        } //end of if
    else { //不可除
        $opcash_netincome_ratio_1Y=NULL;
        $freecash_netincome_ratio_1Y=NULL;
        } //end of else
    //計算近3年營運現金,自由現金占稅後淨利比 (>100%,>50%)
    if ($netincome_3Y > 0) { //可除 (淨利為正才有意義)
        $opcash_netincome_ratio_3Y=round($operatingcash_3Y/$netincome_3Y*100);
        $freecash_netincome_ratio_3Y=round($freecash_3Y/$netincome_3Y*100);
        } //end of if
    else { //不可除
        $opcash_netincome_ratio_3Y=NULL;
        $freecash_netincome_ratio_3Y=NULL;
        } //end of else
    //計算近5年營運現金,自由現金占稅後淨利比 (>100%,>50%)
    if ($netincome_5Y > 0) { //可除 (淨利為正才有意義)
        $opcash_netincome_ratio_5Y=round($operatingcash_5Y/$netincome_5Y*100);
        $freecash_netincome_ratio_5Y=round($freecash_5Y/$netincome_5Y*100);
        } //end of if
    else { //不可除
        $opcash_netincome_ratio_5Y=NULL;
        $freecash_netincome_ratio_5Y=NULL;
        } //end of else
    //計算近8年營運現金,自由現金占稅後淨利比 (>100%,>50%)
    if ($netincome_8Y > 0) { //可除 (淨利為正才有意義)       
        $opcash_netincome_ratio_8Y=round($operatingcash_8Y/$netincome_8Y*100);
        $freecash_netincome_ratio_8Y=round($freecash_8Y/$netincome_8Y*100);
        } //end of if
    else { //不可除
        $opcash_netincome_ratio_8Y=NULL;
        $freecash_netincome_ratio_8Y=NULL;
        } //end of else
    $cashflow_type_358=join(",",$type_358); //3,5,8年類型合併字串
    //計算近1,3,5,8年累積自由現金占股本比 (賺/燒掉幾個股本)
    $capital=$RS[$i]['capital'];
    if ($capital != 0 && $capital != NULL) { //可除
        $freecash_capital_ratio_1Y=round($freecash_1Y/$capital,2);
        $freecash_capital_ratio_3Y=round($freecash_3Y/$capital,2);
        $freecash_capital_ratio_5Y=round($freecash_5Y/$capital,2);
        $freecash_capital_ratio_8Y=round($freecash_8Y/$capital,2);
        } //end of if
    else { //不可除
        $freecash_capital_ratio_1Y=NULL;
        $freecash_capital_ratio_3Y=NULL;
        $freecash_capital_ratio_5Y=NULL;
        $freecash_capital_ratio_8Y=NULL;        
        }
    $out .= "<tr><td>近3年合計</td><td>$netincome_3Y</td>".
            "<td>$operatingcash_3Y</td><td>$investingcash_3Y</td>".
            "<td>$freecash_3Y</td><td>$financingcash_3Y</td>".
            "<td>$type_3Y</td><td>$opcash_netincome_ratio_3Y</td>".
            "<td>$freecash_netincome_ratio_3Y</td></tr>";
    $out .= "<tr><td>近5年合計</td><td>$netincome_5Y</td>".
            "<td>$operatingcash_5Y</td><td>$investingcash_5Y</td>".
            "<td>$freecash_5Y</td><td>$financingcash_5Y</td>".
            "<td>$type_5Y</td><td>$opcash_netincome_ratio_5Y</td>".
            "<td>$freecash_netincome_ratio_5Y</td></tr>";
    $out .= "<tr><td>近8年合計</td><td>$netincome_8Y</td>".
            "<td>$operatingcash_8Y</td><td>$investingcash_8Y</td>".
            "<td>$freecash_8Y</td><td>$financingcash_8Y</td>".
            "<td>$type_8Y</td><td>$opcash_netincome_ratio_8Y</td>".
            "<td>$freecash_netincome_ratio_8Y</td></tr>";
    echo $out."</table>";
    echo "自由現金占股本比: ".
         "近1年=$freecash_capital_ratio_1Y ".
         "近3年=$freecash_capital_ratio_3Y ".
         "近5年=$freecash_capital_ratio_5Y ".
         "近8年=$freecash_capital_ratio_8Y ".
         "(股本=".$capital."億)<br>";
    echo "近8年現金流量類型=$cashflow_type_8Y ".
         "是否為8A類型公司=$cashflow_type_8A ".
         "是否為A/B類型公司=$cashflow_type_AB<br>";
    echo "短中長期3,5,8年累積現金流量類型=".$cashflow_type_358."<br>";
    echo "近8年自由現金為正年數=".$freecash_plus_years." (年)<br><br>";
    //更新 stocks_list 資料表
    $data_array=null;  //清空陣列
    $data_array["freecash_1Y"]=$freecash_1Y; //近1年自由現金 (億)
    $data_array["freecash_3Y"]=$freecash_3Y; //近3年累積自由現金 (億)
    $data_array["freecash_5Y"]=$freecash_5Y; //近5年累積自由現金 (億)
    $data_array["freecash_8Y"]=$freecash_8Y; //近8年累積自由現金 (億)
    //含金量1:營運現金占稅後淨利比
    $data_array["opcash_netincome_ratio_1Y"]=$opcash_netincome_ratio_1Y; 
    $data_array["opcash_netincome_ratio_3Y"]=$opcash_netincome_ratio_3Y; 
    $data_array["opcash_netincome_ratio_5Y"]=$opcash_netincome_ratio_5Y; 
    $data_array["opcash_netincome_ratio_8Y"]=$opcash_netincome_ratio_8Y;
    //含金量2:自由現金占稅後淨利比
    $data_array["freecash_netincome_ratio_1Y"]=$freecash_netincome_ratio_1Y; 
    $data_array["freecash_netincome_ratio_3Y"]=$freecash_netincome_ratio_3Y; 
    $data_array["freecash_netincome_ratio_5Y"]=$freecash_netincome_ratio_5Y; 
    $data_array["freecash_netincome_ratio_8Y"]=$freecash_netincome_ratio_8Y;
    //累積自由現金占股本比 (賺/燒掉幾個股本)
    $data_array["freecash_capital_ratio_1Y"]=$freecash_capital_ratio_1Y; 
    $data_array["freecash_capital_ratio_3Y"]=$freecash_capital_ratio_3Y; 
    $data_array["freecash_capital_ratio_5Y"]=$freecash_capital_ratio_5Y; 
    $data_array["freecash_capital_ratio_8Y"]=$freecash_capital_ratio_8Y;
    $data_array["freecash_plus_years"]=$freecash_plus_years; //8年中為正年數 
    //8年類型以逗號串成字串A,A,B,A,A,C... (第一個為近一年)
    $data_array["cashflow_type_8Y"]=$cashflow_type_8Y; //8年類型合併成字串
    $data_array["cashflow_type_8A"]=$cashflow_type_8A; //8年都是A類:Y/N
    $data_array["cashflow_type_AB"]=$cashflow_type_AB; //8年都是A/B類:Y/N
    $data_array["cashflow_type_358"]=$cashflow_type_358; //3,5,8年類型合併字串
    $data_array["cashflow_update"]=date("Y-m-d H:i:s");
    update("stocks_list", $data_array, "stock_id", $RS[$i]['stock_id']); 
		$last_stock_id=$RS[$i]['stock_id']; //更新最後一個 stock_id
    } //end of for
$remark="OK (pointer=$pointer, last stock_id=".$last_stock_id.")";
//更新指標值
$data_array=null;  //清空陣列
$data_array["cash_pointer_2330"]=$pointer + $offset; 
update_all("stock_settings", $data_array);
//計算執行時間
$end_time=time();
$elapsed=$end_time-$start_time;
//新增 cron_log 資料表
$data_array=null;  //清空陣列
$data_array["date_time"]=date("Y-m-d H:i:s");
$data_array["program_name"]=pathinfo(__FILE__, PATHINFO_BASENAME);
$data_array["cron_type"]="download";
$data_array["elapsed"]=$elapsed;
$data_array["remark"]=$remark;
insert("cron_log", $data_array); //存入資料庫
$RS=null;
echo "<br>處理時間 :".$elapsed." 秒";
?>
</body>
</html>