<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>擷取證交所網站之每日收盤行情</title>
</head>
<body>
<?php
/*-----------------------------------------------------------------------------
用途 : 擷取證交所網站之每日收盤行情
作者 : 黃耀煌
日期 : 2011-12-05, 更新 2012-10-26, 2013-06-12, 2015-01-31 
說明 : 擷取證交所網站之每日收盤行情 -> 存入資料庫 (更新資料表 z0000&stock_list)
       主要分為大盤 (漲跌家數比) 與個股 (成交量週轉率&本益比) 兩大部分
       證交所網站 : http://www.twse.com.tw/ch/index.php
       交易資訊 -> 盤後資訊 -> 每日收盤行情 (每個交易日 14:00 後公布)
       網址格式 :
       http://www.twse.com.tw/ch/trading/exchange/MI_INDEX/genpage/
       Report201111/A11220111125ALLBUT0999_1.php?select2=ALLBUT0999&
       chk_date=100/11/25
       ** 為了避免被免費網站因資料表過多停權, 停止紀錄個股每日交易紀錄,(只有
       大盤每日收盤指數紀錄於單獨之 z0000), 個股僅將擷取之收盤價,成交值,漲跌,
       漲跌幅,本益比, 及計算之峰谷值等改紀錄於 stocks_list 內.
-----------------------------------------------------------------------------*/
#設定時區以使 cron_log 紀錄台灣時間
@ini_set('date.timezone','ASIA/Taipei');  //不一定有效
@ini_set("max_execution_time","120");     //不一定有效
date_default_timezone_set("Asia/Taipei"); 
echo date_default_timezone_get()."<br>";
$start_time=time(); //開始處理時間
//匯入函式庫
include_once("../db.php");             //匯入資料庫設定檔 (必須)
include_once("../lib/mysql.php");      //匯入資料庫模組   (必須)
include_once("../lib/parse.php");      //匯入剖析模組     (必須)
include_once("../lib/http.php");       //匯入http模組     (必須)
//讀取 stock_settings 
$RS=search("stock_settings");
$test_mode=$RS[0]["test_mode"];        //"Y"=測試模式 (測試用)
$test_date=$RS[0]["test_date"];        //"Y"=測試日期 (測試用)
//製作擷取目標網頁網址 (證交所網站之每日收盤行情)
$today=date("Y-m-d");  //今日日期, 格式:2013-06-21
if ($test_mode=="Y") { //測試模式時, 竄改 $today
    list($Y,$M,$D)=explode("-", $test_date); //分出年月日
    $test_date=mktime(0,0,0,$M,$D,$Y); //時分秒月日年
    $today=date("Y-m-d",$test_date); //覆蓋 $today, 擷取測試日期之報告
    } //end of if
list($Y,$M,$D)=explode("-", $today);  //拆成陣列以便製作超連結
//$target="http://www.twse.com.tw/ch/trading/exchange/MI_INDEX/genpage/".
        //"Report".$Y.$M."/A112".$Y.$M.$D."ALLBUT0999_1.php?select2=".
        //"ALLBUT0999&chk_date=".($Y-1911)."/".$M."/".$D;
//新網頁 (格式不同 : UTF-8)
$target="http://www.twse.com.tw/ch/trading/exchange/MI_INDEX/MI_INDEX.php".
        "?download=&selectType=ALLBUT0999&qdate=".($Y-1911)."/".$M."/".$D;
//以下為實際交易日之 URL 樣本(測試用)
/*$target="http://www.twse.com.tw/ch/trading/exchange/MI_INDEX/genpage/".
        "Report201501/A11220150129ALLBUT0999_1.php?select2=".
        "ALLBUT0999&chk_date=104/01/29";*/

echo $target."<br>";
echo "<a href='$target' target='_blank'>原始網頁</a><br>";
$ref=$target;  //HTTP Header 中的 referer (連結要求之來源網址, 偽裝用)
//擷取目標網頁
$web_page=http_get($target,$ref);  //下載網頁檔 (非交易日=404無檔案)
//$file=iconv("BIG5","UTF-8",$web_page['FILE']);  //轉成 utf-8 格式
$file=$web_page['FILE'];  
//擷取表頭之交易日期
$start="<td colspan='5'>";  //起始字串
$end="大盤統計資訊</td>";   //結束字串
$trade_date_title=return_between($file, $start, $end, EXCL);
echo $trade_date_title."<br>"; //"2015年01月29日"
//改為 YYYY-MM-DD 
$trade_date=str_replace("年","-",$trade_date_title);  //年改為 "-"
$trade_date=str_replace("月","-",$trade_date);        //月改為 "-"
$trade_date=preg_replace("/[^0-9-]/","",$trade_date); //除去其餘中文部分
echo $trade_date."<br>";  
//開始剖析網頁內容
if ($trade_date != "1911") {  //非交易日無檔案(404 page not found),日期=1911
    //1.先處理大盤部分
    $start="發行量加權股價指數</td>";
    $end="</tr>";
    $TAIEX=return_between($file, $start, $end, EXCL);
    //清除表格標籤, 剩下 <td></td>
    $TAIEX=preg_replace("/[\s]{2,}/","",$TAIEX); //去除 2 個以上空格
    $TAIEX=str_replace(" style='text-align:left;'", "", $TAIEX);  //去除 style
    $TAIEX=str_replace(" style='text-align:right;'", "", $TAIEX); //去除 style
    $TAIEX=str_replace('<font color="#009900">', "", $TAIEX);     //去除 font
    $TAIEX=str_replace('</font>', "", $TAIEX);                    //去除 font
    $arr=parse_array($TAIEX, "<td", "/td>"); //拆出每一欄 (頭尾 td 還在)
    foreach ($arr as $k => $v) {             //拜訪每一欄
             $tmp=str_replace("<td>", "", $v);         //去除 <td>
             $arr[$k]=str_replace("</td>", "", $tmp);  //去除 </td>
             //echo "$k : ".$arr[$k]."<br>";
             } //end of foreach
    $close=str_replace(",", "", $arr[0]);    //去除收盤指數可能之逗號
    $taiex_close=round($close,0);            //取整數
    $delta=str_replace(",", "", $arr[2]);    //去除可能之逗號
    if ($arr[1]=="－") {$delta=0-(float)$delta;}
    else {$delta=(float)$delta;}
    $delta_percent=(float)$arr[3];
    $arr=null;
    echo "收盤=$close 漲跌=$delta 百分比=$delta_percent<br>";
    echo "<table border=1><tr>".$TAIEX."</tr></table>";
    //擷取一般股票成交量資訊 (單位:元)
    $start="一般股票</td>";
    $end="</td>";
    $volumn=return_between($file, $start, $end, EXCL);
    $volumn=remove($volumn, "<td", ">");           //去除 <td ...>
    $volumn=str_replace(",", "", $volumn);         //去除逗號
    $taiex_volumn=round($volumn/100000000,0);      //(億) 紀錄成交量記錄於 cron_log
    echo "成交量 $taiex_volumn (億)<br>";
    //擷取漲家數跌家數平家數資訊 
    $start="<td colspan='2'>股票</td>"; //取出內容部份之 <tr></tr>
    $end="</tbody>";
    $RF=return_between($file, $start, $end, EXCL);
    $RF=preg_replace("/[\s]{2,}/","",$RF); //去除 2 個以上空格
    $RF=remove($RF, "</tr", "tbody>");     //去除 <tr 前殘餘
    $RF=remove($RF, " style='", "'");      //去除 style 屬性
    $RF=str_replace(" colspan='2'", "", $RF);;  //去除 colspan 屬性
    $arr=parse_array($RF, "<tr", "/tr>");  //拆分每一列
    $start="<td>";  //取出每一列之 <td></td>
    $end="</td>";
    $brr=Array();  //用來儲存第三欄漲家數跌家數平家數資訊
    for ($i=0; $i<3; $i++) {                      //拜訪前 3 列
         $tmp=str_replace("<tr>", "", $arr[$i]);  //去除 <tr>
         $tmp=str_replace("</tr>", "", $tmp);     //去除 </tr>
         $crr=parse_array($tmp, "<td", "/td>");   //拆分為 3 欄
         $brr[$i]=return_between($crr[2], $start, $end, EXCL); //取出第 3 欄
         } //end of for
    $arr=explode("(", $brr[0]);               //以括號拆分 254(2)
    $rise=(int)str_replace(",", "", $arr[0]); //漲家數 (括號前面去除逗號) 
    $arr=explode("(", $brr[1]);               //以括號拆分
    $fall=(int)str_replace(",", "", $arr[0]); //跌家數 (括號前面去除逗號)
    $even=(int)str_replace(",", "", $brr[2]); //平家數 (括號前面去除逗號)
    if ($fall != 0) {$rise_fall_ratio=round($rise/$fall,2);}
    else {$rise_fall_ratio=0;} //漲跌家數比:取小數後兩位
    $arr=null;$brr=null;$crr=null;
    echo "漲家數=$rise 跌家數=$fall 平家數=$even<br>";
    echo "漲跌家數比=$rise_fall_ratio<br>";
    //echo "<table>$RF</table><br>";
    //檢查是否已有大盤資料, 沒有才新增
    $SQL="SELECT * FROM `z0000` WHERE `trade_date`='".$trade_date."'";
    $RS=run_sql($SQL);
    if (sizeof($RS)==0) { //還沒有該日大盤收盤資料=>插入資料表
        $data_array=NULL;   //重設陣列
        $data_array["trade_date"]=$trade_date;
        $data_array["close"]=$close;   //收盤指數
        $data_array["delta"]=$delta;   //漲跌
        $data_array["delta_percent"]=$delta_percent;   //漲跌幅
        $data_array["volumn"]=$volumn; //總成交量 (元)
        $data_array["rise"]=$rise;     //漲家數
        $data_array["fall"]=$fall;     //跌家數
        $data_array["even"]=$even;     //平家數
        $data_array["rise_fall_ratio"]=$rise_fall_ratio;  //漲跌家數比 
        insert("z0000", $data_array); //存入大盤資料表
        } //end of if
    //echo $data_array["trade_date"];
    //2.再處理個股收盤資料 : 擷取上市股票收盤表格內資料
    $start="每日收盤行情(全部(不含權證、牛熊證))";
    $end="</tbody>";
    $data=return_between($file, $start, $end, EXCL);
    //去除多餘的屬性使表格單純化 (剩下 <tr><td></td></tr>)
    $data=preg_replace("/[\s]{2,}/","",$data);  //去除 2 個以上空格
    $data=remove($data, "</span", "/thead>"); //去除 <tbody> 前殘餘
    $data=str_replace("<tbody>", "", $data);  //去除 <tbody>
    $data=str_replace(" style='text-align:left;'", "", $data);  //去除 style
    $data=str_replace(" style='text-align:right;'", "", $data); //去除 style
    $data=str_replace('<font color="#FF3300">', "", $data);     //去除 font
    $data=str_replace('<font color="#009900">', "", $data);     //去除 font
    $data=str_replace('</font>', "", $data);                    //去除 font
    $data=str_replace(",", "", $data);  //刪除可能之逗號 (千位)
    //echo "<table>$data</table><br>";
    //將 stocks_list 之 status 欄位全部預設為 X (已下市), 隨後舊股會被改回 O
    $data_array=NULL;   //重設陣列以免混淆
    $data_array["status"]="X";  //X=已下市
    update_all("stocks_list", $data_array);
    //拆分表格的每一列 (一列=一支股票)
    $data_array=NULL;   //重設陣列以免影響後面
    $arr1=parse_array($data, "<tr>", "</tr>"); 
    $companies=count($arr1);  //紀錄上市公司數目
    $new_stocks=0;
    foreach ($arr1 as $k => $v) {  //拜訪每一列 (每一支股票)
      //拆分每一欄資料
      $arr2=parse_array($v, "<td>", "</td>");
      $stock_id=return_between($arr2[0], "<td>", "</td>", EXCL);
      //$stock_table="z".$stock_id;  //不再記錄各股每日收盤資料於單獨資料表
      $stock_name=return_between($arr2[1], "<td>", "</td>", EXCL); //股名
      $shares=return_between($arr2[2], "<td>", "</td>", EXCL);     //成交股數
      $volumn=return_between($arr2[4], "<td>", "</td>", EXCL);     //成交量
      $open=return_between($arr2[5], "<td>", "</td>", EXCL);       //開盤價
      $high=return_between($arr2[6], "<td>", "</td>", EXCL);       //最高價
      $low=return_between($arr2[7], "<td>", "</td>", EXCL);        //最低價
      $close=return_between($arr2[8], "<td>", "</td>", EXCL);      //收盤價
      $rise_fall=return_between($arr2[9], "<td>", "</td>", EXCL);  //漲跌符
      $delta=return_between($arr2[10], "<td>", "</td>", EXCL);     //漲跌幅(正)
      $PER=return_between($arr2[15], "<td>", "</td>", EXCL);       //本益比
      //依據漲跌符號 $delta (+/-) 還原漲跌幅之正負值
      if ($rise_fall=="－") {$delta=0-(float)$delta;}  //跌時為負
      else {$delta=(float)$delta;}  //漲時為正
      //計算今日峰谷值
      if ($delta > 0) {$PV_today="1";}  //漲為 1
      else {$PV_today="0";}  //跌與平為 0
      //計算漲跌幅百分比
      $close=(float)$close;  //收盤價
      $yesterday=$close + $delta;  //反推昨日收盤價
      if ($yesterday != 0) { //防止除以 0
          $delta_percent=round($delta*100/$yesterday,2); 
          } //end of if
      else {$delta_percent=0;}
      //檢查該股資料表是否存在, 否則新增該股紀錄
      $SQL="SELECT * FROM `stocks_list` WHERE `stock_id`='".$stock_id."'";
      $RS=run_sql($SQL);
      if (sizeof($RS)==0) { //不存在 : 新股 
        //計算 PV 值
        $PV=base_convert($PV_today,2,16);  //0/1 轉成 16 進位
        //在 stock_list 資料表中新增該新股
        $SQL="INSERT INTO `stocks_list` (`stock_id`, `stock_name`, `close`,".
             " `delta`, `delta_percent`, `volumn`, `PER1`, `turnover`,".
             " `category`, `PV`, `remark`, `status`) VALUES".
             "('$stock_id', '$stock_name', $close, $delta, $delta_percent, ".
             "$volumn, $PER, 0, '', $PV, '', 'N')";
        run_sql($SQL);
        ++$new_stocks;
        echo "新上市股 : $stock_id $stock_name<br>";
        } //end of if
      else { //stocks_list 中已有此股票: //更新當日收盤價等資料
        //計算週轉率
        $volumn=(float)$volumn;
        if ($RS["capital"]==0) {$turnover=0;} //股本=0, 無法計算週轉率
        else { //已有股本資料才能計算週轉率
          //因股本單位是億, 而成交值為元, 故股本要乘上 1 億
          $turnover=$volumn/($RS["capital"]*100000000);  
          }  
        //更新峰谷值
        $PV=base_convert($RS["PV"],16,2);  //轉成 2 進位
        $PV=$PV.$PV_today;  //串在後面
        $PV=base_convert($PV,2,16);  //轉回 16 進位
        //更新 stocks_list 之當日收盤相關欄位 
        $data_array=NULL;   //重設陣列
        $data_array["close"]=$close;  //更新收盤價
        $data_array["delta"]=$delta;  //更新漲跌(元)
        $data_array["delta_percent"]=$delta_percent;  //更新漲跌幅(%)
        $data_array["volumn"]=$volumn;  //更新成交量(元)
        $data_array["PER1"]=$PER;  //更新本益比
        $data_array["turnover"]=$turnover;  //更新成交量週轉率
        $data_array["PV"]=$PV;  //更新峰谷值
        $data_array["status"]="O";   //更新狀態為 O=舊股 
        update("stocks_list", $data_array, "stock_id", $stock_id); 
        } //end of else
      //紀錄台灣 50 每日收盤資料
      //echo $trade_date."<br>";
      if ($stock_id=="0050") { //台灣 50
        $RS=search("z0050", "trade_date", $trade_date); //查詢該日已有資料?
        if (sizeof($RS)==0) { //該日尚無資料:新增
            echo "no data";
            $volumn=round($shares/1000);  //成交股數轉為成交張數
            $data_array=null;   //重設陣列
            $data_array["trade_date"]=$trade_date;
            $data_array["close"]=$close;   //收盤價
            $data_array["high"]=$high;     //最高價
            $data_array["low"]=$low;       //最低價
            $data_array["volumn"]=$volumn; //成交量 (張)
            $result=insert("z0050", $data_array);  //存入資料表
            }
        echo "0050 成交張數=".$volumn."<br>";
        }
      if ($stock_id=="0051") { //台灣中型100
        $RS=search("z0051", "trade_date", $trade_date); //查詢該日已有資料?
        if (sizeof($RS)==0) { //該日尚無資料:新增
            $volumn=round($shares/1000);  //成交股數轉為成交張數
            $data_array=null;   //重設陣列
            $data_array["trade_date"]=$trade_date;
            $data_array["close"]=$close;   //收盤價
            $data_array["high"]=$high;     //最高價
            $data_array["low"]=$low;       //最低價
            $data_array["volumn"]=$volumn; //成交量 (張)
            $result=insert("z0051", $data_array);  //存入資料表
            }
        echo "0051 成交張數=".$volumn."<br>";
        }
      if ($stock_id=="0056") { //高股息
        $RS=search("z0056", "trade_date", $trade_date); //查詢該日已有資料?
        if (sizeof($RS)==0) { //該日尚無資料:新增
            $volumn=round($shares/1000);  //成交股數轉為成交張數
            $data_array=null;   //重設陣列
            $data_array["trade_date"]=$trade_date;
            $data_array["close"]=$close;   //收盤價
            $data_array["high"]=$high;     //最高價
            $data_array["low"]=$low;       //最低價
            $data_array["volumn"]=$volumn; //成交量 (張)
            $result=insert("z0056", $data_array);  //存入資料表
            }
        echo "0056 成交張數=".$volumn."<br>";
        }
      $RS=NULL;  //釋放資料集
      } //end of foreach
    if ($new_stocks != 0) {  //有新上市股票 : 加顯示新股支數
      echo "新上市股共 $new_stocks 支<br>";
      $remark="OK ($trade_date 收 $taiex_close 量 $taiex_volumn 億 上市 ".
              "$companies 新股 $new_stocks)";
      } //end of if
    else {  //無新上市股票 : 只顯示
      $remark="OK ($trade_date 收 $taiex_close 量 $taiex_volumn 億 上市 ".
              "$companies)";
      } //end of else
    //更新 settings 之 twse_trade_date 欄位 : 紀錄今日為最近一次的交易日
    $data_array=null;  //清空陣列
    $data_array["twse_trade_date"]=$trade_date; 
    update_all("stock_settings", $data_array);
    } //end of if (交易日) 
else {$remark="非交易日或尚無本日收盤資料";}  //非交易日 $trade_date="1911"
//計算執行時間
$end_time=time();
$elapsed=$end_time-$start_time;
//新增紀錄於 cron_log 資料表
$data_array=NULL;   //重設陣列, 以免混淆
$data_array["date_time"]=date("Y-m-d H:i:s");
$data_array["program_name"]=pathinfo(__FILE__, PATHINFO_BASENAME);
$data_array["cron_type"]="download";
$data_array["elapsed"]=$elapsed;
$data_array["remark"]=$remark;
insert("cron_log", $data_array); //存入資料庫
echo "</table>";
echo "上市公司數目 : ".$companies;
echo "<br>處理時間 : ".$elapsed." 秒";
?>
</body>
</html>