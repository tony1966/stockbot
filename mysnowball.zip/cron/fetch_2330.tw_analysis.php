<?php
/*-----------------------------------------------------------------------------
用途 : 擷取 2330.tw 財務分析
作者 : 黃耀煌
日期 : 2013-08-01, 2015-01-28 修訂 
說明 : 擷取 2330.tw 財務分析表 
       http://2330.tw/Stock_Fina_Q.aspx?id=2330 (季報)
       http://2330.tw/Stock_Fina.aspx?id=2330 (年報)
       擷取以下資訊存入 stocks_list 資料表 :
       1.季存貨周轉率追蹤 (IT 連三季下滑是股價下跌之先行指標)
         存貨周轉率是衡量一家公司存貨品質的最佳指標, 越高越好, 或至少維持穩定.
         若存貨周轉率出現明顯下滑, 通常是損益表出現轉折的先兆, 因需削價競爭打消
         庫存, 從而使未來本業績效營益率下降. 
         見黃國華:財務自由的講堂 p149
       2.季 ART 應收帳款週轉率 Accounts Receivable Turnover(ART):
         資產負債表上會把一家公司卡死的是應收帳款, 可以衡量該公司被掠奪的程度(
         取貨不付款). 
         應收帳款週轉率=銷貨淨額(營收)/平均應收帳款
         應收帳款週轉率的數字高低各行業不同, 但其變化趨勢則是衡量公司財務的指標.
       3.年 ROE 股東權益報酬率追蹤 :
         (1).ROE_5Y_avg : 近 5 年平均 ROE
         (2).ROE_8Y_avg : 近 8 年平均 ROE
         (3).ROE_5Y_CV :  近 5 年平均 ROE 變異係數
         (4).ROE_8Y_CV :  近 8 年平均 ROE 變異係數
         (5).ROE_1Y_GT15 : 近 1 年 ROE > 15 (Y/N)
         (6).ROE_5Y_GT15 : 近 5 年 ROE > 15 (Y/N)
       4.計算存貨營收比 IIR (Inventory Income Ratio)
         利用資產負債表所擷取之近8季存貨(放在 IV_8QS 欄位)損益表所擷取之近8季
         營收(放在 IC_8QS 欄位)相除得到存貨營收比.
         存貨周轉率有個盲點, 它不是用營收來衡量, 而是銷售成本, 應用營收較精準.
         因營收包含成本與損益, 故銷貨毛利越高的公司其存貨營收比越低; 而存貨周轉
         率只是單純的存貨之成本 (銷貨成本) 與存貨之關係而已.
         存貨周轉率見 : fetch_2330.tw_analysis.php (財務分析)
         存貨營收比=當季存貨/當季營收 (本季存貨還要幾季才賣得完)
         存貨營收比越低越好, 但要多低卻沒有一個絕對標準, 只能看相對變化與比較.
         績優股的存貨營收比大都在 0.5 以下, 甚至低到 0.1, 即當季存貨以當季營收
         速度, 不到半季就完銷. 而表現不佳的公司, 其存貨營收比都大於 0.5. 若大於
         1, 表示當季存貨需下一季才能完銷. 
         一家公司存貨營收比逐季逐年下降是好事; 若該產業存貨營收比也是逐季逐年
         下降, 表示該行業處於暢旺之復甦階段.
         IIR: 近8季存貨營收比
         IIR_1Q: 近1季存貨營收比
         IIR_3Q_decrease : 存貨營收比連三季下降 (業績有起色, 看漲).
         IIR_3Q_increase : 存貨營收比連三季上升 (銷貨能力變差, 小心).
         IIR_avg : 近8季存貨營收比平均值.
         IIR_CV : 近8季存貨營收比 CV 值 (看變化程度).
         見黃國華:財務自由的講堂 P157
       5.計算 GVI=(每股淨值/股價)*(1+股東權益報酬率)^5
         GVI=(1+股東權益報酬率)^5/股價淨值比=(1+ROE)^5/PBR
         淨值股價比代表價值性, 而 (1+股東權益報酬率)^5 表示成長性
         ROE 為近一季乘以四得到年 ROE, 淨值亦為近一季每股淨值
         參見財經傳訊出版, 葉怡成著, 誰都學得會超強選股公式 GVI
注意 : ===季報部份===
       擷取存貨周轉率 (索引 1) >0
       <div id="history_fina_oa">
       1.16,2.31,0.28,0.11,78.66,39.50,33.68,84.48,2014-3Q|                       
       1.34,2.38,0.30,0.11,68.10,38.34,32.42,74.02,2014-2Q|                       
       1.11,2.19,0.25,0.09,82.21,41.67,40.70,83.18,2014-1Q|                       
       1.36,2.76,0.30,0.12,67.10,33.06,29.29,70.87,2013-4Q|                       
       1.39,2.34,0.27,0.11,65.65,39.00,33.06,71.59,2013-3Q|                       
       1.48,2.28,0.26,0.10,61.66,40.02,39.30,62.38,2013-2Q|                       
       5.06,2.18,0.22,0.09,18.03,41.86,39.29,20.60,2013-1Q|                       
       1.63,2.90,0.22,0.12,55.98,31.47,28.54,58.91,2012-4Q|                       
       1.72,2.98,0.22,0.12,53.05,30.62,29.44,54.23,2012-3Q|                       
       1.76,2.62,0.21,0.12,51.85,34.83,33.98,52.70,2012-2Q| 
       </div>
       ===年報部份===
       擷取前 8 年 ROE (索引 1) >0
       <div id="history_fina_earn">                    
       0.00,10.24,13.02,19.66,15.31,16.02,2013|                    
       4.61,7.63,8.34,14.82,10.94,10.10,2012|                    
       6.00,10.82,11.59,17.36,13.65,13.95,2011|                    
       6.53,11.87,12.61,18.36,14.74,14.08,2010|                    
       6.79,12.23,13.48,17.90,14.37,14.03,2009|                    
       4.38,6.70,8.25,9.90,6.28,8.38,2008|                    
       7.34,12.37,14.56,20.08,16.82,16.87,2007|                    
       6.53,11.97,13.30,19.31,15.45,14.31,2006|                    
       5.88,11.58,11.81,19.91,16.64,14.66,2005|                    
       4.59,9.19,10.67,21.09,18.04,15.48,2004| 
       </div>
-----------------------------------------------------------------------------*/
#設定時區以使 cron_log 紀錄台灣時間
@ini_set('date.timezone','ASIA/Taipei');  //不一定有效
@ini_set("max_execution_time","120");     //不一定有效
date_default_timezone_set("Asia/Taipei"); 
$start_time=time(); //開始處理時間
//載入 webbot 函式庫
include_once("../db.php");              //匯入資料庫設定檔 (必須)
include_once("../lib/mysql.php");       //匯入資料庫模組   (必須)
include_once("../lib/parse.php");       //匯入剖析模組     (必須)
include_once("../lib/http.php");        //匯入http模組     (必須)
//取得 stock_settings 設定
$RS=search("stock_settings");
$pointer=$RS[0]["analysis_pointer_2330"]; //目前指標
$offset=$RS[0]["analysis_offset_2330"];   //下載股數
//計算有基本資料之總筆數(非 0XXX)
$SQL="SELECT `stock_id` FROM `stocks_list` WHERE NOT `stock_id` LIKE '0%'";
$RS=run_sql($SQL);
if (count($RS)==0) { //若 stock_list 資料表還是空的, 先去擷取收盤資料
    header('Location: fetch_twse_daily_close.php');
    } //end of if
header('Content-Type: text/html;charset=UTF-8');
echo date_default_timezone_get()."<br>";
echo "stocks_list 之總筆數 : ".count($RS)."<br>";
echo "目前指標 $pointer<br>";
echo "下載股數 $offset<br>";
if ($pointer > count($RS)-1) {$pointer=0;} //超過最後一筆指標歸零
//搜尋本次要下載的股號
if (empty($_REQUEST["id"])) { //工作模式 (url 沒有傳入 id 參數)
    $SQL="SELECT `stock_id`,`stock_name`,`market_value`,`equity`,".
         "`IV_8QS`,`IC_8QS`,`PBR` ".
         "FROM `stocks_list` ".
         "WHERE NOT `stock_id` LIKE '0%' ORDER BY `stock_id` LIMIT ".
         $pointer.",".$offset;
    } //end of if
else { //測試模式:網址列指定參數xxx.php?id=股號
    $SQL="SELECT `stock_id`,`stock_name`,`market_value`,`equity`,".
         "`IV_8QS`,`IC_8QS`,`PBR` ".
         "FROM `stocks_list` ".
         "WHERE `stock_id`='".$_REQUEST["id"]."'";
    } //end of else
$RS=run_sql($SQL);
$last_stock_id="";
for ($i=0; $i<count($RS); $i++) { //拜訪這一組各股
    //===1.下載季財務分析頁面===
		$target="http://2330.tw/Stock_Fina_Q.aspx?id=".$RS[$i]['stock_id'];
		echo "<a href='$target' target='_blank'>$target ".$RS[$i]['stock_name'].
         "</a><br>";
		$ref="";
		$web_page=http_get($target,$ref);
    //擷取季存貨周轉率
		$start='<div id="history_fina_oa">'; //唯一標示開頭
    $end="</div>";
		$data=return_between($web_page['FILE'], $start, $end, EXCL);
		$data=preg_replace("/([\s]{2,})/","",$data); //去除多餘空格 >1
		//擷取季存貨周轉率 Inventory turnover IT 
		$arr=explode("|",$data);      //先以管線拆分各年
    $q=count($arr)-1;             //季數 (正常=10),因最後還有一個|,需減1
    $IT=array();                  //儲存近8季 IT 存貨周轉率
    $ART=array();                 //儲存近8季 ART 應收帳款週轉率
    $IT_3Q_decrease="N";          //近3季存貨周轉率下降
    $ART_3Q_decrease="N";         //近3季應收帳款週轉率下降
    $ART_sum=0;                   //近8季應收帳款週轉率總和
    $ART_square=0;                //近8季應收帳款週轉率平方和
    $out='<table border=1><tr><td>項目</td>';  //輸出表格 
    for ($j=0; $j<8; $j++) {      //拜訪近8季
         $brr=explode(",",$arr[$j]); //以逗號分拆本季資料
         $IT[$j]=(float)$brr[1];  //索引 1 為存貨周轉率
         $ART[$j]=(float)$brr[0]; //索引 0 為應收帳款週轉率
         $ART_sum += $ART[$j];    //應收帳款週轉率累計
         $ART_square += pow($ART[$j], 2); //平方和累計(計算標準差用)
         $out .= "<td>前".($j+1)."季</td>";
         }
    //判斷存貨周轉率&應收帳款週轉率連三季遞減
    if ($IT[0]<$IT[1] && $IT[1]<$IT[2]) {$IT_3Q_decrease="Y";}
    if ($ART[0]<$ART[1] && $ART[1]<$ART[2]) {$ART_3Q_decrease="Y";}
    //計算近8季應收帳款週轉率平均值與標準差
    $ART_avg=round($ART_sum/8,2);  //計算8季ART平均值
    $ART_std=sqrt(($ART_square-pow($ART_sum,2)/8)/7); //計算標準差
    //計算近8季應收帳款週轉率變異係數CV=標準差/平均值%
    if($ART_avg != 0) {$ART_CV=round(100*$ART_std/$ART_avg);}
    else {$ART_CV=null;}  //表示極大值
    //輸出結果
    $out .= '</tr>'.
            '<tr><td>存貨周轉率%</td><td>'.join("</td><td>",$IT).'</td></tr>'.
            '<tr><td>應收帳款週轉率%</td><td>'.join("</td><td>",$ART).
            '</td></tr></table>';
    echo $out;
    echo "近8季應收帳款週轉率平均值=$ART_avg% 標準差=$ART_std ".
         "變異係數=$ART_CV%<br>";
    echo "近3季存貨周轉率呈遞減=".$IT_3Q_decrease."<br>";
    echo "近3季應收帳款週轉率呈遞減=".$ART_3Q_decrease."<br><br>";
    //計算存貨營收比 (依據資產負債表之前8季存貨與損益表之前8季營收)
    $IIR=array();               //儲存近8季存貨營收比
    $IIR_1Q=0;                  //近1季存貨營收比
    $IIR_3Q_decrease="N";       //近3季存貨營收比遞降 (銷貨有起色, 看漲)
    $IIR_3Q_increase="N";       //近3季存貨營收比遞升 (銷貨變差, 小心)
    $IIR_sum=0;                 //近8季存貨營收比總和
    $IIR_square=0;              //近8季存貨營收比平方和
    $IV=explode(",",$RS[$i]['IV_8QS']); //以逗號為界拆解近8季存貨
    $IC=explode(",",$RS[$i]['IC_8QS']); //以逗號為界拆解近8季營收
    $out='<table border=1><tr><td>項目</td>';
    for ($j=0; $j<8; $j++) {      //拜訪近8季存貨與營收
         if ($IC[$j] != 0) { 
             $IIR[$j]=round($IV[$j]/$IC[$j],2);
             } 
         else {$IIR[$j]=null;}
         if ($IIR[$j] != null) {
           $IIR_sum += $IIR[$j];
           $IIR_square += pow($IIR[$j], 2); //平方和累計 (計算標準差用)
           }
         if ($j==0) {$IIR_1Q=$IIR[$j];} //紀錄近一季 IIR
         $out .= "<td>前".($j+1)."季</td>";        
         } //for
    //輸出結果
    $out .= "<tr><td>存貨營收比</td><td>".join("</td><td>",$IIR).
            "</td></tr></table>";
    echo $out;
    //判斷近3季存貨營收比是否遞降
    if ($IIR[0]<$IIR[1] && $IIR[1]<$IIR[2]) {$IIR_3Q_decrease="Y";}
    //判斷近3季存貨營收比是否遞升
    if ($IIR[2]<$IIR[1] && $IIR[1]<$IIR[0]) {$IIR_3Q_increase="Y";}
    //計算近8季存貨營收比平均值與標準差
    $IIR_avg=round($IIR_sum/8,2);  //計算8季營益率平均值
    $IIR_std=sqrt(($IIR_square-pow($IIR_sum,2)/8)/7); //計算標準差    
    //計算近8季存貨營收比變異係數 CV=標準差/平均值%
    if($IIR_avg != 0) {$IIR_CV=round(100*$IIR_std/$IIR_avg);}
    else {$IIR_CV=null;}  //表示極大值
    echo "近1季存貨營收比=".$IIR_1Q."<br>";
    echo "近8季存貨營收比平均值=".$IIR_avg." 標準差=".$IIR_std.
         " 變異係數=".$IIR_CV."<br>";
    echo "近3季存貨營收比遞減=".$IIR_3Q_decrease."<br>";
    echo "近3季存貨營收比遞增=".$IIR_3Q_increase."<br>";
    //擷取季獲利能力
		$start='<div id="history_fina_earn">'; //唯一標示開頭
    $end="</div>";
		$data=return_between($web_page['FILE'], $start, $end, EXCL);
		$data=preg_replace("/([\s]{2,})/","",$data); //去除多餘空格 >1
		//擷取最近一季 ROE, 計算 GVI 
		$arr=explode("|",$data);      //先以管線拆分各年
    $ROE_1Q=0;                    //近1季 ROE (百分比%)
    for ($j=0; $j<1; $j++) {      //拜訪近1季獲利能力
         $brr=explode(",",$arr[$j]); //以逗號分拆本季資料
         $ROE_1Q=(float)$brr[1];     //索引1為季ROE       
         } //for
    //計算GVI
    $ROE=min(0.05,$ROE_1Q/100); //單季ROE最高限5% (ROE 可持續性),%轉小數
    $PBR=$RS[$i]['PBR'];
    if ($PBR != 0) {$GVI=round(pow((1+$ROE*4),5)/$PBR,4);} //取小數點後四位
    else {$GVI=0;}
    echo "近1季ROE=".$ROE_1Q." 股價淨值比PBR=".$RS[$i]['PBR'].
         " GVI=".$GVI."<br><br>";
    //更新 stocks_list 資料表
    $data_array=null;  //清空陣列
    $data_array["IT_3Q_decrease"]=$IT_3Q_decrease;   //近3季存貨周轉率下降
    $data_array["ART_3Q_decrease"]=$ART_3Q_decrease; //近3季應收帳款週轉率下降
    $data_array["ART_CV"]=$ART_CV;                   //近8季應收帳款週轉率CV
    $data_array["IIR"]=implode(",",$IIR);            //近3季存貨營收比字串
    $data_array["IIR_1Q"]=$IIR_1Q;                   //近1季存貨營收比
    $data_array["IIR_3Q_decrease"]=$IIR_3Q_decrease; //近8季存貨營收比遞降
    $data_array["IIR_3Q_increase"]=$IIR_3Q_increase; //近8季存貨營收比遞升
    $data_array["IIR_avg"]=$IIR_avg;                 //近8季存貨營收平均值
    $data_array["IIR_CV"]=$IIR_CV;                   //近8季存貨營收變異係數
    $data_array["GVI"]=$GVI;                         //GVI指數
    $data_array["analysis_update"]=date("Y-m-d H:i:s");
    update("stocks_list", $data_array, "stock_id", $RS[$i]['stock_id']); 

    //===2.下載年財務分析頁面===
		$target="http://2330.tw/Stock_Fina.aspx?id=".$RS[$i]['stock_id'];
		echo "<a href='$target' target='_blank'>$target ".$RS[$i]['stock_name'].
         "</a><br>";
		$ref="";
		$web_page=http_get($target,$ref);
    //擷取年ROE數值 
		$start='<div id="history_fina_earn">'; //唯一標示開頭
    $end="</div>";
		$data=return_between($web_page['FILE'], $start, $end, EXCL);
		$data=preg_replace("/([\s]{2,})/","",$data); //去除多餘空格 >1
		//echo $data."<br>";
		//擷取 ROE
		$arr=explode("|",$data);      //先以管線拆分各年
    $q=count($arr)-1;             //年數 (正常=10),因最後還有一個|,需減1
    if ($q >= 8) {$q=8;}          //超過:只抓8年 
    $ROE=array();                 //儲存近 8 年 ROE
    $ROE_5Y_sum=0;                //近 5 年 ROE 總和
    $ROE_8Y_sum=0;                //近 8 年 ROE 總和
    $ROE_5Y_square=0;             //近 5 年 ROE 平方和
    $ROE_8Y_square=0;             //近 8 年 ROE 平方和
    $ROE_1Y_GT15="Y";             //近 1 年 ROE > 15%
    $ROE_5Y_GT15="Y";             //近 5 年 ROE > 15%
    $out='<table border=1><tr><td>項目</td>';
    for ($j=0; $j<$q; $j++) {      //拜訪前 8 年
         $brr=explode(",",$arr[$j]); //以逗號分拆本年資料
         $ROE[$j]=(float)$brr[1];
         if ($j==0 && $ROE[$j] < 15) {$ROE_1Y_GT15="N";} //近1年ROE<15
         if ($j < 5) { //只加前 5 年
           $ROE_5Y_sum += $ROE[$j];
           $ROE_5Y_square += pow($ROE[$j], 2); //平方和累計 (計算標準差用)
           if ($ROE[$j] < 15) {$ROE_5Y_GT15="N";} //近5年ROE沒有都 > 15
           } 
         $ROE_8Y_sum += $ROE[$j]; 
         $ROE_8Y_square += pow($ROE[$j], 2); //平方和累計 (計算標準差用) 
         $out .= "<td>前".($j+1)."年</td>";        
         } //for
    if ($q >= 5) { //5 年以上
      //計算近5年ROE平均值與標準差
      $ROE_5Y_avg=round($ROE_5Y_sum/5,2);  //計算5年ROE平均值
      $ROE_5Y_std=sqrt(($ROE_5Y_square-pow($ROE_5Y_sum,2)/5)/4); //計算標準差 
      //計算近5年ROE變異係數CV=標準差/平均值%
      if($ROE_5Y_avg != 0) {$ROE_5Y_CV=round(100*$ROE_5Y_std/$ROE_5Y_avg);}
      else {$ROE_5Y_CV=9999;}  //表示極大值
      }
    else { //5 年以下,求實際平均
      //計算近$q年ROE平均值與標準差
      if ($q > 1) { //大於 1 項才有標準差
        $ROE_5Y_avg=round($ROE_5Y_sum/$q,2);  //計算$q年ROE平均值
        $ROE_5Y_std=sqrt(($ROE_5Y_square-pow($ROE_5Y_sum,2)/$q)/($q-1)); 
        }
      else {$ROE_5Y_avg=$ROE[0];$ROE_5Y_std=0;}
      //計算近$q年ROE變異係數CV=標準差/平均值%
      if($ROE_5Y_avg != 0) {$ROE_5Y_CV=round(100*$ROE_5Y_std/$ROE_5Y_avg);}
      else {$ROE_5Y_CV=9999;}  //表示極大值
      }
    if ($q >= 8) { //8 年以上
      //計算近8年ROE平均值與標準差
      $ROE_8Y_avg=round($ROE_8Y_sum/8,2);  //計算8年ROE平均值
      $ROE_8Y_std=sqrt(($ROE_8Y_square-pow($ROE_8Y_sum,2)/8)/7); //計算標準差 
      //計算近8年ROE變異係數CV=標準差/平均值%
      if($ROE_8Y_avg != 0) {$ROE_8Y_CV=round(100*$ROE_8Y_std/$ROE_8Y_avg);}
      else {$ROE_8Y_CV=9999;}  //表示極大值
      }
    else { //8 年以下,求實際平均
      //計算近$q年ROE平均值與標準差
      if ($q > 1) { //大於 1 項才有標準差
        $ROE_8Y_avg=round($ROE_8Y_sum/$q,2);  //計算$q年ROE平均值
        $ROE_8Y_std=sqrt(($ROE_8Y_square-pow($ROE_8Y_sum,2)/$q)/($q-1)); 
        }
      else {$ROE_8Y_avg=$ROE[0];$ROE_8Y_std=0;}
      //計算近$q年ROE變異係數CV=標準差/平均值%
      if($ROE_8Y_avg != 0) {$ROE_8Y_CV=round(100*$ROE_8Y_std/$ROE_8Y_avg);}
      else {$ROE_8Y_CV=9999;}  //表示極大值
      }
    //輸出結果
    $out .= "<tr><td>ROE%</td><td>".join("</td><td>",$ROE).
            "</td></tr></table>";
    echo $out;
    echo "近5年ROE平均值=$ROE_5Y_avg% 標準差=$ROE_5Y_std ".
         "變異係數=$ROE_5Y_CV%<br>";
    echo "近8年ROE平均值=$ROE_8Y_avg% 標準差=$ROE_8Y_std ".
         "變異係數=$ROE_8Y_CV%<br>";
    echo "近1年ROE > 15%=".$ROE_1Y_GT15."<br>";
    echo "近5年ROE > 15%=".$ROE_5Y_GT15."<br><br>";

    //更新 stocks_list 資料表
    $data_array=null;  //清空陣列
    $data_array["ROE_5Y_avg"]=$ROE_5Y_avg;       //近5年平均ROE
    $data_array["ROE_8Y_avg"]=$ROE_8Y_avg;       //近8年平均ROE
    $data_array["ROE_5Y_CV"]=$ROE_5Y_CV;         //近5年ROE變異係數
    $data_array["ROE_8Y_CV"]=$ROE_8Y_CV;         //近8年ROE變異係數
    $data_array["ROE_1Y_GT15"]=$ROE_1Y_GT15;     //近1年ROE > 15
    $data_array["ROE_5Y_GT15"]=$ROE_5Y_GT15;     //近5年ROE > 15
    $data_array["analysis_update"]=date("Y-m-d H:i:s");
    update("stocks_list", $data_array, "stock_id", $RS[$i]['stock_id']); 
		$last_stock_id=$RS[$i]['stock_id']; //紀錄最後一個 stock_id
    } //end of for
$remark="OK (pointer=$pointer, last stock_id=".$last_stock_id.")";
//更新指標值
$data_array=null;  //清空陣列
$data_array["analysis_pointer_2330"]=$pointer + $offset; 
update_all("stock_settings", $data_array);
//計算執行時間
$end_time=time();
$elapsed=$end_time-$start_time;
//新增 cron_log 資料表
$data_array=null;  //清空陣列
$data_array["date_time"]=date("Y-m-d H:i:s");
$data_array["program_name"]=pathinfo(__FILE__, PATHINFO_BASENAME);
$data_array["cron_type"]="download";
$data_array["elapsed"]=$elapsed;
$data_array["remark"]=$remark;
insert("cron_log", $data_array); //存入資料庫
$RS=null;
echo "<br>處理時間 :".$elapsed." 秒";
?>