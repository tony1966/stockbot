<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>擷取 2330.tw 個股總覽基本資料-股本,殖利率,本益比,股淨比</title>
</head>
<body>
<?php
/*-----------------------------------------------------------------------------
用途 : 擷取 2330.tw 個股總覽基本資料-股本(億),殖利率,本益比,股淨比
作者 : 黃耀煌
日期 : 2012-02-17, 2013-06-02, 2015-01-28 修訂
說明 : 讀取 http://2330.tw/Stock_Quote.aspx?id=1101
       擷取其中的股本,殖利率,本益比,股淨比資料,上市日期 (計算已上市年數)
       存入 stocks_list 資料表
       2012-03-09 修改, 增加擷取近四季每股盈餘
       2013-07-13 增加 market_value (市值)欄位
       1.刪除市值 50 億元以下者 (流程8)
         市值=股價*股本/10
         見黃國華:財務自由的世界 p210
       2.刪除上市不滿2年者 (流程2)
         見黃國華:財務自由的世界 p204
-----------------------------------------------------------------------------*/
#設定時區以使 cron_log 紀錄台灣時間
@ini_set('date.timezone','ASIA/Taipei');  //不一定有效
@ini_set("max_execution_time","120");     //不一定有效
date_default_timezone_set("Asia/Taipei"); 
echo date_default_timezone_get()."<br>";
$start_time=time(); //開始處理時間
#載入 webbot 函式庫
include_once("../db.php");           //匯入資料庫設定檔 (必須)
include_once("../lib/mysql.php");    //匯入資料庫模組   (必須)
include_once("../lib/parse.php");    //匯入剖析模組     (必須)
include_once("../lib/http.php");     //匯入http模組     (必須)
//取得 stock_settings 設定
$RS=search("stock_settings");
$pointer=$RS[0]["basic_pointer_2330"]; //目前指標
$offset=$RS[0]["basic_offset_2330"];   //下載股數
echo "目前指標 $pointer<br>";
echo "下載股數 $offset<br>";
//計算有基本資料之總筆數(非 0XXX)
$SQL="SELECT `stock_id` FROM `stocks_list` WHERE NOT `stock_id` LIKE '0%'";
$RS=run_sql($SQL);
if (count($RS)==0) { //若 stock_list 資料表還是空的, 先去擷取收盤資料
    header('Location: fetch_twse_daily_close.php');
    } //end of if
echo "stocks_list 之總筆數 : ".count($RS)."<br>";
if ($pointer > count($RS)-1) {$pointer=0;} //超過最後一筆指標歸零
//搜尋本次要下載的股號
if (empty($_REQUEST["id"])) { //工作模式 (url 沒有傳入 id 參數)
    $SQL="SELECT `stock_id`,`stock_name`,`close` FROM `stocks_list` ".
         "WHERE NOT `stock_id` LIKE '0%' ORDER BY `stock_id` LIMIT ".
         $pointer.",".$offset;
    } //end of if
else { //測試模式:網址列指定參數xxx.php?id=股號
    $SQL="SELECT `stock_id`,`stock_name`,`close` FROM `stocks_list` ".
         "WHERE `stock_id`='".$_REQUEST["id"]."'";
    } //end of else
$RS=run_sql($SQL);
$last_stock_id="";
for ($j=0; $j<count($RS); $j++) {  
		$target="http://2330.tw/Stock_Quote.aspx?id=".$RS[$j]['stock_id'];
		echo "<a href='$target' target='_blank'>$target ".$RS[$j]['stock_name']."</a><br>";
		$ref="";
		$web_page=http_get($target,$ref);
		$start='<div class="QuoteLeftQuote">';
		$end="</div>";
		$data=return_between($web_page['FILE'], $start, $end, EXCL);
		$data=preg_replace("/([\s]{2,})/","",$data); //去除多餘空格 >1
		//echo $data;
		//擷取本益比,殖利率,股價淨值比
		$start='淨值比</th></tr><tr>';
		$end="</tr>";
		$data=return_between($data, $start, $end, EXCL); //取出 <tr>...</tr> 之內容
		$data=str_replace(' class="updata"', "", $data); //清除屬性剩下 <td>...</td>*n
		//echo $data."<br>";
		$arr=parse_array($data, "<td", "/td>");  //拆分每一欄
		$start="<td>";   //取出內容部份
		$end="</td>";
		$PER=return_between($arr[5], $start, $end, EXCL); //取出本益比
		$yield=return_between($arr[6], $start, $end, EXCL); //取出殖利率
		$yield=str_replace("%", "", $yield); //去掉 % (存 float)
		$PBR=return_between($arr[7], $start, $end, EXCL); //取出股價淨值比
		echo "本益比 (PER)=$PER<br>";
		echo "殖利率 (yield)=$yield %<br>";
		echo "股價淨值比 (PBR)=$PBR<br>";
		//擷取基本資料 : 股本, 上市時間
		$start='<div class="QuoteRightComBase">';
		$end="</div>";
		$data=return_between($web_page['FILE'], $start, $end, EXCL); //取出div內容
		$data=preg_replace("/([\s]{2,})/","",$data); //去除多餘空格 > 1
		$data=remove($data, "<table", ">"); 
		$data=remove($data, "</table", ">"); //去除table剩下 <tr><td>...</td></tr>
		$data=str_replace(' class="center" colspan="2"', "", $data); //去除 th 屬性
		$data=str_replace(' class="trodd', "", $data);               //去除 tr 屬性
		$data=str_replace(' class="string"', "", $data);             //去除 tr 屬性
    //拆分 5 列 (tr),股本為第 2 列 (索引 1),上市時間為第 4 列
		$arr=parse_array($data, "<tr", "/tr>"); //拆分 5 列 (tr)
    //擷取股本 : 股本在第 2 列第 2 欄
		$brr=parse_array($arr[1], "<td", "/td>");  //股本為第 2 列 (索引 1)
    $capital=preg_replace("/[^0-9.]/","",$brr[1]);  //特殊:去除"億"及空白字元
    echo "股本 $capital 億<br>";
    //擷取上市時間 : 上市時間在第 4 列第 2 欄
		$brr=parse_array($arr[3], "<td", "/td>");  //上市時間在第 4 列
    $listed_date=remove($brr[1], "<td", ">"); //去除 <td ...>
    $listed_date=remove($listed_date, "</td", ">"); //去除 </td>
    //計算已上市年數
    list($Y,$M,$D)=explode("/",$listed_date); //拆分 1987/2/21
    echo "$Y-$M-$D 上市<br>";
    $listed_time=mktime(0,0,0,$M,$D,$Y); //計算 1970/1/1 以來至上市日秒數
    $listed_years=round((time()-$listed_time)/3600/24/365,1); //小數一位
		echo "上市日期=".$listed_date." (已上市 $listed_years 年)<br>";
    //擷取近四季每股盈餘 (EPS)
    $start='最新四季每股盈餘</th>';
		$end="</table>"; //擷取出 4 列 <tr></tr>
		$data=return_between($web_page['FILE'], $start, $end, EXCL); 
		$data=preg_replace("/([\s]{2,})/","",$data); //去除多餘空格 > 1
    $row=remove($arr[$i],"</tr",">"); //移除標題結尾的 </tr>
		$data=str_replace(' class="trodd"', "", $data); //去除 tr 屬性
		$data=str_replace(' class="center"', "", $data); //去除 td 屬性
		$data=str_replace(' class="string"', "", $data); //去除 td 屬性
		//echo $data."<br>";
		$arr=parse_array($data, "<tr", "/tr>");  //拆分每一列
    $EPS=array(); //存放近四季 EPS
    for ($i=0; $i<4; $i++) { //拜訪每列 (近四季 EPS)
         $row=remove($arr[$i],"<tr",">"); //移除 <tr>
         $row=remove($row,"</tr",">"); //移除 </tr>, 剩下兩欄 td
         $arr1=parse_array($row, "<td", "/td>"); //拆分兩欄 td, EPS 在第二欄
         $col=remove($arr1[1],"<td",">"); //移除 <td>
         $col=remove($col,"</td",">"); //移除 </td>
         //echo $col."<br>";
         $EPS[]=preg_replace("/[^0-9.]/","",$col);  //特殊:去除"元"及空白字元
         } //end of for
		echo "近四季 EPS=".join(",",$EPS)."<br>";
    //更新 stocks_list 資料表
    $data_array=null;  //清空陣列
    $data_array["capital"]=(float)$capital; 
    $data_array["yield"]=(float)$yield;
    $data_array["PER"]=(float)$PER;
    $data_array["PBR"]=(float)$PBR;   
    //計算市值(億)
    $data_array["market_value"]=$data_array["capital"]*$RS[$j]['close']/10;
    echo "市值=".$data_array["market_value"]." 億<br>";
    $data_array["basic_update"]=date("Y-m-d H:i:s");
    $data_array["listed_years"]=$listed_years;
    update("stocks_list", $data_array, "stock_id", $RS[$j]['stock_id']); 
		$last_stock_id=$RS[$j]['stock_id'];
    } //end of for
$remark="OK (pointer=$pointer, last stock_id=".$last_stock_id.")";
//更新指標值
$data_array=null;  //清空陣列
$data_array["basic_pointer_2330"]=$pointer + $offset; 
update_all("stock_settings", $data_array);
//計算執行時間
$end_time=time();
$elapsed=$end_time-$start_time;
//新增 cron_log 資料表
$data_array=null;  //清空陣列
$data_array["date_time"]=date("Y-m-d H:i:s");
$data_array["program_name"]=pathinfo(__FILE__, PATHINFO_BASENAME);
$data_array["cron_type"]="download";
$data_array["elapsed"]=$elapsed;
$data_array["remark"]=$remark;
insert("cron_log", $data_array); //存入資料庫
$RS=null;
echo "<br>處理時間 :".$elapsed." 秒";
?>
</body>
</html>