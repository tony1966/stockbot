<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>擷取兆豐證券上市投信買超 1 日排行</title>
</head>
<body>
<P>擷取兆豐證券上市投信買超 1 日排行</P>
<?php
/*-----------------------------------------------------------------------------
用途 : 擷取兆豐證券上市投信買超 1 日排行
作者 : 黃耀煌
日期 : 2014-08-21  
說明 : 擷取兆豐證券上市投信買超 1 日排行 
       https://www.emega.com.tw/Z/ZG/ZG_DD.djhtm
       擷取以下資訊存入 overbuy 資料表 :
       1.股票代號
       2.買賣超張數
         近 2 季 EPS 年增率均為正 (流程12)
         見黃國華:財務自由的世界 p213 (只要求前兩季)
       3.近四年稅後淨利 : >0 不投資近四年虧損之公司 (流程3)
         見黃國華:財務自由的世界 p205
         http://2330.tw/Stock_Profit.aspx?id=2330 (年報)
       4.營益率追蹤 :
         (1).近三季營益率是否遞增
         (2).近三季營益率是否負轉正
         (3).近三季營益率是否遞減
         (4).近三季營益率是否正轉負
         (5).近一季營益率較近八季營益率下降三成(事情大條了)p72
         見黃國華:財務自由的講堂 p58,p72
注意 : 季報部份 :
       擷取目標為上半部季報, 下面實際抓到的資料單位是千, 但網頁顯示單位為百萬,
       即往左再取三位, 每一列對應網頁的一欄, 過去 12 個月營收即取 4 個季的第一
       個數據和, 再除以 100000 轉成以億為單位. 
       索引:0=營收,1=營業成本,2=營業毛利,3=營業費用,4=營業利益,5=營業外收入
       6=營業外支出,7=稅前淨利,8=本期淨利,9=每股盈餘(EPS)
       <div id="history">                
       132755000,71989000,60766000,16342000,44428000,2822000,1502000,45748000,
       39577000,1.53,2013-1Q|
       131305000,69461000,61844000,15694000,46255000,2172000,2180000,46247000,
       41569000,1.60,2012-4Q|
       141375000,72356000,69019000,16377000,52653000,1231000,155000,53729000,
       49303000,1.90,2012-3Q|         128061000,65591000,62470000,15545000,46712000,2176000,2964000,45924000,
       41813000,1.61,2012-2Q|
       </div>
       比率部分:只到索引8,沒有每股盈餘,2=毛利率,4=營益率,7=(稅前)淨利率,
       8=(稅後)淨利率 業外損益率=(稅前)淨利率-營益率
       <div id="history1">
       100.00,54.23,45.77,12.31,33.47,2.13,1.13,34.46,29.81,2013-1Q|                
       100.00,52.90,47.10,11.95,35.23,1.65,1.66,35.22,31.66,2012-4Q|            
       100.00,51.18,48.82,11.58,37.24,0.87,0.11,38.00,34.87,2012-3Q|             
       100.00,51.22,48.78,12.14,36.48,1.70,2.31,35.86,32.65,2012-2Q|             
       100.00,52.34,47.66,14.14,33.59,1.14,0.93,33.79,31.73,2012-1Q|
       ...
       </div>
       年報部份 :
       擷取前 4 年稅後淨利 (索引 8) >0
       <div id="history">
       506249000,262629000,243620000,62538000,181057000,6782000,6285000,
       181554000,166159000,6.41,2012|                
       427081000,232937000,194143000,52512000,141557000,5359000,1768000,
       145148000,134201000,5.18,2011|                
       419537911,212484320,207053591,47878256,159175335,13136072,2041012,
       170270395,161605009,6.24,2010|                
       295742239,166413628,129328611,37366725,91961886,5653548,2152787,
       95462647,89217836,3.45,2009|
       ...
       </div>
-----------------------------------------------------------------------------*/
#設定時區以使 cron_log 紀錄台灣時間
@ini_set('date.timezone','ASIA/Taipei');  //不一定有效
@ini_set("max_execution_time","120");     //不一定有效
date_default_timezone_set("Asia/Taipei"); 
echo date_default_timezone_get()."<br>";
$start_time=time(); //開始處理時間
//載入 webbot 函式庫
include_once("../db.php");           //匯入資料庫設定檔 (必須)
include_once("../lib/mysql.php");    //匯入資料庫模組   (必須)
include_once("../lib/parse.php");    //匯入剖析模組     (必須)
include_once("../lib/http.php");     //匯入http模組     (必須)
//取得 stock_settings 設定
$RS=search("stock_settings");
$pointer=$RS[0]["profit_pointer_2330"]; //目前指標
$offset=$RS[0]["profit_offset_2330"];   //下載股數
echo "目前指標 $pointer<br>";
echo "下載股數 $offset<br>";
//計算有基本資料之總筆數(非 0XXX)
$SQL="SELECT `stock_id` FROM `stocks_list` WHERE NOT `stock_id` LIKE '0%'";
$RS=run_sql($SQL);
if (count($RS)==0) { //若 stock_list 資料表還是空的, 先去擷取收盤資料
    header('Location: fetch_twse_daily_close.php');
    } //end of if
echo "stocks_list 之總筆數 : ".count($RS)."<br>";
if ($pointer > count($RS)-1) {$pointer=0;} //超過最後一筆指標歸零
//搜尋本次要下載的股號
if (empty($_REQUEST["id"])) { //工作模式 (url 沒有傳入 id 參數)
    $SQL="SELECT `stock_id`,`stock_name`,`market_value`,`equity` ".
         "FROM `stocks_list` ".
         "WHERE NOT `stock_id` LIKE '0%' ORDER BY `stock_id` LIMIT ".
         $pointer.",".$offset;
    } //end of if
else { //測試模式:網址列指定參數xxx.php?id=股號
    $SQL="SELECT `stock_id`,`stock_name`,`market_value`,`equity` ".
         "FROM `stocks_list` ".
         "WHERE `stock_id`='".$_REQUEST["id"]."'";
    } //end of else
$RS=run_sql($SQL);
$last_stock_id="";
for ($i=0; $i<count($RS); $i++) { //拜訪這一組各股
    //===下載季營收頁面===
		$target="http://2330.tw/Stock_Profit_Q.aspx?id=".$RS[$i]['stock_id'];
		echo "<a href='$target' target='_blank'>$target ".$RS[$i]['stock_name'].
         "</a><br>";
		$ref="";
		$web_page=http_get($target,$ref);
    //擷取季營收數值 (上半部)
		$start='<div id="history">'; //唯一標示開頭
    $end="</div>";
		$data=return_between($web_page['FILE'], $start, $end, EXCL);
		$data=preg_replace("/([\s]{2,})/","",$data); //去除多餘空格 >1
		//echo $data."<br>";
		//擷取前 12 個月 (4 季) 營收
		$arr=explode("|",$data);      //先以管線拆分各季
    $income_4Q=0;        //近四季營收累計
    $OPM_plus="Y";       //近3季營益率為正
    $OPM_over20="Y";     //近3季營益率超過 20%
    $OPM_increase="N";   //近3季營益率遞增
    $OPM_turnplus="N";   //近3季營益率負轉正
    $OPM_decrease="N";   //近3季營益率遞減
    $OPM_turnminus="N";  //近3季營益率正轉負
    $OPM_down30p="N";    //近1季營益率較近8季平均下降3成以上
    $GPM=array();        //存放近八季毛利率 Gross Profit Margin
    $OP=array();         //存放近八季營業利益 Operating Profit Margin
    $OPM=array();        //存放近八季營益率 Operating Profit Margin
    $PTNI=array();       //存放近八季稅前淨利率 Pre-Taxing Net Income
    $ATNI=array();       //存放近八季稅後淨利率 After-Taxing Net Income
    $NOPM=array();       //存放近八季業外損益率 Non-Operating Profit Margin
    $NOP_PTNI=array();   //存放近八季業外損益占稅前淨利比
    $EPS=array();        //存放近八季 EPS
    $OPM_sum=0;          //近8季營益率總和
    $OPM_square=0;       //近8季營益率平方和
    $out='<table border=1><tr><td>損益表項目</td><td>前1季</td><td>前2季</td>'.
         '<td>前3季</td><td>前4季</td><td>前5季</td><td>前6季</td>'.
         '<td>前7季</td><td>前8季</td></tr>';
    for ($j=0; $j<8; $j++) {   //拜訪前 8 季
         $brr=explode(",",$arr[$j]); //以逗號分拆本季損益資料
         //計算近四季營收以計算營收市值比
         $income=(int)$brr[0];    //索引0=本季營收(百萬)
         $gross=(int)$brr[2];     //索引2=本季毛利(百萬)
         $operating=(int)$brr[4]; //索引2=本季營業利益(百萬)
         $pretax=(int)$brr[7];    //索引7=本季稅前淨利(百萬)
         $aftertax=(int)$brr[8];  //索引8=本季稅後淨利(百萬)
         $nonop_income=(int)$brr[8];  //索引8=本季稅後淨利(百萬)
         if ($j<4) {$income_4Q += $income;} //累計前4季營收:算營收市值比
         //抓前八季 EPS 以計算近四季 EPS 年增率
         $EPS[]=(float)$brr[9]; //索引 9 為該季 EPS
         //計算本季毛利率 (索引2)
         if ($income != 0) { //可除
             $GPM[$j]=round($gross/$income*100, 2);      //本季毛利率
             $OPM[$j]=round($operating/$income*100, 2);  //本季營益率
             $PTNI[$j]=round($pretax/$income*100, 2);    //本季稅前淨利率
             $ATNI[$j]=round($aftertax/$income*100, 2);  //本季稅後淨利率
             $NOPM[$j]=$PTNI[$j]-$OPM[$j];               //本季業外損益率
             if ($pretax!=0) { //本季業外損益占稅前淨利比
                 $NOP_PTNI[$j]=round((1-$operating/$pretax)*100, 2); 
                 } //end of if
             else {$NOP_PTNI[$j]=NULL;}
             } //end of if
         else { //不可除
             $GPM[$j]=NULL;
             $OPM[$j]=NULL;
             $PTNI[$j]=NULL;
             $ATNI[$j]=NULL;
             $NOPM[$j]=NULL;
             $NOP_PTNI[$j]=NULL;
             } //end of else
         //判斷近3季營益率是否為正與超過 20%
         if ($j<3) { //一個不符就設 N (負面設定)             
             if ($OPM[$j]<=0) {$OPM_plus="N";}   
             if ($OPM[$j]<20) {$OPM_over20="N";} 
             } //end of if
         //累計營益率和與平方和以計算平均值與變異係數
         $OPM_sum += $OPM[$j]; //營益率累計
         $OPM_square += pow($OPM[$j], 2); //平方和累計 (計算標準差用)
         } //end of for
		//計算近四季營收總額
    $income_4Q=round($income_4Q/100000,2); //將單位由千轉成億
    //計算營收市值比 (%)
    if ($RS[$i]['market_value']!=0 && $RS[$i]['market_value']!=NULL) {
        $income_value_ratio=round($income_4Q/$RS[$i]['market_value']*100);
        } //end of if
    else {$income_value_ratio=NULL;} //無法計算
    //計算近 4 季 EPS 年增率 (只計算去年 EPS 為正者)
    $EPS_YOY_1Q=NULL;
    $EPS_YOY_2Q=NULL;
    $EPS_YOY_3Q=NULL;
    $EPS_YOY_4Q=NULL;
    if ($EPS[4]>0) {$EPS_YOY_1Q=round(($EPS[0]-$EPS[4])/$EPS[4]*100);}
    if ($EPS[5]>0) {$EPS_YOY_2Q=round(($EPS[1]-$EPS[5])/$EPS[5]*100);}
    if ($EPS[6]>0) {$EPS_YOY_3Q=round(($EPS[2]-$EPS[6])/$EPS[6]*100);}
    if ($EPS[7]>0) {$EPS_YOY_4Q=round(($EPS[3]-$EPS[7])/$EPS[7]*100);}
    //判斷近兩季 EPS 年增率是否為正 :
    if ($EPS_YOY_1Q > 0 && $EPS_YOY_2Q > 0) {$EPS_YOY_last2Q_plus="Y";}
    else {$EPS_YOY_last2Q_plus="N";}    
    //判斷近3季營益率是否遞增
    if ($OPM[0]>$OPM[1] && $OPM[1]>$OPM[2]) {$OPM_increase="Y";}
    //判斷近3季營益率是否遞減
    if ($OPM[0]<$OPM[1] && $OPM[1]<$OPM[2]) {$OPM_decrease="Y";}
    //判斷近3季營益率是否負轉正,(發生在近2季或前2,3季:[210]=負負正/負正正)
    if ($OPM[0]>0 && $OPM[2]<0) {$OPM_turnplus="Y";} //[0]必為正,[2]必為負
    //判斷近3季營益率是否正轉負 (發生在近2季或前2,3季:[210]=正負負/正正負)
    if ($OPM[0]<0 && $OPM[2]>0) {$OPM_turnminus="Y";}
    //計算近8季營益率平均值與變異係數CV
    $OPM_avg=round($OPM_sum/8,2);  //計算8季營益率平均值
    $OPM_std=sqrt(($OPM_square-pow($OPM_sum,2)/8)/7); //計算標準差    
    //計算近8季營益率平均值與變異係數 CV=標準差/平均值%
    if($OPM_avg != 0) {$OPM_CV=round(100*$OPM_std/$OPM_avg);}
    else {$OPM_CV=9999;}  //表示極大值
    //判斷近1季營益率是否較近8季平均下降3成以上
    if ($OPM_avg>0) {$down30p=$OPM_avg*0.7;} //正數:門檻=0.7倍
    else {$down30p=$OPM_avg*1.3;} //負數:門檻=1.3倍
    if ($OPM[0] <= $down30p) {$OPM_down30p="Y";}
    //
    $out .= "<tr><td>毛利率%</td><td>".join("</td><td>",$GPM)."</td></tr>".
            "<tr><td>營益率%</td><td>".join("</td><td>",$OPM)."</td></tr>".
            "<tr><td>稅前淨利率%</td><td>".join("</td><td>",$PTNI)."</td></tr>".
            "<tr><td>業外損益率%</td><td>".join("</td><td>",$NOPM)."</td></tr>".
            "<tr><td>稅後淨利率%</td><td>".join("</td><td>",$ATNI)."</td></tr>".
            "<tr><td>業外損益占稅前淨利比%</td><td>".
            join("</td><td>",$NOP_PTNI)."</td></tr>".
            "<tr><td>EPS (元)<td>".join("</td><td>",$EPS)."</td></tr>".    
            "<tr><td>EPS 年增率%</td><td>$EPS_YOY_1Q</td>".
            "<td>$EPS_YOY_2Q</td><td>$EPS_YOY_3Q</td><td>$EPS_YOY_4Q</td>".
            "<td></td><td></td><td></td><td></td></tr></table>";
    echo $out;
    echo "最近4季營收累計=".$income_4Q."億 市值=".$RS[$i]['market_value'].
         "億 營收市值比=".$income_value_ratio." %<br>";
    echo "近3季營益率均為正=".$OPM_plus."<br>";
    echo "近3季營益率 > 20%=".$OPM_over20."<br>";
    echo "近3季營益率呈遞增=".$OPM_increase."<br>";
    echo "近3季營益率呈遞減=".$OPM_decrease."<br>";
    echo "近3季營益率負轉正=".$OPM_turnplus."<br>";
    echo "近3季營益率正轉負=".$OPM_turnminus."<br>";    
    echo "近8季營益率平均值=$OPM_avg% 標準差=$OPM_std 變異係數=$OPM_CV%<br>";
    echo "近8季平均營益率下三成門檻=$down30p%<br>";
    echo "近1季營益率較近8季平均下降3成以上=".$OPM_down30p."<br>";
    echo "近2季EPS年增率均為正=$EPS_YOY_last2Q_plus<br><br>";
    //更新 stocks_list 資料表
    $data_array=null;  //清空陣列
    $data_array["income_value_ratio"]=$income_value_ratio; //營收市值比 (%)
    //EPS 追蹤
    $data_array["EPS_YOY_1Q"]=$EPS_YOY_1Q; //前1季EPS年增率
    $data_array["EPS_YOY_2Q"]=$EPS_YOY_2Q; //前2季EPS年增率
    $data_array["EPS_YOY_3Q"]=$EPS_YOY_3Q; //前3季EPS年增率
    $data_array["EPS_YOY_4Q"]=$EPS_YOY_4Q; //前4季EPS年增率
    //近兩季 EPS 年增率是否為正
    $data_array["EPS_YOY_last2Q_plus"]=$EPS_YOY_last2Q_plus; //Y/N
    //營益率追蹤
    //$data_array["GPM_8QS"]=join(",",$GPM);       //近8季毛利率字串
    //$data_array["PTNI_8QS"]=join(",",$PTNI);     //近8季稅前淨利率字串
    //$data_array["ATNI_8QS"]=join(",",$ATNI);     //近8季稅後淨利率字串
    //$data_array["NOPM_8QS"]=join(",",$NOPM);     //近8季業外損益率字串
    //$data_array["NOP_PTNI_8QS"]=join(",",$NOP_PTNI); //近8季業外損益率字串
    $data_array["OPM_8QS"]=join(",",$OPM);       //近8季營益率字串
    $data_array["OPM_avg"]=$OPM_avg;             //近8季營益率平均值
    $data_array["OPM_CV"]=$OPM_CV;               //近8季營益率變異係數
    $data_array["OPM_increase"]=$OPM_increase;   //近3季營益率呈遞增
    $data_array["OPM_decrease"]=$OPM_decrease;   //近3季營益率呈遞減
    $data_array["OPM_plus"]=$OPM_plus;           //近3季營益率均為正
    $data_array["OPM_over20"]=$OPM_over20;       //近3季營益率 > 20%
    $data_array["OPM_turnminus"]=$OPM_turnminus; //近3季營益率負轉正
    $data_array["OPM_turnplus"]=$OPM_turnplus;   //近3季營益率正轉負
    $data_array["OPM_down30p"]=$OPM_down30p;     //近1季營益率下降3成以上
    $data_array["profit_update"]=date("Y-m-d H:i:s");
    update("stocks_list", $data_array, "stock_id", $RS[$i]['stock_id']); 
		$last_stock_id=$RS[$i]['stock_id'];
    } //end of for
$remark="OK (pointer=$pointer, last stock_id=".$last_stock_id.")";
//更新指標值
$data_array=null;  //清空陣列
$data_array["profit_pointer_2330"]=$pointer + $offset; 
update_all("stock_settings", $data_array);
//計算執行時間
$end_time=time();
$elapsed=$end_time-$start_time;
//新增 cron_log 資料表
$data_array=null;  //清空陣列
$data_array["date_time"]=date("Y-m-d H:i:s");
$data_array["program_name"]=pathinfo(__FILE__, PATHINFO_BASENAME);
$data_array["cron_type"]="download";
$data_array["elapsed"]=$elapsed;
$data_array["remark"]=$remark;
insert("cron_log", $data_array); //存入資料庫
$RS=null;
echo "<br>處理時間 :".$elapsed." 秒";
?>
</body>
</html>