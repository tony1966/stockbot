<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>擷取 2330.tw 營業收入(月報)</title>
</head>
<body>
<P>擷取 2330.tw 營業收入(月報)</P>
<?php
/*-----------------------------------------------------------------------------
用途 : 擷取 2330.tw 營業收入(月報)
作者 : 黃耀煌
日期 : 2013-07-22, 2015-01-28 修訂 
說明 : 擷取 2330.tw 營業收入(月報) http://2330.tw/Stock_Income.aspx?id=2330
       擷取以下資訊存入 stocks_list 資料表 :
       1.最近 3 個月月營收年增率 > 0 嚴格 > 20%(流程6)
         見黃國華:財務自由的世界 p198,p209
         我自己加的:
         (1).近三月營收年增率是否遞增
         (2).近三月營收年增率是否負轉正
         (3).近三月營收年增率是否遞減
         (4).近三月營收年增率是否正轉負
         (5).近三月營收年增率是否均為正
       2.長短期月營收年增率 (暫不實做,需抓 24 個月資料,IFRS剛實施資料不準)
         (1).3個月漲破12個月
         (2).1個月漲破6個月
         見財報狗教你挖好股 p250
注意 : 擷取對象 :
       單位 : 千元, 年增率在索引 2
       <div id="history"> 
       N,54027749,24.30,2013-06|                
       N,51787926,17.23,2013-05|                
       N,50070645,23.50,2013-04|                
       N,44134225,18.91,2013-03|
       ....
       </div>
-----------------------------------------------------------------------------*/
#設定時區以使 cron_log 紀錄台灣時間
@ini_set('date.timezone','ASIA/Taipei');  //不一定有效
@ini_set("max_execution_time","120");     //不一定有效
date_default_timezone_set("Asia/Taipei"); 
echo date_default_timezone_get()."<br>";
$start_time=time(); //開始處理時間
//載入 webbot 函式庫
include_once("../db.php");           //匯入資料庫設定檔 (必須)
include_once("../lib/mysql.php");    //匯入資料庫模組   (必須)
include_once("../lib/parse.php");    //匯入剖析模組     (必須)
include_once("../lib/http.php");     //匯入http模組     (必須)
//取得 stock_settings 設定
$RS=search("stock_settings");
$pointer=$RS[0]["income_pointer_2330"]; //目前指標
$offset=$RS[0]["income_offset_2330"];   //下載股數
echo "目前指標 $pointer<br>";
echo "下載股數 $offset<br>";
//計算有基本資料之總筆數(非 0XXX)
$SQL="SELECT `stock_id` FROM `stocks_list` WHERE NOT `stock_id` LIKE '0%'";
$RS=run_sql($SQL);
if (count($RS)==0) { //若 stock_list 資料表還是空的, 先去擷取收盤資料
    header('Location: fetch_twse_daily_close.php');
    } //end of if
echo "stocks_list 之總筆數 : ".count($RS)."<br>";
if ($pointer > count($RS)-1) {$pointer=0;} //超過最後一筆指標歸零
//搜尋本次要下載的股號
if (empty($_REQUEST["id"])) { //工作模式 (url 沒有傳入 id 參數)
    $SQL="SELECT `stock_id`,`stock_name` FROM `stocks_list` ".
         "WHERE NOT `stock_id` LIKE '0%' ORDER BY `stock_id` LIMIT ".
         $pointer.",".$offset;
    } //end of if
else { //測試模式:網址列指定參數xxx.php?id=股號
    $SQL="SELECT `stock_id`,`stock_name` FROM `stocks_list` ".
         "WHERE `stock_id`='".$_REQUEST["id"]."'";
    } //end of else
$RS=run_sql($SQL);
$last_stock_id="";
for ($i=0; $i<count($RS); $i++) { //拜訪這一組各股
    //===下載營業收入(月報)頁面===
		$target="http://2330.tw/Stock_Income.aspx?id=".$RS[$i]['stock_id'];
		echo "<a href='$target' target='_blank'>$target ".$RS[$i]['stock_name'].
         "</a><br>";
		$ref="";
		$web_page=http_get($target,$ref);
    //擷取營業收入月報
		$start='<div id="history">'; //唯一標示開頭
    $end="</div>";
		$data=return_between($web_page['FILE'], $start, $end, EXCL);
		$data=preg_replace("/([\s]{2,})/","",$data); //去除多餘空格 >1
		//echo $data."<br>";
		//擷取近3月營業收入之年增率
		$arr=explode("|",$data);     //先以管線拆分各月
    $income_YOY=array();         //存放近3月營收年增率 (%)
    $income_YOY_plus="Y";        //近3月營收年增率為正
    $income_YOY_over20="Y";      //近3月營收年增率超過 20%
    $income_YOY_increase="N";    //近3月營收年增率遞增
    $income_YOY_turnplus="N";    //近3月營收年增率負轉正
    $income_YOY_decrease="N";    //近3月營收年增率遞減
    $income_YOY_turnminus="N";   //近3月營收年增率正轉負
    for ($j=0; $j<3; $j++) {     //拜訪前 3 月
         $arr1=explode(",",$arr[$j]);            //以逗號分拆該月營收資料
         $income_YOY[$j]=(float)$arr1[2];        //月營收年增率索引為 2
         if ($j<3) { //近3月營收年增率
             //一個不符就設 N (負面設定)
             if ($income_YOY[$j]<=0) {$income_YOY_plus="N";}   
             if ($income_YOY[$j]<20) {$income_YOY_over20="N";} 
             } //end of if
         } //end of for  
    //判斷近3月營收年增率是否遞增
    if ($income_YOY[0]>$income_YOY[1] && $income_YOY[1]>$income_YOY[2]) {
        $income_YOY_increase="Y"; //近3月營收年增率遞增
        } //end of if
    //判斷近3月營收年增率是否遞減
    if ($income_YOY[0]<$income_YOY[1] && $income_YOY[1]<$income_YOY[2]) {
        $income_YOY_decrease="Y"; //近3月營收年增率遞減
        } //end of if
    //判斷近3月營收年增率是否負轉正 (發生在近2月或前2,3月:[210]=負負正/負正正)
    $turn_plus=($income_YOY[0]>0 && $income_YOY[2]<0); //[0]必為正,[2]必為負
    if ($turn_plus) { //近3月營收年增率負轉正
        $income_YOY_turnplus="Y"; 
        } //end of if
    //判斷近3月營收年增率是否正轉負 (發生在近2月或前2,3月:[210]=正負負/正正負)
    $turn_minus=($income_YOY[0]<0 && $income_YOY[2]>0); //[2]必為正,[0]必為負
    if ($turn_minus) { //近3月營收年增率負轉正
        $income_YOY_turnminus="Y"; 
        } //end of if
    echo "月營收年增率:前1月=".$income_YOY[0]." 前2月=".$income_YOY[1].
         " 前3月=".$income_YOY[2]."<br>";
    echo "近3月營收年增率均為正=".$income_YOY_plus."<br>";
    echo "近3月營收年增率呈遞增=".$income_YOY_increase."<br>";
    echo "近3月營收年增率呈遞減=".$income_YOY_decrease."<br>";
    echo "近3月營收年增率負轉正=".$income_YOY_turnplus."<br>";
    echo "近3月營收年增率正轉負=".$income_YOY_turnminus."<br>";
    echo "近3月營收年增率 > 20%=".$income_YOY_over20."<br><br>";
    //更新 stocks_list 資料表
    $data_array=null;  //清空陣列
    $data_array["income_YOY_1M"]=$income_YOY[0]; //前1月月營收年增率(%)
    $data_array["income_YOY_2M"]=$income_YOY[1]; //前2月月營收年增率(%)
    $data_array["income_YOY_3M"]=$income_YOY[2]; //前3月月營收年增率(%)
    $data_array["income_YOY_plus"]=$income_YOY_plus; //近3月月營收年增率均為正
    $data_array["income_YOY_over20"]=$income_YOY_over20; //近3月營收年增率>20%
    $data_array["income_YOY_increase"]=$income_YOY_increase;  //近3月年增率遞增
    $data_array["income_YOY_decrease"]=$income_YOY_decrease;  //近3月年增率遞減
    $data_array["income_YOY_turnplus"]=$income_YOY_turnplus;  //近3月負轉正
    $data_array["income_YOY_turnminus"]=$income_YOY_turnminus; //近3月正轉負
    $data_array["income_update"]=date("Y-m-d H:i:s");
    update("stocks_list", $data_array, "stock_id", $RS[$i]['stock_id']); 
		$last_stock_id=$RS[$i]['stock_id']; //更新最後一個 stock_id
    } //end of for
$remark="OK (pointer=$pointer, last stock_id=".$last_stock_id.")";
//更新指標值
$data_array=null;  //清空陣列
$data_array["income_pointer_2330"]=$pointer + $offset; 
update_all("stock_settings", $data_array);
//計算執行時間
$end_time=time();
$elapsed=$end_time-$start_time;
//新增 cron_log 資料表
$data_array=null;  //清空陣列
$data_array["date_time"]=date("Y-m-d H:i:s");
$data_array["program_name"]=pathinfo(__FILE__, PATHINFO_BASENAME);
$data_array["cron_type"]="download";
$data_array["elapsed"]=$elapsed;
$data_array["remark"]=$remark;
insert("cron_log", $data_array); //存入資料庫
$RS=null;
echo "<br>處理時間 :".$elapsed." 秒";
?>
</body>
</html>