<?php
/*-----------------------------------------------------------------------------
用途 : 製作盤後資料分析報告
作者 : 黃耀煌
日期 : 2011-12-10, 2013-06-02, 2015-01-28 修訂
說明 : 讀取資料庫分析盤後資料, 製作今日盤後分析報告, 存入 report
       讀取 users 之 mail_list 1/0(郵寄列表), 1=寄出盤後分析報告
       寫入 cron_log 資料表
-----------------------------------------------------------------------------*/
header('Content-type: text/html; charset=utf-8');
#設定時區以使 cron_log 紀錄台灣時間
@ini_set('date.timezone','ASIA/Taipei');  //不一定有效
@ini_set("max_execution_time","120");     //不一定有效
date_default_timezone_set("Asia/Taipei"); 
//echo date_default_timezone_get()."<br>";
$start_time=time(); //開始處理時間
include_once("../db.php");           //匯入資料庫設定檔 (必須)
include_once("../lib/mysql.php");    //匯入資料庫模組   (必須)
//讀取 stock_settings (測試用)
$RS=search("stock_settings");
$test_mode=$RS[0]["test_mode"];        //"Y"=測試模式 (測試用)
$test_date=$RS[0]["test_date"];        //"Y"=測試日期 (測試用)
//製作今日日期
$today=date("Y-m-d"); //2011-12-10
if ($test_mode=="Y") { //測試模式時
    list($Y,$M,$D)=explode("-", $test_date); //分出年月日
    $test_date=mktime(0,0,0,$M,$D,$Y); //時分秒月日年
    $today=date("Y-m-d",$test_date); //覆蓋 $today, 擷取測試日期之報告
    } //end of if
$SQL="SELECT * FROM `report` WHERE `date_time` LIKE '".$today."%'";
//echo $SQL."<br>";
$RS=run_sql($SQL);
if (sizeof($RS)!=0) { //有該日收盤資料 => 交易日
   $email_content=$RS[0]["email_content"];
   $summary=$RS[0]["summary"];
	 echo $email_content;
   $remark="OK";
   } //end of if
else { //沒有該日收盤資料 => 非交易日或 create_daily_report.php 失敗
   echo "未取得 $today 盤後分析報告<br>";
   $remark="無 $today 之報告";
   } //end of else
//計算執行時間
$end_time=time();
$elapsed=$end_time-$start_time;
echo "<br>執行時間 :".$elapsed." 秒<br>";
//新增 cron_log 資料表紀錄
$data_array["date_time"]=date("Y-m-d H:i:s");
$data_array["program_name"]=pathinfo(__FILE__, PATHINFO_BASENAME);
$data_array["cron_type"]="report";
$data_array["elapsed"]=$elapsed;
$data_array["remark"]=$remark;
insert("cron_log", $data_array); //存入資料庫
$data_array=NULL;
?>
