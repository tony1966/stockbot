<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>製作盤後資料分析報告</title>
</head>
<body>
<?php
/*-----------------------------------------------------------------------------
用途 : 製作盤後資料分析報告
作者 : 黃耀煌
日期 : 2011-12-10, 2013-06-02, 2015-01-28 修訂
說明 : 讀取資料庫分析盤後資料, 製作今日盤後分析報告, 存入 report
       讀取 users 之 mail_list 1/0(郵寄列表), 1=寄出盤後分析報告
       寫入 cron_log 資料表
       測試模式 : 可重複產生當日報告 
       工作模式 : 多次 cron 觸發, 但每日只產生一份報告
-----------------------------------------------------------------------------*/
#設定時區以使 cron_log 紀錄台灣時間
@ini_set('date.timezone','ASIA/Taipei');  //不一定有效
@ini_set("max_execution_time","120");     //不一定有效
date_default_timezone_set("Asia/Taipei"); 
echo date_default_timezone_get()."<br>";
$start_time=time(); //開始處理時間
include_once("../db.php");             //匯入資料庫設定檔 (必須)
include_once("../lib/mysql.php");      //匯入資料庫模組   (必須)
include_once("../lib/mail.php");       //匯入郵寄模組     (必須)
//讀取 stock_settings 
$RS=search("stock_settings");
$test_mode=$RS[0]["test_mode"];        //"Y"=測試模式 (測試用)
$test_date=$RS[0]["test_date"];        //"Y"=測試日期 (測試用)
$yahoo=$RS[0]["yahoo"];                //報告用
$statementdog=$RS[0]["statementdog"];  //報告用
$www2333two=$RS[0]["www2333tw"];       //報告用
//製作今日日期
$today=date("Y-m-d"); //2011-12-10
if ($test_mode=="Y") { //測試模式時
    list($Y,$M,$D)=explode("-", $test_date); //分出年月日
    $test_date=mktime(0,0,0,$M,$D,$Y); //時分秒月日年
    $today=date("Y-m-d",$test_date); //覆蓋 $today, 擷取測試日期之報告
    } //end of if
//讀取 report 資料表, 判斷本日是否已有報告
$SQL="SELECT * FROM `report` WHERE `date_time` LIKE '".$today."%'";
$RS=run_sql($SQL);
echo $today."<br>";
if ($test_mode=="Y") {$RS="";} //測試模式時以字串覆蓋陣列,允許重複產生報告
if (is_array($RS)) {echo "本日已有報告";} //工作模式,不允許重複產生報告
else { //本日未有報告,或測試模式
    //讀取大盤資料表 z0000, 從 trade_date 判斷是否今日為交易日
    $SQL="SELECT * FROM `z0000` WHERE `trade_date`='".$today."'";
    $RS=run_sql($SQL);
    //echo $SQL."<br>";
    if (sizeof($RS)!=0) { //有該日收盤資料 => 交易日
        //製作郵件報告內容
        $email=$today." 台股盤後分析報告<br>";
        $em='style="color: blue;"';
        $volumn=round((int)$RS[0]["volumn"]/100000000,0); //單位換成億
        $delta_percent=$RS[0]["delta_percent"]."%";
        $style=<<<STYLE
<style>
  .tbl {border:1px solid purple;border;border-collapse:collapse;}
  .rpt {border:1px solid purple;padding:5px;}
  .tbl_cap {text-align:left;}
</style>
STYLE;
        $z0000=<<<Z0000
<table border=1 cellspacing=1 cellpadding=3 class="tbl">
  <caption class="tbl_cap"><b>{$today} 大盤整體市況</b></caption>
  <tr>
    <td class="rpt">指數 : {$RS[0]["close"]}</td>
    <td class="rpt">漲跌 : {$RS[0]["delta"]}</td>
    <td class="rpt">幅度 : {$delta_percent}</td>
    <td class="rpt">成交量(億) : {$volumn}</td>
  </tr>
  <tr>
    <td class="rpt">漲家數 : {$RS[0]["rise"]}</td>
    <td class="rpt">跌家數 : {$RS[0]["fall"]}</td>
    <td class="rpt">平家數 : {$RS[0]["even"]}</td>
    <td class="rpt">漲跌家數比 : {$RS[0]["rise_fall_ratio"]}</td>
  </tr>
  <tr>
    <td class="rpt" colspan=4>
     *多頭漲跌家數比 < 1.25 表示大盤轉疲處於弱勢, 注意可能變盤<br>
     *空頭漲跌家數比 > 1.25 連續 3 日, 為即將反彈之先期信號.
    </td>
  </tr>
</table><br>
Z0000;
        //製作簡訊通知
        $sms=$today."大盤收 ".$RS[0]["close"]." 漲跌 ".$RS[0]["delta"]."(".
             $RS[0]["delta_percent"]."%) 漲跌家數比 ".$RS[0]["rise_fall_ratio"];
        //製作本日摘要
        if ($RS[0]["rise_fall_ratio"]>=1.25) {$trend=">=1.25 漲勢";}
        else {$trend="<1.25 跌勢";}
        $summary="<b>".$today." 大盤市況</b><br>".
                 "指數 ".$RS[0]["close"]." 漲跌 ".$RS[0]["delta"]." ".
                 "(".$RS[0]["delta_percent"]."%) 成交量 ".$volumn." 億 ".
                 "漲跌家數比 ".$RS[0]["rise_fall_ratio"]." $trend<br>";
        $email=$style.$z0000; 
        //製作本日雪球股名單
        $SQL="SELECT * FROM `stocks_list` WHERE `yield` > 3.125 ".
             "AND `close` <= `cheap_price` ".
             "AND `dividend_avg` >= 2 ".
             "AND `close` > 20 ".
             "AND `CV` <= 30 ".
             "ORDER BY yield DESC,CV DESC,dividend_avg DESC";
        $RSA=run_sql($SQL);
        $row=array();    //mail 用
        $stock=array();  //summary 用
        $count=count($RSA);
        if (is_array($RSA)) { //有找到資料的話
            for ($i=0; $i<$count; $i++) { //走訪紀錄集陣列
                 $stock_id='<a href="'.$yahoo.$RSA[$i]["stock_id"].
                           '" target="_blank" title="Yahoo">'.
                           $RSA[$i]["stock_id"].'</a>';
                 $stock_name='<a href="'.$statementdog.$RSA[$i]["stock_id"].
                             '" target="_blank" title="財報狗">'.
                             $RSA[$i]["stock_name"].'</a>';
                 $tr='<tr>'.
                     '<td class="rpt">'.$stock_id.'</td>'.
                     '<td class="rpt">'.$stock_name.'</td>'.
                     '<td class="rpt">'.$RSA[$i]["dividend_avg"].'</td>'.
                     '<td class="rpt">'.$RSA[$i]["CV"].'%</td>'.
                     '<td class="rpt">'.$RSA[$i]["close"].'</td>'.
                     '<td class="rpt">'.$RSA[$i]["cheap_price"].'</td>'.
                     '<td class="rpt">'.$RSA[$i]["reason_price"].'</td>'.
                     '<td class="rpt">'.$RSA[$i]["expensive_price"].'</td>'.
                     '<td class="rpt">'.$RSA[$i]["yield"].'</td>'.
                     '<td class="rpt">'.$RSA[$i]["PER"].'</td>'.
                     '<td class="rpt">'.$RSA[$i]["PBR"].'</td>'.
                     '</tr>';
                 $row[]=$tr;
                 $stock[]=$stock_name."(".$stock_id.")";
                 } //end of for
            } //end of if
        else {
            $row[]="<tr><td colspan=11>無符合條件之股票.</td></tr>";
            $stock[]="無符合條件之股票.";
            } //end of else
        $tbody=join("",$row);echo count($RSA);
        $snowball=<<<SNOWBALL
<table border=1 cellspacing=1 cellpadding=3 class="tbl">
  <caption class="tbl_cap"><b>{$today} 雪球股 ({$count})</b></caption>
  <thead>
    <tr>
      <th>股號</th><th>公司</th><th>平均股息</th><th>變異係數</th>
      <th>收盤價</th><th>便宜價</th><th>合理價</th><th>昂貴價</th>
      <th>殖利率</th><th>本益比</th><th>股淨比</th>
    </tr>
  </thead>
  <tbody>{$tbody}</tbody>
</table><br>
SNOWBALL;
        $summary .= "<br><b>".$today." 雪球股 (".$count.")</b><br>".
                    join(" ",$stock);
        $email .= $snowball; 
        //將分析報告存入資料庫
        $data_array["date_time"]=$today." ".date("H:i:s");  
        $data_array["summary"]=$summary;  
        $data_array["email_content"]=$email;  
        $data_array["sms_content"]=$sms;  
        $data_array["emailed"]="N";  
        $result=insert("report", $data_array); //存入大盤資料表
        $data_array=NULL;  //重設以免影響後面的 SQL 操作
        //傳送 mail
        $subject=$today." 台股盤後分析報告";
        $message=$email;
        $address["to"]="yhhuang1966@gmail.com";
        $address["cc"]="yhhuang@cht.com.tw";
        $address["bcc"]="tony1966@ms5.hinet.net";
        $address["replyto"]="yhhuang1966@stockbot.x90x.net";
        $address["from"]="許功蓋";
        $content_type="text/html;charset=UTF-8";
        $result=formatted_mail($subject,$message,$address,$content_type);
        if ($result==TRUE) {
            echo "Your mail has been sent.<br>";
            foreach ($address as $key => $value) {
                     echo "$key: $value<br>";
                     } //end of foreach
            echo "Subject : $subject<br>";
            echo "Message : $message<br>";
            } //end of if
        else {echo("Mail-sending fails.");}
        $remark="OK"; //cron_log 說明欄位
        } //end of if
    else {  //沒有該日收盤資料 => 非交易日
        $remark="非交易日或尚無本日收盤資料"; //cron_log 說明欄位
        echo $remark;
        } //end of else
    //計算執行時間
    $end_time=time();
    $elapsed=$end_time-$start_time;
    echo "<br>執行時間 :".$elapsed." 秒";
    //新增 cron_log 資料表紀錄
    $data_array["date_time"]=date("Y-m-d H:i:s");
    $data_array["program_name"]=pathinfo(__FILE__, PATHINFO_BASENAME);
    $data_array["cron_type"]="report";
    $data_array["elapsed"]=$elapsed;
    $data_array["remark"]=$remark;
    insert("cron_log", $data_array); //存入資料庫
    $data_array=NULL;
    } //end of else
?>
</body>
</html>