<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>擷取挖股站 ROE 資料</title>
</head>
<body>
<P>擷取挖股站 ROE 資料</P>
<?php
/*-----------------------------------------------------------------------------
用途 : 擷取挖股站 ROE 資料
作者 : 黃耀煌
日期 : 2013-07-11, 2015-01-28 修訂 
說明 : 讀取 http://wowstock.org/roe.php
       擷取其中的 ROE 5 年平均, 8 年平均, 以及最近一年 ROE
       存入 stocks_list 資料表 
       ROE=稅後淨利/股東權益=營益率*總資產週轉率*權益乘數
       變異係數 CV=標準差/平均值 標準差=SQRT(平方的平均-平均的平方)
       標準差怎麼算 : 
       http://greenhornfinancefootnote.blogspot.tw/2007/08/blog-post_27.html
       在比較兩組因次不同或均值不同的數據時, 應該用變異係數而不是標準差來作為
       比較的參考.
注意 : 原網頁很大, 看原始碼需等很久, 不要沒耐心用另存新檔方式, 瀏覽器可能會
       把單引號改為雙引號, 導致誤判 pattern.
		   </tr><tr bgcolor='f4f4f4'>	
	       <td align='center'>1101</td>
	       <td width='70'>台泥</td>	
	       <td align='right'>9.30%</td>
         <td align='right'><fontcolor='red'>-5.03%</font></td>
-----------------------------------------------------------------------------*/
#設定時區以使 cron_log 紀錄台灣時間
@ini_set('date.timezone','ASIA/Taipei');  //不一定有效
@ini_set("max_execution_time","120");     //不一定有效
date_default_timezone_set("Asia/Taipei"); 
echo date_default_timezone_get()."<br>";
$start_time=time(); //開始處理時間
//載入 webbot 函式庫
include_once("../db.php");           //匯入資料庫設定檔 (必須)
include_once("../lib/mysql.php");    //匯入資料庫模組   (必須)
include_once("../lib/parse.php");    //匯入剖析模組     (必須)
include_once("../lib/http.php");     //匯入http模組     (必須)
//擷取網頁
$target="http://wowstock.org/roe.php";
echo "<a href='$target' target='_blank'>$target</a><br>";
$ref="";
$web_page=http_get($target,$ref); //下載網頁檔 (非交易日=404無檔案)
//$file=iconv("BIG5","UTF-8",$web_page['FILE']); //本身已是 utf-8, 不用轉
$file=$web_page['FILE'];
$file=preg_replace("/([\s]{2,})/","",$file); //去除多餘空格
$start="<tr bgcolor='f4f4f4'>"; //唯一標示開頭
$end="</table>";
$rows=return_between($file, $start, $end, EXCL); //補上 tr
//去除 font 與 td 屬性得 <tr><td>...</td></tr>
$rows=str_replace("<fontcolor='red'>","",$rows);  //去除 font
$rows=str_replace("</font>","",$rows);            //去除 font
$rows=str_replace(" bgcolor='f5f8cd'","",$rows);  //去除 tr 屬性
$rows=str_replace(" bgcolor='f4f4f4'","",$rows);  //去除 tr 屬性
$rows=str_replace(" width='70'",'',$rows);        //去除 td 屬性
$rows=str_replace(" align='center'","",$rows);    //去除 td 屬性
$rows=str_replace(" align='right'","",$rows);     //去除 td 屬性
//echo "<table><tr>".$rows."</table>";
$arr=parse_array($rows, "<tr", "/tr>"); //拆分每一列, 含界定字串 
echo "<table border=1><tr><td>stock_id</td><td>ROE_5Y</td><td>CV_5Y</td>".
     "<td>ROE_8Y</td><td>CV_8Y</td></tr>";
foreach ($arr as $k => $v) {  //拜訪每一列 (每一支股票)
  $arr1=parse_array($v, "<td>", "</td>");
  $stock_id=trim(return_between($arr1[0], "<td>", "</td>", EXCL));
  //平均 ROE
  $ROE_5Y_avg=trim(return_between($arr1[2], "<td>", "</td>", EXCL)); 
  $ROE_5Y_avg=preg_replace("/[%]/","",$ROE_5Y_avg); //去除 %
  $ROE_5Y_avg=(float)$ROE_5Y_avg;
  $ROE_8Y_avg=trim(return_between($arr1[3], "<td>", "</td>", EXCL)); 
  $ROE_8Y_avg=preg_replace("/[%]/","",$ROE_8Y_avg); //去除 %
  $ROE_8Y_avg=(float)$ROE_8Y_avg;
  $ROE=Array(); //儲存 8 年 ROE
  $ROE[]=trim(return_between($arr1[4], "<td>", "</td>", EXCL)); //前1年ROE
  $ROE[]=trim(return_between($arr1[5], "<td>", "</td>", EXCL)); //前2年ROE
  $ROE[]=trim(return_between($arr1[6], "<td>", "</td>", EXCL)); //前3年ROE
  $ROE[]=trim(return_between($arr1[7], "<td>", "</td>", EXCL)); //前4年ROE
  $ROE[]=trim(return_between($arr1[8], "<td>", "</td>", EXCL)); //前5年ROE
  $ROE[]=trim(return_between($arr1[9], "<td>", "</td>", EXCL)); //前6年ROE
  $ROE[]=trim(return_between($arr1[10], "<td>", "</td>", EXCL)); //前7年ROE
  $ROE[]=trim(return_between($arr1[11], "<td>", "</td>", EXCL)); //前8年ROE
  $dev_5Y=array(); //近 5 年 ROE 變異數
  $dev_8Y=array(); //近 8 年 ROE 變異數
  for ($i=0; $i<8; $i++) {
       $ROE[$i]=preg_replace("/[%]/","",$ROE[$i]); //去除 %
       if ($i < 5) {$dev_5Y[]=pow((float)$ROE[$i]-$ROE_5Y_avg, 2);} 
       $dev_8Y[]=pow((float)$ROE[$i]-$ROE_8Y_avg, 2);
       } //end of for
  $ROE_5Y_std=sqrt(array_sum($dev_5Y)/4); //計算 $ROE_8Y 標準差
  $ROE_8Y_std=sqrt(array_sum($dev_8Y)/7); //計算 $ROE_8Y 標準差
  //計算變異係數 (%)
  if($ROE_5Y_avg != 0) {$ROE_5Y_CV=round(100*$ROE_5Y_std/$ROE_5Y_avg);}
  else {$ROE_5Y_CV=9999;}  //溢位:用 9999 表示極大值
  if($ROE_8Y_avg != 0) {$ROE_8Y_CV=round(100*$ROE_8Y_std/$ROE_8Y_avg);}
  else {$ROE_8Y_CV=9999;}  //溢位:用 9999 表示極大值
  echo "<tr><td>$stock_id</td><td>$ROE_5Y_avg</td><td>$ROE_5Y_CV</td>".
       "<td>$ROE_8Y_avg</td><td>$ROE_8Y_CV</tr>";
  } //end of foreach
echo "</table>";
//計算執行時間
$end_time=time();
$elapsed=$end_time-$start_time;
echo "<br>處理時間 :".$elapsed." 秒";
?>
</body>
</html>