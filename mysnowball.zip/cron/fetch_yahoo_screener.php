<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>擷取 Yahoo 股市個股健診資料</title>
</head>
<body>
<P>擷取 Yahoo 股市個股健診資料</P>
<?php
/*-----------------------------------------------------------------------------
用途 : 擷取 Yahoo 股市個股健診資料
作者 : 黃耀煌
日期 : 2013-07-11, 2015-01-28 修訂 
說明 : 讀取 http://tw.screener.finance.yahoo.net/screener/check.html?symid=2330
       擷取其中的技術面資料-近一週,近一月,近三月股價表現,K,d,macd 值,
       近52週最高, 近52週最低, 券資比與增減
       存入 stocks_list 資料表
-----------------------------------------------------------------------------*/
#設定時區以使 cron_log 紀錄台灣時間
@ini_set('date.timezone','ASIA/Taipei');  //不一定有效
@ini_set("max_execution_time","120");     //不一定有效
date_default_timezone_set("Asia/Taipei"); 
echo date_default_timezone_get()."<br>";
$start_time=time(); //開始處理時間
//載入 webbot 函式庫
include_once("../db.php");           //匯入資料庫設定檔 (必須)
include_once("../lib/mysql.php");    //匯入資料庫模組   (必須)
include_once("../lib/parse.php");    //匯入剖析模組     (必須)
include_once("../lib/http.php");     //匯入http模組     (必須)
//取得 stock_settings 設定
$RS=search("stock_settings");
$pointer=$RS[0]["dividend_pointer"]; //目前指標
$offset=$RS[0]["dividend_offset"];   //下載股數
$test_mode=$RS[0]["test_mode"];      //"Y"=測試模式
echo "目前指標 $pointer<br>";
echo "下載股數 $offset<br>";
//計算有股利分派之總筆數(非 0XXX)
$SQL="SELECT `stock_id` FROM `stocks_list` WHERE NOT `stock_id` LIKE '0%'";
$RS=run_sql($SQL);
if (count($RS)==0) { //若 stock_list 資料表還是空的, 先去擷取收盤資料
    header('Location: fetch_twse_daily_close.php');
    } //end of if
echo "有股利分派之總筆數 : ".count($RS)."<br>";
if ($pointer > count($RS)-1) {$pointer=0;} //超過最後一筆指標歸零
//搜尋本次要下載的股號
$SQL="SELECT `stock_id`, `close` FROM `stocks_list` WHERE NOT `stock_id` ".
     "LIKE '0%' ORDER BY `stock_id` LIMIT ".$pointer.",".$offset;
$RS=run_sql($SQL);
$last_stock_id="";
for ($j=0; $j<count($RS); $j++) {  
    $target="http://tw.stock.yahoo.com/d/s/dividend_".$RS[$j]['stock_id'].
            ".html";
    echo "<a href='$target' target='_blank'>$target</a><br>";
    $ref="";
    $web_page=http_get($target,$ref); //下載網頁檔 (非交易日=404無檔案)
    $file=iconv("BIG5","UTF-8",$web_page['FILE']); //轉成 utf-8 格式
    $file=preg_replace("/([\s]{2,})/","",$file); //去除多餘空格
    //擷取前五年現金股利
    $start="合　計</td></tr>";
    $end="</table>";
    $rows=return_between($file, $start, $end, EXCL); //得 <tr><td></td>...</tr>
    //echo $rows;
    $arr=parse_array($rows, "<tr", "/tr>");          //拆分每一列
    $Y=Array();  //儲存年度
    $D=Array();  //儲存股息
    $sum=0;
    $square=0;
    for ($i=0; $i<5; $i++) { //取 5 列 (前五年股息)
         $arr[$i]=remove($arr[$i], "<tr", ">");       //去除 <tr ...>
         $arr[$i]=str_replace("</tr>", "", $arr[$i]); //去除 </tr>
         $brr=parse_array($arr[$i], "<td", "/td>");   //拆分為 6 欄
         $start='<td align="center" height="25">';
         $end="</td>";
         $Y[$i]=return_between($brr[0], $start, $end, EXCL);  //第 1 欄是年度
         if (is_numeric($Y[$i])) {$Y[$i]=$Y[$i] + 1911;}      //改為西元
         $start='<td align="center">';
         $end="</td>";
         $D[$i]=return_between($brr[1], $start, $end, EXCL);  //第 2 欄是股息
         $sum +=(float)$D[$i]; //股息累計
         $square += pow((float)$D[$i], 2); //平方和累計 (計算標準差用)
         echo "$Y[$i] : $D[$i]<br>";
         } //end of for
    $dividend_avg=$sum/5; //計算五年平均股息
    $dividend_std=sqrt(($square-pow($sum,2)/5)/4); //計算標準差
    if($dividend_avg != 0) { //防止溢位
       $CV=round(100*$dividend_std/$dividend_avg); //計算變異係數 (%)
       } //end of if
    else {$CV=9999;}  //表示極大值
    $cheap_price=round($dividend_avg * 16, 1); //便宜價 16 倍
    $reason_price=round($dividend_avg * 20, 1); //合理價 20 倍
    $expensive_price=round($dividend_avg * 32, 1); //昂貴價 32 倍
		//更新 stocks_list 資料表
    $data_array=null;  //清空陣列
    $data_array["Y1"]=$Y[0];
    $data_array["D1"]=$D[0];
    $data_array["Y2"]=$Y[1];
    $data_array["D2"]=$D[1];
    $data_array["Y3"]=$Y[2];
    $data_array["D3"]=$D[2];
    $data_array["Y4"]=$Y[3];
    $data_array["D4"]=$D[3];
    $data_array["Y5"]=$Y[4];
    $data_array["D5"]=$D[4];
    $data_array["dividend_avg"]=$dividend_avg;
    $data_array["dividend_std"]=$dividend_std;
    $data_array["CV"]=$CV;
    $data_array["cheap_price"]=$cheap_price;
    $data_array["reason_price"]=$reason_price;
    $data_array["expensive_price"]=$expensive_price;
    $data_array["dividend_update"]=date("Y-m-d H:i:s");
    update($table="stocks_list",$data_array,"stock_id",$RS[$j]['stock_id']);
    echo "平均股息:$dividend_avg<br>";   
    echo "變異係數:$CV<br>";   
		$last_stock_id=$RS[$j]['stock_id'];
    } 
$remark="OK (pointer=$pointer, last stock_id=".$last_stock_id.")";
//更新指標值
$data_array=null;  //清空陣列
$data_array["dividend_pointer"]=$pointer + $offset; 
update_all("stock_settings", $data_array);
//計算執行時間
$end_time=time();
$elapsed=$end_time-$start_time;
//新增 cron_log 資料表
$data_array=null;  //清空陣列
$data_array["date_time"]=date("Y-m-d H:i:s");
$data_array["program_name"]=pathinfo(__FILE__, PATHINFO_BASENAME);
$data_array["cron_type"]="download";
$data_array["elapsed"]=$elapsed;
$data_array["remark"]=$remark;
insert("cron_log", $data_array); //存入資料庫
$RS=null;$data_array=null;
echo "<br>處理時間 :".$elapsed." 秒";
?>
</body>
</html>