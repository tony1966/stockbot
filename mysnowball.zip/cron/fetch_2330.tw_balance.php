<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>擷取 2330.tw 資產負債表</title>
</head>
<body>
<P>擷取 2330.tw 資產負債表</P>
<?php
/*-----------------------------------------------------------------------------
用途 : 擷取 2330.tw 損益表
作者 : 黃耀煌
日期 : 2013-07-13 (蘇力颱風來襲), 2015-01-28 修訂 
說明 : 擷取 2330.tw 資產負債表 http://2330.tw/Stock_Balance_Q.aspx?id=2330
       擷取以下資訊存入 stocks_list 資料表 :
       1.最近一季的股東權益總額 (淨值) -> 計算市值淨值比  
         市值淨值比=投資人願意用多少錢來買一塊錢的股東權益? 可用來衡量股價高低.
         當來到 10 以上時, 表示股價已經過熱了,高價股的價格天險已近.
         見黃國華:財務自由的世界 p154
       2.擷取近8季存貨, 計算存貨營收比 IIR (Inventory Income Ratio)
         見 fetch_2330.tw_analysis.php 說明
         見黃國華:財務自由的講堂 P157
注意 : 擷取目標為上半部季報, 下面實際抓到的資料單位是千, 但網頁顯示單位為百萬,
       即往左再取三位, 每一列對應網頁的一欄, 最近一季的股東權益總額在第一欄
       的底端,再除以 100000 轉成以億為單位. 
       <div id="history">                
       186029000,66083000,37833000,297751000,70703000,666447000,26728000,
       1061630000,158206000,126325000,8449000,292981000,768649000,2013-1Q|
       ....
       </div>
-----------------------------------------------------------------------------*/
#設定時區以使 cron_log 紀錄台灣時間
@ini_set('date.timezone','ASIA/Taipei');  //不一定有效
@ini_set("max_execution_time","120");     //不一定有效
date_default_timezone_set("Asia/Taipei"); 
echo date_default_timezone_get()."<br>";
$start_time=time(); //開始處理時間
//載入 webbot 函式庫
include_once("../db.php");           //匯入資料庫設定檔 (必須)
include_once("../lib/mysql.php");    //匯入資料庫模組   (必須)
include_once("../lib/parse.php");    //匯入剖析模組     (必須)
include_once("../lib/http.php");     //匯入http模組     (必須)
//取得 stock_settings 設定
$RS=search("stock_settings");
$pointer=$RS[0]["balance_pointer_2330"]; //目前指標
$offset=$RS[0]["balance_offset_2330"];   //下載股數
echo "目前指標 $pointer<br>";
echo "下載股數 $offset<br>";
//計算有基本資料之總筆數(非 0XXX)
$SQL="SELECT `stock_id` FROM `stocks_list` WHERE NOT `stock_id` LIKE '0%'";
$RS=run_sql($SQL);
if (count($RS)==0) { //若 stock_list 資料表還是空的, 先去擷取收盤資料
    header('Location: fetch_twse_daily_close.php');
    } //end of if
echo "stocks_list 之總筆數 : ".count($RS)."<br>";
if ($pointer > count($RS)-1) {$pointer=0;} //超過最後一筆指標歸零
//搜尋本次要下載的股號
if (empty($_REQUEST["id"])) { //工作模式 (url 沒有傳入 id 參數)
    $SQL="SELECT `stock_id`,`stock_name`,`market_value` FROM `stocks_list` ".
         "WHERE NOT `stock_id` LIKE '0%' ORDER BY `stock_id` LIMIT ".
         $pointer.",".$offset;
    } //end of if
else { //測試模式:網址列指定參數xxx.php?id=股號
    $SQL="SELECT `stock_id`,`stock_name`,`market_value` FROM `stocks_list` ".
         "WHERE `stock_id`='".$_REQUEST["id"]."'";
    } //end of else
$RS=run_sql($SQL);
$last_stock_id="";
for ($i=0; $i<count($RS); $i++) { //拜訪這一組各股
    //===下載資產負債表季報頁面===
		$target="http://2330.tw/Stock_Balance_Q.aspx?id=".$RS[$i]['stock_id'];
		echo "<a href='$target' target='_blank'>$target ".$RS[$i]['stock_name'].
         "</a><br>";
		$ref="";
		$web_page=http_get($target,$ref);
    //擷取季資產負債表 (上半部)
		$start='<div id="history">'; //唯一標示開頭
    $end="</div>";
		$data=return_between($web_page['FILE'], $start, $end, EXCL);
		$data=preg_replace("/([\s]{2,})/","",$data); //去除多餘空格 >1
		//echo $data."<br>";
		//擷取最近一季的股東權益總額
		$arr=explode("|",$data); //先以管線拆分各季
    $q=count($arr)-1;           //季數 (正常=10),因最後還有一個|,需減1
    $IV=array();                //儲存近8季存貨
    $last_1Q_equity=0;          //最近一季股東權益總額 (淨值)
    $out='<table border=1><tr><td>項目</td>';  //輸出表格 
    for ($j=0; $j<8; $j++) {   //拜訪近8季
         $brr=explode(",",$arr[$j]); //以逗號分拆本季資料
         $IV[$j]=(int)$brr[2]; //索引 2 為存貨, 顯示單位為百萬,實際為千
         if ($j==0) { //最近一季股東權益總額, 資料單位為千(但顯示改為百萬)
             $last_1Q_equity=round($brr[12]/100000,2); //將單位由千轉成億
             } 
         $out .= "<td>前".($j+1)."季</td>";
         }
    //輸出結果
    $out .= '</tr>'.
            '<tr><td>存貨(千)</td><td>'.join("</td><td>",$IV).
            '</td></tr></table>';
    echo $out;  
    //計算市值淨值比 
    if ($last_1Q_equity!=0) {
        $value_equity_ratio=round($RS[$i]['market_value']/$last_1Q_equity,2);
        } //end of if
    else {$value_equity_ratio=NULL;} //無法計算
    echo "市值=".$RS[$i]['market_value']." 億<br>";
    echo "最近 1 季淨值 (股東權益)=$last_1Q_equity 億<br>";
    echo "市值淨值比=".$value_equity_ratio."<br><br>";
    //更新 stocks_list 資料表
    $data_array=null;  //清空陣列
    $data_array["IV_8QS"]=implode(",",$IV); //儲存近8季存貨 (單位實際為千)
    $data_array["equity"]=$last_1Q_equity; //淨值 (億)
    $data_array["value_equity_ratio"]=$value_equity_ratio; //市值淨值比
    $data_array["balance_update"]=date("Y-m-d H:i:s");
    update("stocks_list", $data_array, "stock_id", $RS[$i]['stock_id']); 
		$last_stock_id=$RS[$i]['stock_id'];
    } //end of for
$remark="OK (pointer=$pointer, last stock_id=".$last_stock_id.")";
//更新指標值
$data_array=null;  //清空陣列
$data_array["balance_pointer_2330"]=$pointer + $offset; 
update_all("stock_settings", $data_array);
//計算執行時間
$end_time=time();
$elapsed=$end_time-$start_time;
//新增 cron_log 資料表
$data_array=null;  //清空陣列
$data_array["date_time"]=date("Y-m-d H:i:s");
$data_array["program_name"]=pathinfo(__FILE__, PATHINFO_BASENAME);
$data_array["cron_type"]="download";
$data_array["elapsed"]=$elapsed;
$data_array["remark"]=$remark;
insert("cron_log", $data_array); //存入資料庫
$RS=null;
echo "<br>處理時間 :".$elapsed." 秒";
?>
</body>
</html>