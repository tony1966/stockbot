<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>擷取 2330.tw 股利政策</title>
</head>
<body>
<P>擷取 2330.tw 股利政策</P>
<?php
/*-----------------------------------------------------------------------------
用途 : 擷取 2330.tw 股利政策
作者 : 黃耀煌
日期 : 2013-07-20 
說明 : 擷取 2330.tw 股利政策 http://2330.tw/Stock_Dividend.aspx?id=2330
       擷取以下資訊存入 stocks_list 資料表 :
       擷取其中的前五年股息資料 : 現金股利, 每股盈餘, 股利發放率(現金配息率)
       計算平均股息與變異係數,以及便宜價,合理價,昂貴價,存入 stocks_list 資料表
注意 : 擷取目標 : 索引0=現金股利,5=EPS
       <div id="history"> 
       3.00,0.00,0.00,0.00,3.00,6.41,2012|                
       3.00,0.00,0.00,0.00,3.00,5.18,2011|                
       3.00,0.00,0.00,0.00,3.00,6.24,2010|                
       3.00,0.00,0.00,0.00,3.00,3.45,2009|                
       3.00,0.02,0.03,0.05,3.05,3.86,2008|
       ....
       </div>
-----------------------------------------------------------------------------*/
#設定時區以使 cron_log 紀錄台灣時間
@ini_set('date.timezone','ASIA/Taipei');  //不一定有效
@ini_set("max_execution_time","120");     //不一定有效
date_default_timezone_set("Asia/Taipei"); 
echo date_default_timezone_get()."<br>";
$start_time=time(); //開始處理時間
//載入 webbot 函式庫
include_once("../db.php");           //匯入資料庫設定檔 (必須)
include_once("../lib/mysql.php");    //匯入資料庫模組   (必須)
include_once("../lib/parse.php");    //匯入剖析模組     (必須)
include_once("../lib/http.php");     //匯入http模組     (必須)
//取得 stock_settings 設定
$RS=search("stock_settings");
$pointer=$RS[0]["dividend_pointer_2330"]; //目前指標
$offset=$RS[0]["dividend_offset_2330"];   //下載股數
echo "目前指標 $pointer<br>";
echo "下載股數 $offset<br>";
//計算有基本資料之總筆數(非 0XXX)
$SQL="SELECT `stock_id` FROM `stocks_list` WHERE NOT `stock_id` LIKE '0%'";
$RS=run_sql($SQL);
if (count($RS)==0) { //若 stock_list 資料表還是空的, 先去擷取收盤資料
    header('Location: fetch_twse_daily_close.php');
    } //end of if
echo "stocks_list 之總筆數 : ".count($RS)."<br>";
if ($pointer > count($RS)-1) {$pointer=0;} //超過最後一筆指標歸零
//搜尋本次要下載的股號
if (empty($_REQUEST["id"])) { //工作模式 (url 沒有傳入 id 參數)
    $SQL="SELECT `stock_id`,`stock_name`,`close` FROM `stocks_list` ".
         "WHERE NOT `stock_id` LIKE '0%' ORDER BY `stock_id` LIMIT ".
         $pointer.",".$offset;
    } //end of if
else { //測試模式:網址列指定參數xxx.php?id=股號
    $SQL="SELECT `stock_id`,`stock_name`,`close` FROM `stocks_list` ".
         "WHERE `stock_id`='".$_REQUEST["id"]."'";
    } //end of else
$RS=run_sql($SQL);
$last_stock_id="";
for ($i=0; $i<count($RS); $i++) { //拜訪這一組各股
    //下載 2330.tw 股利政策頁面
		$target="http://2330.tw/Stock_Dividend.aspx?id=".$RS[$i]['stock_id'];
		echo "<a href='$target' target='_blank'>$target ".$RS[$i]['stock_name'].
         "</a><br>";
		$ref="";
		$web_page=http_get($target,$ref);
    //擷取股利政策資料
		$start='<div id="history">'; //唯一標示開頭
    $end="</div>";
		$data=return_between($web_page['FILE'], $start, $end, EXCL);
		$data=preg_replace("/([\s]{2,})/","",$data); //去除多餘空格 >1
		//echo $data."<br>";
		//擷取前五年現金股利
		$arr=explode("|",$data);  //先以管線拆分各年度 
    $Y=Array();      //儲存年度
    $D=Array();      //儲存近5年股息
    $P=Array();      //儲存近5年股利 (Payout)
    $EPS=Array();    //儲存近5年每股盈餘(EPS)
    $CDR=Array();    //儲存近5年現金配息率(cash_dividend_rate)
    $PDR=Array();    //儲存近5年股利發放率(payout_dividend_rate)
    $CDR_over80="Y"; //近5年現金配息率均>80%
    $CDR_5Y=0;       //近5年現金配息率累計 (求平均值用)
    $PDR_5Y=0;       //近5年股利發放率累計 (求平均值用)
    $sum=0;          //近5年股息總和
    $square=0;       //近5年股息平方和
    $out='<table border=1><tr><td>年</td><td>現金股息</td>'.
         '<td>EPS</td><td>現金配息率%</td><td>股利發放率%</td></tr>';
    for ($j=0; $j<5; $j++) { //取 5 列 (前五年股息)
         //3.00,0.00,0.00,0.00,3.00,6.41,2012| 索引0=現金股利,5=EPS
         $brr=explode(",",$arr[$j]); //以逗號拆分列資料
         //擷取現金股息與 EPS
         $D[$j]=$brr[0];             //第 0 欄是現金股息
         $EPS[$j]=$brr[5];           //第 5 欄是EPS
         $Y[$j]=$brr[6];             //第 6 欄是年
         $P[$j]=$brr[4];             //第 4 欄是全部股利合計
         //計算股利發放率
         if ($EPS[$j] != 0) {$PDR[$j]=round($P[$j]/$EPS[$j]*100);}
         else {$PDR[$j]=0;} //EPS=0
         $PDR_5Y += $PDR[$j]; //近5年股利發放率累計
         //計算現金配息率
         if ($EPS[$j] != 0) {$CDR[$j]=round($D[$j]/$EPS[$j]*100);}
         else {$CDR[$j]=0;} //EPS=0
         $CDR_5Y += $CDR[$j]; //近5年現金配息率累計
         //檢查現金配息率是否>80%
         if ($CDR[$j]<80) {$CDR_over80="N";} //有一年小於80就設 N
         $sum +=(float)$D[$j]; //股息累計
         $square += pow((float)$D[$j], 2); //平方和累計 (計算標準差用)
         $out .= "<tr><td>$Y[$j]</td><td>$D[$j]</td>".
                 "<td>$EPS[$j]</td><td>$CDR[$j]</td>".
                 "<td>$PDR[$j]</td></tr>";
         } //end of for
    echo $out."</table>";
    $PDR_avg=round($PDR_5Y/5); //計算近5年股利發放率平均值
    $CDR_avg=round($CDR_5Y/5); //計算近5年現金配息率平均值
    $dividend_avg=$sum/5;      //計算五年平均股息
    $dividend_std=sqrt(($square-pow($sum,2)/5)/4); //計算標準差    
    if($dividend_avg != 0) { //計算變異係數 CV=標準差/平均值 %
       $CV=round(100*$dividend_std/$dividend_avg); //計算變異係數 (%)
       } //end of if
    else {$CV=9999;}  //表示極大值
    $close=$RS[$i]['close'];                       //收盤價
    $cheap_price=round($dividend_avg * 16, 1);     //便宜價 16 倍
    $reason_price=round($dividend_avg * 20, 1);    //合理價 20 倍
    $expensive_price=round($dividend_avg * 32, 1); //昂貴價 32 倍
		//更新 stocks_list 資料表
    $data_array=null;  //清空陣列
    $data_array["D1"]=$D[0]; //前1年股息
    $data_array["D2"]=$D[1]; //前2年股息
    $data_array["D3"]=$D[2]; //前3年股息
    $data_array["D4"]=$D[3]; //前4年股息
    $data_array["D5"]=$D[4]; //前5年股息
    $data_array["PDR1"]=$PDR[0]; //前1年現金配息率
    $data_array["PDR2"]=$PDR[1]; //前2年現金配息率
    $data_array["PDR3"]=$PDR[2]; //前3年現金配息率
    $data_array["PDR4"]=$PDR[3]; //前4年現金配息率
    $data_array["PDR5"]=$PDR[4]; //前5年現金配息率
    $data_array["CDR1"]=$CDR[0]; //前1年現金配息率
    $data_array["CDR2"]=$CDR[1]; //前2年現金配息率
    $data_array["CDR3"]=$CDR[2]; //前3年現金配息率
    $data_array["CDR4"]=$CDR[3]; //前4年現金配息率
    $data_array["CDR5"]=$CDR[4]; //前5年現金配息率
    $data_array["PDR_avg"]=$PDR_avg;           //近5年股利發放率平均值
    $data_array["CDR_avg"]=$CDR_avg;           //近5年現金配息率平均值
    $data_array["CDR_over80"]=$CDR_over80;     //是否近5年現金配息率均>80%
    $data_array["dividend_avg"]=$dividend_avg; //近5年平均股息
    $data_array["dividend_std"]=$dividend_std; //近5年平均股息標準差
    $data_array["CV"]=$CV;                     //近5年平均股息變異係數
    $data_array["cheap_price"]=$cheap_price;         //便宜價 16 倍
    $data_array["reason_price"]=$reason_price;       //合理價 20 倍
    $data_array["expensive_price"]=$expensive_price; //昂貴價 32 倍
    $data_array["dividend_update"]=date("Y-m-d H:i:s");
    update($table="stocks_list",$data_array,"stock_id",$RS[$i]['stock_id']);
    echo "近5年平均股息=$dividend_avg 標準差=$dividend_std 變異係數=$CV<br>";   
    echo "近5年平均股利發放率=$PDR_avg%<br>";  
    echo "近5年平均現金配息率=$CDR_avg%<br>";
    echo "近5年現金配息率均>80%=$CDR_over80<br>";
    echo "收盤價=$close 便宜價=$cheap_price 合理價=$reason_price ".
         "昂貴價=$expensive_price<br><br>";
		$last_stock_id=$RS[$i]['stock_id']; //更新最後一個 stock_id
    } 
$remark="OK (pointer=$pointer, last stock_id=".$last_stock_id.")";
//更新指標值
$data_array=null;  //清空陣列
$data_array["dividend_pointer_2330"]=$pointer + $offset; 
update_all("stock_settings", $data_array);
//計算執行時間
$end_time=time();
$elapsed=$end_time-$start_time;
//新增 cron_log 資料表
$data_array=null;  //清空陣列
$data_array["date_time"]=date("Y-m-d H:i:s");
$data_array["program_name"]=pathinfo(__FILE__, PATHINFO_BASENAME);
$data_array["cron_type"]="download";
$data_array["elapsed"]=$elapsed;
$data_array["remark"]=$remark;
insert("cron_log", $data_array); //存入資料庫
$RS=null;
echo "<br>處理時間 :".$elapsed." 秒";
?>
</body>
</html>