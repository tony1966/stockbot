<?php
session_start(); //啟動 session 功能
//檢查是否已登入, 否則回登入畫面
if (!isset($_SESSION["user_account"])) {header("Location: index.php");}
//設定台北時間
date_default_timezone_set("Asia/Taipei");
//匯入資料庫
require_once("db.php");        //匯入資料庫設定檔 (必須)
require_once("lib/mysql.php");    //匯入資料庫模組   (必須)
require_once("lib/file.php");     //匯入剖析模組     (必須)
//先測試是否能讀取資料庫
$installed=find_table("sys_settings"); //檢查資料庫是否已安裝
if ($installed===FALSE) {header("Location: index.php");} //安裝系統
//製作日期顯示 
$week_arr=array("日","一","二","三","四","五","六");
list($Y,$M,$D)=explode("-",date("Y-m-d")); //取出年月日
$week=$week_arr[date("w",mktime(0,0,0,$M,$D,$Y))];
$greeting="您好! ".$_SESSION["user_name"].", ".
          "今天是 $Y 年 $M 月 $D 日 星期$week";
//擷取系統設定布景
$RS=search("sys_settings");
$sys_theme=$RS[0]["sys_theme"];
$site_title=$RS[0]["site_title"];
$system_state=$RS[0]["system_state"];
$auth_policy=$RS[0]["auth_policy"];
$min_password_length=$RS[0]["min_password_length"];
$password_type=$RS[0]["password_type"];
//擷取使用者布景
$RS=search("sys_users","account",$_SESSION["user_account"]);
if (empty($RS[0]["theme"])) {$user_theme="default";}
else {$user_theme=$RS[0]["theme"];}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title><?php echo $site_title ?></title>
  <link id="theme" rel="stylesheet" type="text/css" href="jquery/themes/<?php echo $user_theme ?>/easyui.css">
  <link rel="stylesheet" type="text/css" href="jquery/themes/icon.css">
  <script type="text/javascript" src="jquery/jquery.min.js"></script>
  <script type="text/javascript" src="jquery/jquery.easyui.min.js"></script>
  <script type="text/javascript" src="jquery/locale/easyui-lang-zh_TW.js"></script>
  <script type="text/javascript" src="ckeditor/ckeditor.js"></script>
  <style>
    a {text-decoration:none;}
    a:hover {text-decoration:underline;background-color:yellow;}
    #west {width:150px;}
    #west-inner {border-top:0px;border-right:0px;border-bottom:0px;}
    .nav {padding:5px;}
    .tab {padding:10px;}
    #north {height:55px;overflow:hidden;}
    #north-table {width:100%;border-spacing:0px}
    #north-left {text-align:left;padding:5px;}
    #north-right {text-align:right;padding:5px;}
  </style>
</head>
<body id="layout" class="easyui-layout">
  <div id="north" title="<?php echo $site_title ?>" data-options="region:'north',border:false,collapsible:true,tools:'#tools'">
    <form id="header-form" method="post">
      <table id="north-table">
        <tr>
          <td id="north-left" style="vertical-align:middle"><?php echo $greeting ?></td>
          <td id="north-right" style="vertical-align:middle">
            <span id="header_links">
<?php
$SQL="SELECT * FROM `sys_header_links`";
$RS=run_sql($SQL);
if (is_array($RS)) {
  for ($i=0; $i<count($RS); $i++) { 
    $title=$RS[$i]["title"];
    $url=$RS[$i]["url"];
    $target=$RS[$i]["target"];
    $hint=$RS[$i]["hint"];
?>
              <a href="<?php echo $url ?>" target="<?php echo $target ?>" title="<?php echo $hint ?>"><?php echo $title ?></a>．
<?php
    }
  }
?>
            </span>
            <select id="theme_sel" name="theme" class="easyui-combobox" style="width:120px;height:18px" panelHeight="320">
              <option value="default">主題布景</option>
<?php
$SQL="SELECT * FROM `sys_themes`";
$RS=run_sql($SQL);
if (is_array($RS)) {
  for ($i=0; $i<count($RS); $i++) { 
    $theme=$RS[$i]["theme"];
?>
              <option value="<?php echo $theme ?>"<?php if ($theme==$user_theme) {echo " selected";}?>><?php echo $theme ?></option>
<?php
    }
  }
?>
            </select>
          </td>
        </tr>
      </table>
    </form>
  </div>
  <div id="tools">
   <a href="javascript:logout()" class="icon-remove" title="登出"></a>
  </div>
  <div title="導覽" data-options="region:'west',border:true" id="west">
    <div class="easyui-accordion" id="west-inner">
<?php
$SQL="SELECT * FROM `sys_nav_blocks` WHERE display='Y' ORDER BY sequence";
$RS=run_sql($SQL);
if (is_array($RS)) {
  for ($i=0; $i<count($RS); $i++) { 
    $block_id=$RS[$i]["id"];
    $title=$RS[$i]["title"];
?>
      <div title="<?php echo $title ?>" class="nav">
<?php
    $SQL="SELECT * FROM `sys_nav_links` WHERE block_id=".$block_id.
         " ORDER BY sequence";
    $RS1=run_sql($SQL);
    if (is_array($RS1)) {
      for ($j=0; $j<count($RS1); $j++) { 
        $title=$RS1[$j]["title"];
        $url=$RS1[$j]["url"];
        $target=$RS1[$j]["target"];
        $hint=$RS1[$j]["hint"];
?>
        ．<a href="<?php echo $url ?>" target="<?php echo $target ?>" title="<?php echo $hint ?>"><?php echo $title ?></a><br>
<?php
        }
      }
?>
      </div>
<?php
    }
  }
?>
    </div>
  </div>
  <div data-options="region:'center',border:false,href:'sys.php'" id="center">
  </div>
  <script>
    <!-- 系統的載入與登出函式 -->
    function gohome(){
      $(function(){
        var p=$("#layout").layout("panel","center");
        p.panel({href:"sys.php"});
        });
      }
    function logout(){
      $(function(){
        $.messager.confirm("確認","確定要登出系統嗎?",function(btn){
          if (btn) {window.location.href="sys.php?op=logout";} 
          });
        });
      }
    <!-- 應用程式的載入函式 -->
<?php
$SQL="SELECT * FROM `sys_apps`";
$RS=run_sql($SQL);
if (is_array($RS)) {
  for ($i=0; $i<count($RS); $i++) { 
    $app_path="apps/".$RS[$i]["app_name"].".php?op=home";
?>
    function <?php echo $RS[$i]["app_name"] ?>(){
      $(function(){
        var p=$("#layout").layout("panel","center");
        p.panel({href:"<?php echo $app_path ?>"});
        });
      }
<?php
    }
  }
?>
    $(document).ready(function(){
      $("#theme_sel").combobox({
        onSelect:function(rec){
          var css="jquery/themes/" + rec.value + "/easyui.css";
          $("#theme").attr("href", css);
          $.get("sys.php?op=change_theme",{theme:rec.value});
          }
        });
      });
    <!-- 檔案上傳回呼函式 -->
    //不可放在 sys.php 內 (IE 會語法錯誤)
    function upload_file_callback(status,msg) { //必須在最上層, 不可放在 $ 內
      $("#uploading").css("visibility","hidden");
      $("#upload_file_dialog").dialog("close");
      $("#sys_files").datagrid("reload",{op:"list_files"});
      if (status=="success") {
        var msg=msg + '檔案上傳成功! <br>';
        var icon="info";
        }
      else {
        var msg=msg + '檔案上傳失敗, 請重新上傳! <br>';
        var icon="error";
        }
      $.messager.alert("上傳結果",msg,icon);
      }
    <!-- 應用程式上傳回呼函式 -->
    //不可放在 sys.php 內 (IE 會語法錯誤)
    function upload_app_callback(status,msg) { //必須在最上層, 不可放在 $ 內
      $("#upload_app_dialog").dialog("close");
      $("#sys_apps").datagrid("reload",{op:"list_apps"});
      if (status=="success") {
        var msg=msg + '檔案上傳全部成功! <br>';
        var icon="info";
        }
      else {
        var msg=msg + '檔案上傳失敗, 請重新上傳! <br>';
        var icon="error";
        }
      $.messager.alert("上傳結果",msg,icon);
      }
  </script>
</body>
</html>