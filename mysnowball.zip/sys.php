<?php
/*-----------------------------------------------------------------------------
Title        : EasyuiCMS 系統程式
Translator   : Tony Huang (tony1966@ms5.hinet.net)
Version      : v1.0.0
Prototype    : 2015-01-05
Last Updated : 2015-01-05
Usage        : 應用程式的主要功能寫在此檔中
Note         : 
請根據安裝檔內寫入 tabs 的各頁籤 $tab 與各作業 $op 撰寫功能
Ajax/DataTable 的 url 格式 : 
$url="sys.php?op=get_xxxx";
$url="sys.php?op=list_xxxx";
$url="sys.php?op=add_xxxx";
$url="sys.php?op=remove_xxxx";
$url="sys.php?op=update_xxxx";
-----------------------------------------------------------------------------*/
//啟動 session
session_start(); 
//header('Content-Type: text/html;charset=UTF-8');
//載入函式庫
require_once("db.php");           //匯入資料庫設定檔 (必須)
require_once("lib/mysql.php");    //匯入資料庫模組   (必須)
require_once("lib/tools.php");    //匯入工具模組     (選項)
require_once("lib/file.php");     //匯入file模組     (選項)
//擷取功能碼 op 分派工作
$op=$_REQUEST["op"];   //功能碼
//檢查是否已登入, 否則回登入畫面 (login 除外)
if ($op != "login") { //login 以外都要檢查
  if (!isset($_SESSION["user_account"])) {header("Location: index.php");}
  }
//設定台北時間
date_default_timezone_set("Asia/Taipei");
switch ($op) { 
  case "-" : { 
    break;
    } 
  case "home" : {
    break;
    }    
  case "login" : {
    //查詢認證政策
    $RS=search("sys_settings");
    $auth_policy=$RS[0]["auth_policy"]; //"normal"/"strict"
    //取得登入資訊
    $account=$_REQUEST["account"];
    $password=md5($_REQUEST["password"]);
    //驗證登入資訊
    $RS=search("sys_users","account",$account);
    $status="failure"; //預設不符合
    $msg=""; //失敗原因
    if (is_array($RS)) { //有找到帳號
      if ($auth_policy=="strict" && $RS[0]["locked"]=="Y") {
        $msg="帳號已被鎖住, 請洽管理員.";
        } //end of if
      else { //不是嚴格認證, 或嚴格認證但帳號尚未被鎖 : 比對密碼 
        if ($RS[0]["password"]===$password) { //密碼符合:登入成功
          $status="success"; //更新比對結果
          //設定 session 變數
          $_SESSION["user_account"]=$account;      //設定 account 
          $_SESSION["user_name"]=$RS[0]["name"];   //設定 name 
          $_SESSION["user_level"]=$RS[0]["level"]; //設定 level
          //更新 users 中的 login_count 與 last_login
          $data_array["login_count"]=$RS[0]["login_count"] + 1;
          $data_array["last_login"]=date("Y-m-d H:i:s");
          $ret=update("sys_users",$data_array,"account",$account);
          $data_array=null;
          //處理嚴格認證政策 : 失敗次數歸零
          if ($auth_policy=="strict") { //嚴格認證
            //重設 users 中的 login_fail_count
            $data_array["login_fail_count"]=0;
            $ret=update("sys_users",$data_array,"account",$account);
            } //end of if
          } //end of if
        else { //密碼不符合:登入失敗
          //處理嚴格認證政策 : 登入失敗次數增量
          if ($auth_policy=="strict") { //嚴格認證
            //增量 users 中的 login_fail_count
            $count=$RS[0]["login_fail_count"] + 1;
            if ($count >= 3) { //密碼錯誤 3 次以上
              $data_array["locked"]="Y"; //鎖住帳號
              $msg="密碼錯誤 3 次, 帳號已鎖住, 請洽管理員.";
              } //end of if
            else { //密碼錯誤未達 3 次
              $msg="密碼不符合, 還有 ".(3-$count)." 次機會.";
              } //end of else
            $data_array["login_fail_count"]=$count;
            $ret=update("sys_users",$data_array,"account",$account);
            } //end of if
          else { //普通認證="normal"
            $msg="密碼不符合, 請重新登入.";
            } //end of else
          } //end of else : 密碼不符合
        } //end of else : 不是嚴格認證, 或帳號尚未被鎖
      } //end of if:有找到帳號
    else {$msg="帳號不存在";} //沒找到帳號
    $arr["status"]=$status;
    $arr["msg"]=$msg;
    echo json_encode($arr);
    break;
    }
  case "logout" : {
    $ret=session_destroy(); //刪除 session 檔
    header("Location: index.php");
    break;
    }
  case "change_theme" : {
    $theme=$_REQUEST["theme"];
    $SQL="UPDATE sys_users SET theme='".$theme."' WHERE account='".
         $_SESSION["user_account"]."'";
    $result=run_sql($SQL);
    break;
    }
  case "news" : { 
    break;
    }
  case "board" : {
    $SQL="SELECT COUNT(*) FROM `sys_board`";
    $RS=run_sql($SQL);
    $total=$RS[0][0]; //紀錄總筆數
?>
<style>
  .arrow_box {
    margin-top:30px;
    padding: 15px;
    color: black;
    height: auto; 
    border-radius: 10px;
    position: relative;
    background: #ffffff;
    border: 1px solid #95B8E7;
    }
  .arrow_box:after, .arrow_box:before {
    bottom: 100%;
    left: 60px;
    border: solid transparent;
    content: " ";
    height: 0;
    width: 0;
    position: absolute;
    pointer-events: none;
    }
  .arrow_box:after {
    border-bottom-color: #ffffff;
    border-width: 15px;
    margin-left: -12px;
    }
  .arrow_box:before {
    border-bottom-color: #95B8E7;
    border-width: 16px;
    margin-left: -13px;
    }
</style>
<div class="tab" title="留言板">
  <div id="board" class="easyui-panel" title="留言板" style="padding:15px;height:100%" data-options="href:'sys.php?op=list_board',tools:'#board_tools',footer:'#board_pager',fit:true">
  </div>
  <div id="board_tools"> 
    <a href="#" id="add_post" class="icon-add" title="新增留言"></a>
    <a href="#" id="reload_board" class="icon-reload" title="重新載入"></a>
  </div>
  <div id="board_pager" class="easyui-pagination" data-options="total:<?php echo $total ?>,pageSize:10">
  </div>
  <!--新增留言對話框-->
  <div id="board_dialog" class="easyui-dialog" title="新增留言" style="width:360px;" data-options="closed:'true',buttons:'#board_buttons'">
    <form id="board_form" style="padding:10px">
      <div style="margin:10px">
        <label style="width:50px;display:inline-block;">主題 : </label>
        <input name="subject" type="text" class="easyui-textbox"  data-options="missingMessage:'此欄位為必填',required:true"  style="width:230px">
      </div>
      <div style="margin:10px">
        <label style="vertical-align:top;width:50px;display:inline-block;">內容 : </label>
        <textarea name="content" class="easyui-validatebox" data-options="required:true" style="resize:none;width:225px;height:80px;border-radius:5px;"></textarea>
      </div>
    </form>
  </div>
  <div id="board_buttons" style="padding-right:15px;">
    <a href="#" id="clear_post" class="easyui-linkbutton" iconCls="icon-clear" style="width:90px">重設</a>
    <a href="#" id="save_post" class="easyui-linkbutton" iconCls="icon-ok" style="width:90px">確定</a>
  </div>
</div>
<script>
  function remove_post(id){
    $.messager.confirm('確認','確定要刪除這筆留言?',function(r){
	    if(r){
        var params='op=remove_post&id=' + id;
        var callback=function(data,textStatus){
          if (data.status==='success'){
            $('#board_dialog').dialog("close");
            $('#board').panel('open').panel('refresh');
            $('#board_pager').pagination('refresh',{total:data.total});
            }
          else {$.messager.alert('訊息',"刪除留言失敗",'error');}
          }
        $.post('sys.php',params,callback,'json');
	      }
      });
    }
  $(function(){
    $("#board").panel({height:$("#center").height()});
    $("#add_post").bind("click",function(){
      $("#board_dialog").dialog("open").dialog("setTitle","新增留言");
      $("#board_form").form("clear");
      });
    $('#save_post').bind('click',function(){
      if (!$('#board_form').form('validate')){
        $.messager.alert('訊息','必填欄位未輸入!','warning');
        return;
        }
      var params=$('#board_form').serialize();
      params='op=add_post&' + params;
      var callback=function(data,textStatus){
        if (data.status==='success'){
          $('#board_dialog').dialog("close");
          $('#board').panel('open').panel('refresh');
          $('#board_pager').pagination('select',1);	
          $('#board_pager').pagination('refresh',{total:data.total});
          }
        else {$.messager.alert('訊息','留言失敗!','error');}
        }
      $.post('sys.php',params,callback,'json');
      });
    $("#clear_post").bind("click",function(){
      $("#board_form")[0].reset();
      });
    $("#reload_board").bind("click",function(){
      $('#board').panel('open').panel('refresh');
      });
    $("#board_pager").pagination({
      onRefresh:function(pageNumber,pageSize) {
        var url='sys.php?op=list_board&page=' + pageNumber + '&row=' + pageSize;
		    $('#board').panel('refresh',url);      
        },
      onSelectPage:function(pageNumber,pageSize){
        var url='sys.php?op=list_board&page=' + pageNumber + '&row=' + pageSize;
		    $('#board').panel('refresh',url);
        }
      });
    });
</script>
<?php
    break;
    }
  case "list_board" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    $SQL="SELECT COUNT(*) FROM `sys_board`";
    $RS=run_sql($SQL);
    $total=$RS[0][0]; //紀錄總筆數
    $SQL="SELECT * FROM sys_board ORDER BY post_time DESC ".
         "LIMIT ".$start.",".$rows;
    $RS=run_sql($SQL);
    if (is_array($RS)) {
      $icon=Array();
      $icon[]="ball";
      $icon[]="bambi";
      $icon[]="bear";
      $icon[]="corgi";
      $icon[]="cow";
      $icon[]="denchi";
      $icon[]="dorayaki";
      $icon[]="duck";
      $icon[]="kaeru";
      $icon[]="kuma";
      $icon[]="momo";
      $icon[]="saru";
      for ($i=0; $i<count($RS); $i++) {
        $gif=$icon[mt_rand(0,11)].".gif";
?>
  <div>
    <img src="images/<?php echo $gif ?>" style="margin-top:20px;border-width:0px;">     
    <?php echo $RS[$i]["poster"] ?> 張貼於 <?php echo $RS[$i]["post_time"] ?>
    主題 : <?php echo $RS[$i]["subject"] ?>
<?php
    if ($_SESSION["user_level"]==9) {
?>
    <a href="#" id="remove_post" class="easyui-linkbutton" data-options="iconCls:'icon-clear'" title="刪除留言" onclick="javascript:remove_post(<?php echo $RS[$i]['id'] ?>)"></a>
<?php
      }
?>
    <div class="arrow_box"><?php echo $RS[$i]["content"] ?></div>
  </div>
<?php
        }
      }
    else {
?>
  <div>沒有留言</div>
<?php
      }
    break;
    }
  case "add_post" : {
    $SQL="SELECT COUNT(*) FROM `sys_board`";
    $RS=run_sql($SQL);
    $total=$RS[0][0]; //紀錄總筆數
    $data_array["poster"]=$_SESSION["user_name"];
    $data_array["subject"]=$_REQUEST["subject"];
    $data_array["content"]=$_REQUEST["content"];
    $data_array["post_time"]=date("Y-m-d H:i:s");;
    $result=insert("sys_board", $data_array);
    if ($result===TRUE) {
      $status="success";
      ++$total;
      $msg="ok";
      }
    else {
      $status="failure";
      $msg="資料新增錯誤!";
      }
    $arr["status"]=$status;
    $arr["total"]=$total;
    $arr["msg"]=$msg;
    echo json_encode($arr);
    break;
    }    
  case "remove_post" : {
    $SQL="SELECT COUNT(*) FROM `sys_board`";
    $RS=run_sql($SQL);
    $total=$RS[0][0]; //紀錄總筆數
    $id=$_REQUEST["id"];
    $result=delete_record("sys_board", "id", $id);
    if ($result===TRUE) {$status="success";--$total;}
    else {$status="failure";}
    $arr["status"]=$status;
    $arr["total"]=$total;
    echo json_encode($arr);
    break;
    }
  case "files" : { 
?>
<div class="tab" title="檔案">
  <!--檔案 sys_files 列表-->
  <table id="sys_files" title="檔案列表" style="width:auto" data-options="tools:'#files_tools',toolbar:'#files_toolbar'"></table>
  <div id="files_tools"> 
    <a href="#" id="upload_file" class="icon-add" title="上傳檔案"></a>
    <a href="#" id="remove_file" class="icon-remove" title="刪除檔案"></a>
    <a href="#" id="reload_files" class="icon-reload" title="重新載入"></a>
    <a href="#" id="download_file" class="icon-save" title="下載另存"></a>
  </div>
  <div id="files_toolbar" style="text-align:right;padding:2px;">
    <select id="files_search_field" class="easyui-combobox" data-options="panelHeight:120">
      <option value="file_name">檔案名稱</option>
      <option value="file_note">檔案說明</option>
      <option value="file_type">檔案類型</option>
      <option value="uploader">上傳者</option>
      <option value="upload_time">上傳時間</option>
    </select>
    <input id="files_search_what" class="easyui-textbox">
  </div> 
  <!--上傳檔案表單對話框-->
  <div id="upload_file_dialog" class="easyui-dialog" title="上傳應用程式" style="width:420px;height:230px;"  data-options="closed:'true',buttons:'#upload_file_buttons'">
    <form id="upload_file_form" style="padding:15px" action="sys.php?op=upload_file" method="post" enctype="multipart/form-data" target="upload_target">
      <div style="margin:10px">
        <label style="width:60px;display:inline-block;">檔案 : </label>
        <input name="uploader" id="uploader" class="easyui-filebox" data-options="buttonText:'選擇檔案',prompt:'',required:true" style="width:280px">
      </div>
      <div style="margin:10px">
        <label style="width:60px;display:inline-block;">說明 : </label>
        <input name="file_note" class="easyui-textbox" style="width:280px" data-options="required:true">
      </div>
      <div style="margin:10px">
        <label style="width:60px;display:inline-block;">公開 : </label>
        <select name="public" class="easyui-combobox" data-options="panelHeight:50"  style="width:80px">
          <option value="Y">Y</option>
          <option value="N">N</option>
        </select>
        <img src="images/uploading.gif" id="uploading" style="visibility:hidden;margin-left:20px;">
      </div>
      <div>
        <iframe id="upload_target" name="upload_target" src="#"           style="width:0;height:0;border:0px solid #ffffff;">
        </iframe>
      </div>
    </form>
  </div>
  <div id="upload_file_buttons" style="padding-right:15px;">
    <a href="#" id="clear_file" class="easyui-linkbutton" iconCls="icon-clear" style="width:90px">重設</a>
    <a href="#" id="upload_file_go" class="easyui-linkbutton" iconCls="icon-ok" style="width:90px">上傳</a>
  </div>
</div> 
<script>
  $(function(){
    //檔案 sys_files
    $('#sys_files').datagrid({
      columns:[[
        {field:'id',title:'id',sortable:true},
        {field:'file_name',title:'檔案名稱',sortable:true},
        {field:'file_note',title:'檔案說明',sortable:true},
        {field:'file_type',title:'檔案類型',sortable:true},
        {field:'file_size',title:'檔案大小',align:'right',sortable:true},
        {field:'uploader',title:'上傳者',sortable:true},
        {field:'upload_time',title:'上傳時間',sortable:true},
        {field:'download_count',title:'下載次數',align:'right',sortable:true}
        ]],
      url:"sys.php",
      queryParams:{op:"list_files"},
      fit:true,
      fitColumns:true,
      singleSelect:true,
      pagination:true,
      pageSize:10,
      rownumbers:true,
      onDblClickRow:function(index,row){
        var url="sys.php?op=download_file&id=" + row.id + 
                "&file_name=" + row.file_name;
        window.open(url);
        }
      });
    $("#files_search_what").textbox({
      icons:[{
        iconCls:"icon-search",
        handler:function(e){
          $('#sys_files').datagrid("load",{
            op:"list_files",
            search_field:$("#files_search_field").combobox("getValue"),
            search_what:$("#files_search_what").textbox("getValue")
            });          
          }
        }]
      });
    $("#clear_file").bind("click",function(){
      $("#upload_file_form")[0].reset();
      });
    $("#upload_file_go").bind("click",function(){
      var arr=$("#uploader").filebox("getText").split("\\");
      filename=arr[arr.length-1];
      var reg=/^[a-zA-Z0-9._-]+$/g;
      if (reg.test(filename)) {
        $("#uploading").css("visibility","visible");
        $("#upload_file_form").form("submit");      
        }
      else {
        var msg="檔名必須為英數字, 小數點, 底線, 或減號之組合! " +
                "請更改檔名!<br>";
        $.messager.alert("訊息",msg,"warning");
        }
      });
    $("#upload_file").bind("click",function(){
      $("#upload_file_dialog").dialog("open").dialog("setTitle","上傳檔案");
      $("#upload_file_form").form("clear");
      });
    $("#remove_file").bind("click",function(){
      var row=$("#sys_files").datagrid("getSelected");
      if (row) {
        $.messager.confirm("確認","確定要刪除這個檔案嗎?",function(btn){
          if (btn){
            var params={op:"remove_file",id:row.id,file_name:row.file_name};
            var callback=function(data){
              if (data.status==="success"){
                $("#sys_files").datagrid("reload",{op:"list_files"});
                }
              else {$.messager.alert("訊息",data.msg,"error");}            
              };                
            $.post("sys.php",params,callback,"json");
            }
          })
        }
      else {$.messager.alert("訊息","請選擇要刪除的檔案!","info");}
      });
    $("#reload_files").bind("click",function(){
      $("#sys_files").datagrid("load",{op:"list_files"});
      });
    $("#download_file").bind("click",function(){
      var row=$("#sys_files").datagrid("getSelected");
      if (row) {
        var url="sys.php?op=download_file&id=" + row.id + 
                "&file_name=" + row.file_name;
        window.open(url);
        }
      else {$.messager.alert("訊息","請選擇要下載儲存的檔案!","info");}
      });
    }); //end of jQuery
</script>
<?php
    break;
    }
  case "list_files" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $sort=isset($_REQUEST['sort']) ? $_REQUEST['sort'] : 'upload_time';
    $order=isset($_REQUEST['order']) ? $_REQUEST['order'] : 'desc';
    if (isset($_REQUEST['search_field'])) { //有 search
      if ($_SESSION["user_level"]==9) { //管理員 (搜尋全部)
        $where="WHERE ".$_REQUEST['search_field']." LIKE '%".
               $_REQUEST['search_what']."%'";
        } 
      else { //非管理員 (搜尋公開的與自己上傳的)
        $where="WHERE (public='Y' OR uploader='".$_SESSION["user_name"].
               "') AND ".$_REQUEST['search_field']." LIKE '%".
               $_REQUEST['search_what']."%'";
        }
      }
    else { //無 search (顯示全部)
      if ($_SESSION["user_level"]==9) {$where="";} //管理員
      else { //非管理員 (只能看得到公開的與自己上傳的)
        $where="WHERE public='Y' OR uploader='".$_SESSION["user_name"]."'";
        }             
      } 
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    $SQL="SELECT COUNT(*) FROM `sys_files`";
    $RS=run_sql($SQL);
    $total=$RS[0][0]; //紀錄總筆數
    $SQL="SELECT * FROM sys_files ".$where." ORDER BY ".
         $sort." ".$order." LIMIT ".$start.",".$rows; 
    $RS=run_sql($SQL);
    $files=Array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
        $file_name="<a href='javascript:download_file(".'"'.
                   $RS[$i]["file_name"].'"'.")' target='_blank'>".
                   $RS[$i]["file_name"]."</a>";
        $files[$i]=Array("id" => $RS[$i]["id"],
                         "file_name" => $RS[$i]["file_name"],
                         "file_note" => $RS[$i]["file_note"],
                         "file_type" => $RS[$i]["file_type"],
                         "file_size" => $RS[$i]["file_size"],
                         "uploader" => $RS[$i]["uploader"],
                         "upload_time" => $RS[$i]["upload_time"],
                         "download_count" => $RS[$i]["download_count"]
                         );
        }
      }
    $arr=array("total" => $total, "rows" => $files);
    echo json_encode($arr);
    break;
    }
  case "upload_file" : { 
    $status="success";       //預設上傳成功
    $msg="";                 //執行結果字串
    $upload_dir="./files/";  //設定上傳目錄
    $file_note=$_REQUEST["file_note"];     //取得檔案說明
    $public=empty($_REQUEST["public"])?"Y":$_REQUEST["public"]; //取得公開與否
    $result=upload_file("uploader", $upload_dir);
    if (is_array($result)) {
      $msg .= $result["name"]." (".$result["size"]." bytes).<br>";
      $data_array["file_name"]=$result["name"];
      $data_array["file_note"]=$file_note;
      $data_array["file_type"]=$result["type"];
      $data_array["file_size"]=$result["size"];
      $data_array["uploader"]=$_SESSION["user_name"];
      $data_array["upload_time"]=date("Y-m-d H:i:s");
      $data_array["download_count"]=0;
      $data_array["public"]=$public;
      insert("sys_files", $data_array);
      } //end of if
    else { //上傳失敗
      $msg .= $file_name." 上傳失敗 (".$result["error"].")!<br>";
      $status="failure";
      } //end of else
    $para='"'.$status.'","'.$msg.'"'; //回傳回呼函式之參數
?>
<!-- 輸出 script 到 $op=files 中的 iframe 並執行其中的回呼函式 -->
<script language="javascript" type="text/javascript">
  window.top.window.upload_file_callback(<?php echo $para; ?>);
</script>
<?php
    break;
    }
  case "download_file" : {
    $id=$_REQUEST["id"];
    $file_name=$_REQUEST["file_name"];
    $file=dirname(__FILE__)."/files/".$file_name;
    if (file_exists($file)) {
      //增量下載次數
      $RS=search("sys_files","id",$id);
      if (is_array($RS)) {
        $data_array["download_count"]=$RS[0]["download_count"] + 1;
        $result=update("sys_files", $data_array, "id", $id);
        }
      //用 header 傳回檔案
      $file_size=filesize($file);
      header('Pragma: public');
      header('Expires: 0');
      header('Last-Modified: '.gmdate('D, d M Y H:i ').' GMT');
      header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
      header('Cache-Control: private', false);
      header('Content-Type: application/octet-stream');
      header('Content-Length: '.$file_size);
      header('Content-Disposition: attachment; filename="'.basename($file).'";');
      header('Content-Transfer-Encoding: binary');
      readfile($file);
      exit(0);
      }
    break;
    }
  case "remove_file" : {
    $id=$_REQUEST["id"];
    $file_name=$_REQUEST["file_name"];
    $status="success";
    $msg="";
    $result=delete_record("sys_files", "id", $id);
    if ($result!==TRUE) {
      $status="failure";
      $msg="刪除資料表 sys_files 紀錄失敗!";
      }
    $result=delete_file("./files/".$file_name);
    if ($result!==TRUE) {
      $status="failure";
      $msg="刪除檔案 "."./files/".$file_name."失敗!";
      }
    $arr["status"]=$status;
    $arr["msg"]=$msg;
    echo json_encode($arr);
    break;
    }
  case "messages" : { 
    break;
    }
  case "user_settings" : { 
    //查詢目前使用者設定
    $RS=search("sys_users","account",$_SESSION["user_account"]);
    $password=$RS[0]["password"];
    $theme=$RS[0]["theme"];
    $email=$RS[0]["email"];
    $mobile_phone=$RS[0]["mobile_phone"];
?>
<div class="tab" title="使用者設定">
  <!--使用者設定表單-->
  <div id="user_settings" class="easyui-panel" title="使用者設定" style="width:auto;padding:5px;" data-options="tools:'#user_settings_tools'">
    <form id="user_settings_form" style="padding:5px">
      <div style="margin:10px">
        <label style="width:100px;display:inline-block;">密碼 : </label>
        <input name="password" type="password" class="easyui-textbox"  data-options="missingMessage:'此欄位為必填',required:true" style="width:230px">
      </div>
      <div style="margin:10px">
        <label style="width:100px;display:inline-block;">布景主題 : </label>
        <select name="theme" class="easyui-combobox" style="width:160px;"  data-options="panelMinHeight:200">
<?php
    $SQL="SELECT * FROM `sys_themes`";
    $RS=run_sql($SQL);
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
?>
          <option value="<?php echo $RS[$i]["theme"] ?>"<?php if ($theme==$RS[$i]["theme"]) {echo " selected";}?>><?php echo $RS[$i]["theme"] ?></option>
<?php
        }
      }
?>
        </select>
      </div>
      <div style="margin:10px">
        <label style="width:100px;display:inline-block;">E-mail : </label>
        <input name="email" type="text" class="easyui-textbox" data-options="validType:'email'" style="width:230px">
      </div>
      <div style="margin:10px">
        <label style="width:100px;display:inline-block;">行動電話 : </label>
        <input name="mobile_phone" type="text" class="easyui-textbox" style="width:230px">
      </div>
    </form>
  </div>
  <div id="user_settings_tools">
    <a href="#" id="save_user_settings" class="icon-save" title="儲存"></a>
  </div>
</div>
<script>
  $(document).ready(function(){
    //使用者設定 user_settings
    $("#user_settings_form").form("load",
      {email:"<?php echo $email ?>",
       mobile_phone:"<?php echo $mobile_phone ?>"
       });
    $('#save_user_settings').bind('click',function(){
      $("#user_settings_form").form("submit",{
        url:"sys.php",
        method:"post",
        queryParams:{op:"update_user_settings"},
        success:function(data){
          var data=eval('(' + data + ')');
          if (data.status==='success'){
            $.messager.alert('訊息','使用者設定更新成功!',"info",
              function(btn){if (btn){window.location.href="main.php";}}
              ); //無效???
            }
          else {$.messager.alert('訊息','使用者設定更新失敗!',"error");}
          }
        });
      });
    });
</script>  
<?php
    break;
    }
  case "get_user_themes" : { //user_settings 使用
    $selected=$_REQUST["selected"];
    $RS=search("sys_themes");
    $arr=array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
        if ($selected==$RS[$i]["theme"]) {
          $arr[$i]=Array("theme" => $RS[$i]["theme"],
                         "selected" => true);
          }
        else {$arr[$i]=Array("theme" => $RS[$i]["theme"]);}
        }
      }
    echo json_encode($arr);
    break;
    }
  case "update_user_settings" : {
    $data_array["password"]=md5($_REQUEST["password"]);
    $data_array["theme"]=$_REQUEST["theme"];
    $data_array["email"]=$_REQUEST["email"];
    $data_array["mobile_phone"]=$_REQUEST["mobile_phone"];
    $result=update("sys_users",$data_array,"account",$_SESSION["user_account"]);
    if ($result===TRUE) {$status="success";}
    else {$status="failure";}
    $arr["status"]=$status;
    echo json_encode($arr);
    break;
    }
  case "sys_settings" : { //輸出系統設定表單
    //查詢目前系統設定
    $RS=search("sys_settings");
    $sys_theme=$RS[0]["sys_theme"];
    $site_title=$RS[0]["site_title"];
    $system_state=$RS[0]["system_state"];
    $auth_policy=$RS[0]["auth_policy"];
    $min_password_length=$RS[0]["min_password_length"];
    $password_type=$RS[0]["password_type"];
    //製作主題布景選單
    $RS=search("sys_themes");
    $arr=Array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) { 
        $theme=$RS[$i]["theme"];
        if ($theme==$sys_theme) {$selected=' selected';}
        else {$selected='';}
        $arr[]="<option value='".$theme."'".$selected.">".
               $theme."</option>";
        }
      }
    $theme_options=implode("\r\n",$arr);
    //製作系統狀態 radio 群組
    $radio="<input type='radio' name='system_state' "; //共同部分
    if ($system_state=="active") { 
      $system_state_radio=$radio." value='active' checked>工作中 ".
                          $radio." value='inactive'>維護中"; 
      } //end of if
    else { 
      $system_state_radio=$radio." value='active'>工作中 ".
                          $radio." value='inactive' checked>維護中";
      } //end of else
    //製作使用者認證政策 radio 群組
    $radio="<input type='radio' name='auth_policy' "; //共同部分
    if ($auth_policy=="normal") { 
      $auth_policy_radio=$radio." value='normal' checked>普通 ".
                         $radio." value='strict'>嚴格"; 
      } //end of if
    else { 
      $auth_policy_radio=$radio." value='normal'>普通 ".
                         $radio." value='strict' checked>嚴格";
      } //end of else
    //製作密碼類型選單
    $arr=array();
    $arr[]="不限制";
    $arr[]="必須含有英文字母,數字至少一個";
    $arr[]="必須含有大小寫英文字母至少一個";
    $arr[]="必須含有大小寫英文字母,數字至少一個";
    $arr[]="必須含有大小寫英文字母,數字,特殊符號至少一個";
    $password_type_sel="<select name='password_type' style='width:300px;' ".
                       "class='easyui-combobox' data-options='panelHeight:120'>";
    for ($i=0; $i<5; $i++) {
      if ($i==$password_type) {$selected=" selected";}
      else {$selected="";}
      $password_type_sel .= "<option value='".$i."'".$selected.">".
                            $i." ".$arr[$i]."</option>";
      } //end of for 
    $password_type_sel .= "</select>";
?>
<div class="tab" title="系統設定">
  <!--系統設定表單-->
  <div id="sys_settings" class="easyui-panel" title="系統設定" style="width:auto;padding:5px;" data-options="tools:'#sys_settings_tools'">
    <form id="sys_settings_form" style="padding:5px">
      <table style="border-width:0px;width:100%;border-spacing:2px;">
        <tr>
          <td style="width:50%;padding:3px;">
            <label style="width:100px;display:inline-block;">網站標題 : </label>
            <input name="site_title" type="text" class="easyui-textbox" data-options="missingMessage:'此欄位為必填',required:true" style="min-width:300px;" value="<?php echo $site_title ?>">
          </td>
          <td style="width:50%;padding:3px;">
            <label style="width:100px;display:inline-block;">系統主題布景 : </label>
            <select name="sys_theme" class="easyui-combobox" style="width:120px;" data-options="panelHeight:320">
              <option value="default">主題布景</option>
              <?php echo $theme_options ?>
            </select>
          </td>
        </tr>
        <tr>
          <td style="width:50%;padding:3px;">
            <label style="width:100px;display:inline-block;">系統運行狀態 : </label>
            <?php echo $system_state_radio ?>
          </td>
          <td style="width:50%;padding:3px;">
            <label style="width:100px;display:inline-block;">密碼最短長度 : </label>
            <input id="min_password_length" name="min_password_length" value="<?php echo $min_password_length ?>" style="min-width:120px;">
          </td>
        </tr>
        <tr>
          <td style="width:50%;padding:3px;">
            <label style="width:100px;display:inline-block;">使用者認證政策 : </label>
            <?php echo $auth_policy_radio ?>
          </td>
          <td style="width:50%;padding:3px;">
            <label style="width:100px;display:inline-block;">密碼字元類型 : </label>
            <?php echo $password_type_sel ?>
          </td>
        </tr>
      </table>
    </form>
  </div>
  <div id="sys_settings_tools">
    <a href="#" id="reload_sys_settings" class="icon-reload" title="重新載入"></a>
    <a href="#" id="save_sys_settings" class="icon-save" title="儲存"></a>
  </div>
</div>
<script>
  $(document).ready(function(){
    //系統設定 sys_settings
    $("#min_password_length").numberspinner({
      min:4,
      max:12,
      increment:1,
      required:true,
      missingMessage:'此欄位為必填'
      });
    $('#reload_sys_settings').bind('click',function(){
      $('#sys_settings').panel('open').panel('refresh');
      });
    $('#save_sys_settings').bind('click',function(){
      var params=$('#sys_settings_form').serialize();
      params='op=update_sys_settings&' + params;
      var callback=function(data,textStatus){
        if (data.status==='success'){
          $.messager.alert('訊息','系統設定更新成功!','info');
          }
        else {$.messager.alert('訊息','系統設定更新失敗!','error');}
        }
      $.post('sys.php',params,callback,'json');
      });
    });
</script>  
<?php
    break;
    } 
  case "update_sys_settings" : {
    $data_array["sys_theme"]=$_REQUEST["sys_theme"];
    $data_array["site_title"]=$_REQUEST["site_title"];
    $data_array["system_state"]=$_REQUEST["system_state"];
    $data_array["auth_policy"]=$_REQUEST["auth_policy"];
    $data_array["min_password_length"]=$_REQUEST["min_password_length"];
    $data_array["password_type"]=$_REQUEST["password_type"];
    $result=update_all("sys_settings", $data_array);
    if ($result===TRUE) {$status="success";}
    else {$status="failure";}
    $arr["status"]=$status;
    echo json_encode($arr);
    break;
    }       
  case "users" : {
?>
<div class="tab" title="使用者">
  <!--使用者列表-->
  <table id="sys_users" title="使用者列表" style="width:auto" data-options="tools:'#sys_users_tools',toolbar:'#sys_users_search_bar'"></table>
  <div id="sys_users_tools">
    <a href="#" id="add_user" class="icon-add" title="新增"></a>
    <a href="#" id="edit_user" class="icon-edit" title="編輯"></a>
    <a href="#" id="remove_user" class="icon-remove" title="刪除"></a>
    <a href="#" id="reload_users" class="icon-reload" title="重新載入"></a>
  </div>
  <div id="sys_users_search_bar" style="text-align:right;padding:2px;">
    <select id="users_search_field" class="easyui-combobox" data-options="panelHeight:90">
      <option value="name">姓名</option>
      <option value="account">帳號</option>
      <option value="email">E-mail</option>
      <option value="mobile_phone">行動電話</option>
    </select>
    <input id="users_search_what" class="easyui-textbox">
  </div>
  <!--新增&編輯 sys_users 表單對話框-->
  <div id="user_dialog" class="easyui-dialog" title="新增使用者" style="width:360px;height:370px;" data-options="closed:'true',buttons:'#login_buttons'">
    <form id="user_form" style="padding:10px">
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">帳號 : </label>
        <input name="account" type="text" class="easyui-textbox" data-options="missingMessage:'此欄位為必填',required:true"  style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">密碼 : </label>
        <input name="password" type="text" class="easyui-textbox"  data-options="missingMessage:'此欄位為必填',required:true" style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">姓名 : </label>
        <input name="name" type="text" class="easyui-textbox"  data-options="missingMessage:'此欄位為必填',required:true" style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">等級 : </label>
        <select name="level" class="easyui-combobox">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9 (管理者)</option>
        </select>
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">布景主題 : </label>
        <select name="theme" class="easyui-combobox" style="width:160px;"  data-options="url:'sys.php?op=get_themes',valueField:'theme',textField:'theme',panelMinHeight:200">
        </select>
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">E-mail : </label>
        <input name="email" type="text" class="easyui-textbox" data-options="validType:'email'" style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">行動電話 : </label>
        <input name="mobile_phone" type="text" class="easyui-textbox" style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">郵件遞送 : </label>
        <select name="maillist" class="easyui-combobox" data-options="panelHeight:60">
          <option value="N">N</option>
          <option value="Y">Y</option>
        </select>
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">簡訊遞送 : </label>
        <select name="send_sms" class="easyui-combobox" data-options="panelHeight:60">
          <option value="N">N</option>
          <option value="Y">Y</option>
        </select>
        <input type="hidden" id="user_op" value="">
        <input type="hidden" id="user_id" value="">
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">帳號鎖住 : </label>
        <select name="locked" class="easyui-combobox" data-options="panelHeight:60">
          <option value="N">N</option>
          <option value="Y">Y</option>
        </select>
        <input type="hidden" id="user_op" value="">
        <input type="hidden" id="user_id" value="">
      </div>
    </form>
  </div>
  <div id="login_buttons" style="padding-right:15px;">
    <a href="#" id="clear_user" class="easyui-linkbutton" iconCls="icon-clear" style="width:90px">重設</a>
    <a href="#" id="save_user" class="easyui-linkbutton" iconCls="icon-ok" style="width:90px">確定</a>
  </div>
</div>
<script>
  $(function(){
    $('#sys_users').datagrid({
      columns:[[
        {field:'id',title:'id',sortable:true},
        {field:'account',title:'帳號',sortable:true},
        {field:'password',title:'密碼',sortable:true,hidden:true},
        {field:'name',title:'姓名',sortable:true},
        {field:'level',title:'等級',align:'center',sortable:true},
        {field:'theme',title:'布景主題',sortable:true},
        {field:'email',title:'E-mail',sortable:true},
        {field:'mobile_phone',title:'行動電話',sortable:true},
        {field:'maillist',title:'郵件遞送',sortable:true},
        {field:'send_sms',title:'簡訊遞送',sortable:true},
        {field:'login_count',title:'登入次數',align:'right',sortable:true},
        {field:'login_fail_count',title:'失敗次數',align:'right',sortable:true},
        {field:'last_login',title:'最近登入',sortable:true},
        {field:'locked',title:'鎖住',align:'center',sortable:true}
        ]],
      url:"sys.php",
      queryParams:{op:"list_users"},
      fitColumns:true,
      singleSelect:true,
      pagination:true,
      pageSize:10,
      rownumbers:true
      });
    $("#users_search_what").textbox({
      icons:[{
        iconCls:"icon-search",
        handler:function(e){
          $('#sys_users').datagrid("load",{
            op:"list_users",
            search_field:$("#users_search_field").combobox("getValue"),
            search_what:$("#users_search_what").textbox("getValue")
            });          
          }
        }]
      });
    $("#clear_user").bind("click",function(){
      $("#user_form")[0].reset();
      });
    $("#save_user").bind("click",function(){
      var op=$("#user_op").val();
      var id=$("#user_id").val();
      $("#user_form").form("submit",{
        url:"sys.php",
        method:"post",
        queryParams:{op:op,id:id},
        success:function(data){
          var data=eval('(' + data + ')');
          $("#user_dialog").dialog("close");
          if (data.status==="success") {
            $("#sys_users").datagrid("reload",{op:"list_users"});           
            }
          else {$.messager.alert("訊息",data.msg,"error");}          
          }
        });
      });
    $("#add_user").bind("click",function(){
      $("#user_dialog").dialog("open").dialog("setTitle","新增使用者");
      $("#user_form").form("clear");
      $("#user_op").val("add_user");
      });
    $("#edit_user").bind("click",function(){
      var row=$("#sys_users").datagrid("getSelected");
      if (row) {
        $("#user_dialog").dialog("open").dialog("setTitle","編輯使用者");
        $("#user_form").form("load",row);
        }
      $("#user_op").val("update_user");
      $("#user_id").val(row.id);
      });
    $("#remove_user").bind("click",function(){
      var row=$("#sys_users").datagrid("getSelected");
      if (row) {
        $.messager.confirm("確認","確定要刪除這個使用者嗎?",function(btn){
          if (btn){
            var params={op:"remove_user",id:row.id};
            var callback=function(data){
              if (data.status==="success"){
                $("#sys_users").datagrid("reload",{op:"list_users"});
                }
              else {$.messager.alert("訊息","刪除使用者失敗!","error");}            
              };                
            $.post("sys.php",params,callback,"json");
            }
          })
        }
      });
    $("#reload_users").bind("click",function(){
      $("#sys_users").datagrid("load",{op:"list_users"});
      });
    });
</script>
<?php
    break;
    }
  case "list_users" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $sort=isset($_REQUEST['sort']) ? $_REQUEST['sort'] : 'name';
    $order=isset($_REQUEST['order']) ? $_REQUEST['order'] : 'asc';
    if (isset($_REQUEST['search_field'])) { //有 search
      $where="WHERE ".$_REQUEST['search_field']." LIKE '%".
             $_REQUEST['search_what']."%'";
      }
    else {$where="";} //無 search
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    $SQL="SELECT COUNT(*) FROM `sys_users`";
    $RS=run_sql($SQL);
    $total=$RS[0][0]; //紀錄總筆數
    $SQL="SELECT * FROM sys_users ".$where." ORDER BY ".
         $sort." ".$order." LIMIT ".$start.",".$rows; 
    $RS=run_sql($SQL);
    $users=Array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
        $users[$i]=Array("id" => $RS[$i]["id"],
                         "name" => $RS[$i]["name"],
                         "account" => $RS[$i]["account"],
                         "password" => $RS[$i]["password"],
                         "level" => $RS[$i]["level"],
                         "theme" => $RS[$i]["theme"],
                         "email" => $RS[$i]["email"],
                         "mobile_phone" => $RS[$i]["mobile_phone"],
                         "maillist" => $RS[$i]["maillist"],
                         "send_sms" => $RS[$i]["send_sms"],
                         "login_count" => $RS[$i]["login_count"],
                         "login_fail_count" => $RS[$i]["login_fail_count"],
                         "last_login" => $RS[$i]["last_login"],
                         "locked" => $RS[$i]["locked"]
                         );
        }
      }
    $arr=array("total" => $total, "rows" => $users);
    echo json_encode($arr);
    break;
    }
  case "add_user" : { 
    $RS=search("sys_users", "account", $_REQUEST["account"]);
    if (count($RS) >= 1) {
      $status="failure";
      $msg="帳號已存在!";
      }
    else {
      $data_array["account"]=$_REQUEST["account"];
      $data_array["name"]=$_REQUEST["name"];
      $data_array["password"]=md5($_REQUEST["password"]);
      $data_array["email"]=$_REQUEST["email"];
      $data_array["mobile_phone"]=$_REQUEST["mobile_phone"];
      $level=empty($_REQUEST["level"])?1:$_REQUEST["level"];
      $data_array["level"]=$level;
      $theme=empty($_REQUEST["theme"])?"default":$_REQUEST["theme"];
      $data_array["theme"]=$theme;
      $maillist=empty($_REQUEST["maillist"])?"N":$_REQUEST["maillist"];
      $data_array["maillist"]=$maillist;
      $send_sms=empty($_REQUEST["send_sms"])?"N":$_REQUEST["send_sms"];
      $data_array["send_sms"]=$send_sms;
      $locked=empty($_REQUEST["locked"])?"N":$_REQUEST["locked"];
      $data_array["locked"]=$locked;
      $result=insert("sys_users", $data_array);
      if ($result===TRUE) {
        $status="success";
        $msg="ok";
        }
      else {
        $status="failure";
        $msg="新增使用者失敗!";
        }
      }
    $arr["status"]=$status;
    $arr["msg"]=$msg;
    echo json_encode($arr);
    break;
    }
  case "get_themes" : { //user_dialog 使用
    $RS=search("sys_themes");
    $arr=array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
        $arr[$i]=Array("theme" => $RS[$i]["theme"]);
        }
      }
    echo json_encode($arr);
    break;
    }
  case "update_user" : {
    $id=$_REQUEST["id"];
    $data_array["name"]=$_REQUEST["name"];
    $data_array["password"]=$_REQUEST["password"];
    $data_array["email"]=$_REQUEST["email"];
    $data_array["mobile_phone"]=$_REQUEST["mobile_phone"];
    $data_array["level"]=$_REQUEST["level"];
    $data_array["theme"]=$_REQUEST["theme"];
    $data_array["maillist"]=$_REQUEST["maillist"];
    $data_array["send_sms"]=$_REQUEST["send_sms"];
    $data_array["locked"]=$_REQUEST["locked"];
    $result=update("sys_users", $data_array, "id", $id);
    if ($result===TRUE) {
      $status="success";
      $msg="ok";
      }
    else {
      $status="failure";
      $msg="更新使用者失敗!";
      }
    $arr["status"]=$status;
    $arr["msg"]=$msg;
    echo json_encode($arr);
    break;
    }
  case "remove_user" : {
    $id=$_REQUEST["id"];
    $result=delete_record("sys_users", "id", $id);
    if ($result===TRUE) {$status="success";}
    else {$status="failure";}
    $arr["status"]=$status;
    echo json_encode($arr);
    break;
    }
  case "header_links" : { 
?>
<div class="tab" title="標頭連結">
  <!--標頭連結 sys_header_links 列表-->
  <table id="sys_header_links" title="標頭連結列表" style="width:auto" data-options="tools:'#header_links_tools'"></table>
  <div id="header_links_tools">    
    <a href="#" id="add_header_link" class="icon-add" title="新增"></a>
    <a href="#" id="edit_header_link" class="icon-edit" title="編輯"></a>
    <a href="#" id="remove_header_link" class="icon-remove" title="刪除"></a>
    <a href="#" id="reload_header_links" class="icon-reload" title="重新載入"></a>
  </div>
  <!--新增&編輯 sys_header_links 表單對話框-->
  <div id="header_link_dialog" class="easyui-dialog" title="新增使用者" style="width:360px;height:240px;"  data-options="closed:'true',buttons:'#header_link_buttons'">
    <form id="header_link_form" style="padding:10px">
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">標題 : </label>
        <input name="title" type="text" class="easyui-textbox"  data-options="missingMessage:'此欄位為必填',required:true"  style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">網址 : </label>
        <input name="url" type="text" class="easyui-textbox"  data-options="missingMessage:'此欄位為必填',required:true"  style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">目標 : </label>
        <select name="target" class="easyui-combobox" data-options="panelHeight:50">
          <option value="_self">_self</option>
          <option value="_blank">_blank</option>
        </select>
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">順序 : </label>
        <input id="header_link_sequence" name="sequence">
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">提示 : </label>
        <input name="hint" type="text" class="easyui-textbox" style="width:230px">
        <input type="hidden" id="header_link_op" value="">
        <input type="hidden" id="header_link_id" value="">
      </div>
    </form>
  </div>
  <div id="header_link_buttons" style="padding-right:15px;">
    <a href="#" id="clear_header_link" class="easyui-linkbutton" iconCls="icon-clear" style="width:90px">重設</a>
    <a href="#" id="save_header_link" class="easyui-linkbutton" iconCls="icon-ok" style="width:90px">確定</a>
  </div>
</div>
<script>
  $(function(){
    //標頭連結 sys_header_links
    $('#sys_header_links').datagrid({
      columns:[[
        {field:'id',title:'id',sortable:true},
        {field:'title',title:'title',sortable:true},
        {field:'url',title:'url',sortable:true},
        {field:'target',title:'target',sortable:true},
        {field:'sequence',title:'sequence',align:'center',sortable:true},
        {field:'hint',title:'hint',sortable:true}
        ]],
      url:"sys.php",
      queryParams:{op:"list_header_links"},
      fitColumns:true,
      singleSelect:true,
      rownumbers:true
      });
    $("#header_link_sequence").numberspinner({
      min:0,
      max:99,
      increment:1,
      value:"0",
      required:true,
      missingMessage:'此欄位為必填'
      });
    $("#clear_header_link").bind("click",function(){
      $("#header_link_form")[0].reset();
      });
    $("#save_header_link").bind("click",function(){
      var op=$("#header_link_op").val();
      var id=$("#header_link_id").val();
      $("#header_link_form").form("submit",{
        url:"sys.php",
        method:"post",
        queryParams:{op:op,id:id},
        success:function(data){
          var data=eval('(' + data + ')');
          $("#header_link_dialog").dialog("close");
          if (data.status==="success") {
            $("#sys_header_links").datagrid("reload",{op:"list_header_links"});
            //window.location.href="main.php";
            }
          else {
            $.messager.alert("訊息",data.msg,"error");    
            }          
          }
        });
      });
    $("#add_header_link").bind("click",function(){
      $("#header_link_dialog").dialog("open").dialog("setTitle","新增連結");
      $("#header_link_form").form("clear");
      $("#header_link_op").val("add_header_link");
      });
    $("#edit_header_link").bind("click",function(){
      var row=$("#sys_header_links").datagrid("getSelected");
      if (row) {
        $("#header_link_dialog").dialog("open").dialog("setTitle","編輯連結");
        $("#header_link_form").form("load",row);
        }
      $("#header_link_op").val("update_header_link");
      $("#header_link_id").val(row.id);
      });
    $("#remove_header_link").bind("click",function(){
      var row=$("#sys_header_links").datagrid("getSelected");
      if (row) {
        $.messager.confirm("確認","確定要刪除這個連結嗎?",function(btn){
          if (btn){
            var params={op:"remove_header_link",id:row.id};
            var callback=function(data){
              if (data.status==="success"){
                $("#sys_header_links").datagrid("reload",{op:"list_header_links"});
                }
              else {$.messager.alert("訊息","刪除連結失敗!","error");}            
              };                
            $.post("sys.php",params,callback,"json");
            }
          })
        }
      });
    $("#reload_header_links").bind("click",function(){
      $("#sys_header_links").datagrid("load",{op:"list_header_links"});
      });
    });
</script>
<?php
    break;
    }
  case "list_header_links" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $sort=isset($_REQUEST['sort']) ? $_REQUEST['sort'] : 'id';
    $order=isset($_REQUEST['order']) ? $_REQUEST['order'] : 'asc';
    if (isset($_REQUEST['search_field'])) { //有 search
      $where="WHERE ".$_REQUEST['search_field']." LIKE '%".
             $_REQUEST['search_what']."%'";
      }
    else {$where="";} //無 search
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    $SQL="SELECT COUNT(*) FROM `sys_header_links`";
    $RS=run_sql($SQL);
    $total=$RS[0][0]; //紀錄總筆數
    $SQL="SELECT * FROM sys_header_links ".$where." ORDER BY ".
         $sort." ".$order." LIMIT ".$start.",".$rows; 
    $RS=run_sql($SQL);
    $header_links=Array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
         $header_links[$i]=Array("id" => $RS[$i]["id"],
                                 "title" => $RS[$i]["title"],
                                 "url" => $RS[$i]["url"],
                                 "target" => $RS[$i]["target"],
                                 "sequence" => $RS[$i]["sequence"],
                                 "hint" => $RS[$i]["hint"]
                                 );
         }
       }
    $arr=array("total" => $total, "rows" => $header_links);
    echo json_encode($arr);
    break;
    }
  case "add_header_link" : {
    $data_array["title"]=$_REQUEST["title"];
    $data_array["url"]=$_REQUEST["url"];
    $data_array["target"]=$_REQUEST["target"];
    $sequence=empty($_REQUEST["sequence"])?0:$_REQUEST["sequence"];
    $data_array["sequence"]=$sequence;
    $data_array["hint"]=$_REQUEST["hint"];
    $result=insert("sys_header_links", $data_array);
    if ($result===TRUE) {
      $status="success";
      $msg="ok";
      }
    else {
      $status="failure";
      $msg="資料新增錯誤!";
      }
    $arr["status"]=$status;
    $arr["msg"]=$msg;
    echo json_encode($arr);
    break;
    }
  case "update_header_link" : {
    $id=$_REQUEST["id"];
    $data_array["title"]=$_REQUEST["title"];
    $data_array["url"]=$_REQUEST["url"];
    $data_array["target"]=$_REQUEST["target"];
    $data_array["sequence"]=$_REQUEST["sequence"];
    $data_array["hint"]=$_REQUEST["hint"];
    $result=update("sys_header_links", $data_array, "id", $id);
    if ($result===TRUE) {
      $status="success";
      $msg="ok";
      }
    else {
      $status="failure";
      $msg="資料更新錯誤!";
      }
    $arr["status"]=$status;
    $arr["msg"]=$msg;
    echo json_encode($arr);
    break;
    }
  case "remove_header_link" : {
    $id=$_REQUEST["id"];
    $result=delete_record("sys_header_links", "id", $id);
    if ($result===TRUE) {$status="success";}
    else {$status="failure";}
    $arr["status"]=$status;
    echo json_encode($arr);
    break;
    }
  case "nav_blocks" : { 
?>
<div class="tab" title="導覽區">
  <!--導覽區塊 sys_nav_blocks 列表-->
  <table id="sys_nav_blocks" title="導覽區塊列表" style="width:auto" data-options="tools:'#nav_blocks_tools'"></table>
  <div id="nav_blocks_tools">    
    <a href="#" id="add_nav_block" class="icon-add" title="新增"></a>
    <a href="#" id="edit_nav_block" class="icon-edit" title="編輯"></a>
    <a href="#" id="remove_nav_block" class="icon-remove" title="刪除"></a>
    <a href="#" id="reload_nav_block" class="icon-reload" title="重新載入"></a>
  </div><br>
  <!--新增&編輯 sys_nav_blocks 表單對話框-->
  <div id="nav_block_dialog" class="easyui-dialog" title="新增導覽區塊" style="width:360px;height:180px;" data-options="closed:'true',buttons:'#nav_block_buttons'">
    <form id="nav_block_form" style="padding:10px">
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">標題 : </label>
        <input name="title" type="text" class="easyui-textbox"  data-options="missingMessage:'此欄位為必填',required:true"  style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">順序 : </label>
        <input id="nav_block_sequence" name="sequence">
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">顯示 : </label>
        <select name="display" class="easyui-combobox" data-options="panelHeight:50">
          <option value="Y">Y</option>
          <option value="N">N</option>
        </select>
        <input type="hidden" id="nav_block_op" value="">
        <input type="hidden" id="nav_block_id" value="">
      </div>
    </form>
  </div>
  <div id="nav_block_buttons" style="padding-right:15px;">
    <a href="#" id="clear_nav_block" class="easyui-linkbutton" iconCls="icon-clear" style="width:90px">重設</a>
    <a href="#" id="save_nav_block" class="easyui-linkbutton" iconCls="icon-ok" style="width:90px">確定</a>
  </div>
  <!--導覽區連結 sys_nav_links 列表-->
  <table id="sys_nav_links" title="導覽區連結列表" style="width:auto" data-options="tools:'#nav_links_tools'"></table>
  <div id="nav_links_tools">    
    <a href="#" id="add_nav_link" class="icon-add" title="新增"></a>
    <a href="#" id="edit_nav_link" class="icon-edit" title="編輯"></a>
    <a href="#" id="remove_nav_link" class="icon-remove" title="刪除"></a>
    <a href="#" id="reload_nav_links" class="icon-reload" title="重新載入"></a>
  </div>
  <!--新增&編輯 sys_nav_links 表單對話框-->
  <div id="nav_link_dialog" class="easyui-dialog" title="新增使用者" style="width:360px;height:260px;" data-options="closed:'true',buttons:'#nav_link_buttons'">
    <form id="nav_link_form" style="padding:10px">
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">標題 : </label>
        <input name="title" type="text" class="easyui-textbox"  data-options="missingMessage:'此欄位為必填',required:true"  style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">網址 : </label>
        <input name="url" type="text" class="easyui-textbox"  data-options="missingMessage:'此欄位為必填',required:true" style="width:230px">
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">目標 : </label>
        <select name="target" class="easyui-combobox" data-options="panelHeight:50">
          <option value="_self">_self</option>
          <option value="_blank">_blank</option>
        </select>
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">順序 : </label>
        <input id="nav_link_sequence" name="sequence" style="width:100px;">
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">導覽區塊 : </label>
        <select id="block_id" name="block_id" class="easyui-combobox"   panelMinHeight="120" style="width:160px;" data-options="
        missingMessage:'此欄位為必填',
        required:true,
        url:'sys.php?op=get_nav_blocks',
        valueField:'id',
        textField:'title'
        ">
        </select>
      </div>
      <div style="margin:5px">
        <label style="width:60px;display:inline-block;">提示 : </label>
        <input name="hint" type="text" class="easyui-textbox" style="width:230px">
        <input type="hidden" id="nav_link_op" value="">
        <input type="hidden" id="nav_link_id" value="">
      </div>
    </form>
  </div>
  <div id="nav_link_buttons" style="padding-right:15px;">
    <a href="#" id="clear_nav_link" class="easyui-linkbutton" iconCls="icon-clear" style="width:90px">重設</a>
    <a href="#" id="save_nav_link" class="easyui-linkbutton" iconCls="icon-ok" style="width:90px">確定</a>
  </div><br>
</div>
<script>
  $(function(){
    //導覽區塊 sys_nav_blocks
    $('#sys_nav_blocks').datagrid({
      columns:[[
        {field:'id',title:'id',sortable:true},
        {field:'title',title:'title',sortable:true},
        {field:'sequence',title:'sequence',align:'center',sortable:true},
        {field:'display',title:'display',sortable:true}
        ]],
      url:"sys.php",
      queryParams:{op:"list_nav_blocks"},
      fitColumns:true,
      singleSelect:true,
      rownumbers:true
      });
    $("#nav_block_sequence").numberspinner({
      min:0,
      max:99,
      increment:1,
      value:"0",
      required:true,
      missingMessage:'此欄位為必填'
      });
    $("#add_nav_block").bind("click",function(){
      $("#nav_block_dialog").dialog("open").dialog("setTitle","新增導覽區塊");
      $("#nav_block_form").form("clear");
      $("#nav_block_op").val("add_nav_block");
      });
    $("#edit_nav_block").bind("click",function(){
      var row=$("#sys_nav_blocks").datagrid("getSelected");
      if (row) {
        $("#nav_block_dialog").dialog("open").dialog("setTitle","編輯導覽區塊");
        $("#nav_block_form").form("load",row);
        }
      $("#nav_block_op").val("update_nav_block");
      $("#nav_block_id").val(row.id);
      });
    $("#clear_nav_block").bind("click",function(){
      $("#nav_block_form")[0].reset();
      });
    $("#save_nav_block").bind("click",function(){
      var op=$("#nav_block_op").val();
      var id=$("#nav_block_id").val();
      $("#nav_block_form").form("submit",{
        url:"sys.php",
        method:"post",
        queryParams:{op:op,id:id},
        success:function(data){
          var data=eval('(' + data + ')');
          $("#nav_block_dialog").dialog("close");
          if (data.status==="success") {
            $("#sys_nav_blocks").datagrid("reload",{op:"list_nav_blocks"});
            //window.location.href="main.php";
            }
          else {$.messager.alert("訊息",data.msg,"error");}          
          }
        });
      });
    $("#remove_nav_block").bind("click",function(){
      var row=$("#sys_nav_blocks").datagrid("getSelected");
      if (row) {
        $.messager.confirm("確認","確定要刪除這個導覽區塊嗎?",function(btn){
          if (btn){
            var params={op:"remove_nav_block",id:row.id};
            var callback=function(data){
              if (data.status==="success"){
                $("#sys_nav_blocks").datagrid("reload",{op:"list_nav_blocks"});
                $("#sys_nav_links").datagrid("reload",{op:"list_nav_links"});
                }
              else {$.messager.alert("訊息","刪除導覽區塊失敗!","error");}            
              };                
            $.post("sys.php",params,callback,"json");
            }
          })
        }
      });
    $("#reload_nav_blocks").bind("click",function(){
      $("#sys_nav_blocks").datagrid("load",{op:"list_nav_blocks"});
      });
    //導覽區連結 sys_nav_links
    $('#sys_nav_links').datagrid({
      columns:[[
        {field:'id',title:'id',sortable:true},
        {field:'title',title:'title',sortable:true},
        {field:'url',title:'url',sortable:true},
        {field:'target',title:'target',sortable:true},
        {field:'sequence',title:'sequence',align:'center',sortable:true},
        {field:'block_id',title:'block_id',sortable:true},
        {field:'hint',title:'hint',sortable:true}
        ]],
      url:"sys.php",
      queryParams:{op:"list_nav_links"},
      fitColumns:true,
      singleSelect:true,
      pagination:true,
      pageSize:10,
      rownumbers:true
      });
    $("#nav_link_sequence").numberspinner({
      min:0,
      max:99,
      increment:1,
      value:"0",
      required:true,
      missingMessage:'此欄位為必填'
      });
    $("#clear_nav_link").bind("click",function(){
      $("#nav_link_form")[0].reset();
      });
    $("#save_nav_link").bind("click",function(){
      var op=$("#nav_link_op").val();
      var id=$("#nav_link_id").val();
      $("#nav_link_form").form("submit",{
        url:"sys.php",
        method:"post",
        queryParams:{op:op,id:id},
        success:function(data){
          var data=eval('(' + data + ')');
          $("#nav_link_dialog").dialog("close");
          if (data.status==="success") {
            $("#sys_nav_links").datagrid("reload",{op:"list_nav_links"});
            //window.location.href="main.php";
            }
          else {$.messager.alert("訊息",data.msg,"error");}          
          }
        });
      });
    $("#add_nav_link").bind("click",function(){
      $("#nav_link_dialog").dialog("open").dialog("setTitle","新增連結");
      $("#nav_link_form").form("clear");
      $("#nav_link_op").val("add_nav_link");
      $("#block_id").combobox("reload", "sys.php?op=get_nav_blocks");
      });
    $("#edit_nav_link").bind("click",function(){
      var row=$("#sys_nav_links").datagrid("getSelected");
      if (row) {
        $("#nav_link_dialog").dialog("open").dialog("setTitle","編輯連結");
        $("#nav_link_form").form("load",row);
        }
      $("#nav_link_op").val("update_nav_link");
      $("#nav_link_id").val(row.id);
      });
    $("#remove_nav_link").bind("click",function(){
      var row=$("#sys_nav_links").datagrid("getSelected");
      if (row) {
        $.messager.confirm("確認","確定要刪除這個連結嗎?",function(btn){
          if (btn){
            var params={op:"remove_nav_link",id:row.id};
            var callback=function(data){
              if (data.status==="success"){
                $("#sys_nav_links").datagrid("reload",{op:"list_nav_links"});
                }
              else {$.messager.alert("訊息","刪除連結失敗!","error");}            
              };                
            $.post("sys.php",params,callback,"json");
            }
          })
        }
      });
    $("#reload_nav_links").bind("click",function(){
      $("#sys_nav_links").datagrid("load",{op:"list_nav_links"});
      });
    });
</script>
<?php
    break;
    }
  case "get_nav_blocks" : {
    $RS=search("sys_nav_blocks");
    $arr=Array();
    if (is_array($RS)){
      for ($i=0; $i<count($RS); $i++) {    
        $arr[$i]=Array("id" => $RS[$i]["id"],
                       "title" => $RS[$i]["title"]);   
        }
      }
    echo json_encode($arr);
    break;
    }
  case "list_nav_blocks" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $sort=isset($_REQUEST['sort']) ? $_REQUEST['sort'] : 'id';
    $order=isset($_REQUEST['order']) ? $_REQUEST['order'] : 'asc';
    if (isset($_REQUEST['search_field'])) { //有 search
      $where="WHERE ".$_REQUEST['search_field']." LIKE '%".
             $_REQUEST['search_what']."%'";
      }
    else {$where="";} //無 search
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    $SQL="SELECT COUNT(*) FROM `sys_nav_blocks`";
    $RS=run_sql($SQL);
    $total=$RS[0][0]; //紀錄總筆數
    $SQL="SELECT * FROM sys_nav_blocks ".$where." ORDER BY ".
         $sort." ".$order." LIMIT ".$start.",".$rows; 
    $RS=run_sql($SQL);
    $nav_blocks=Array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
        $nav_blocks[$i]=Array("id" => $RS[$i]["id"],
                              "title" => $RS[$i]["title"],
                              "sequence" => $RS[$i]["sequence"],
                              "display" => $RS[$i]["display"]
                              );
        }
      }
    $arr=array("total" => $total, "rows" => $nav_blocks);
    echo json_encode($arr);
    break;
    }
  case "add_nav_block" : {
    $data_array["title"]=$_REQUEST["title"];
    $sequence=empty($_REQUEST["sequence"])?0:$_REQUEST["sequence"];
    $data_array["sequence"]=$sequence;
    $display=empty($_REQUEST["display"])?"Y":$_REQUEST["display"];
    $data_array["display"]=$display;
    $result=insert("sys_nav_blocks", $data_array);
    if ($result===TRUE) {
      $status="success";
      $msg="ok";
      }
    else {
      $status="failure";
      $msg="資料新增錯誤!";
      }
    $arr["status"]=$status;
    $arr["msg"]=$msg;
    echo json_encode($arr);
    break;
    }
  case "update_nav_block" : {
    $id=$_REQUEST["id"];
    $data_array["title"]=$_REQUEST["title"];
    $data_array["sequence"]=$_REQUEST["sequence"];
    $data_array["display"]=$_REQUEST["display"];
    $result=update("sys_nav_blocks", $data_array, "id", $id);
    if ($result===TRUE) {
      $status="success";
      $msg="ok";
      }
    else {
      $status="failure";
      $msg="資料更新錯誤!";
      }
    $arr["status"]=$status;
    $arr["msg"]=$msg;
    echo json_encode($arr);
    break;
    }
  case "remove_nav_block" : {
    $id=$_REQUEST["id"];
    $result=delete_record("sys_nav_links", "block_id", $id);
    if ($result===TRUE) {$status="success";}
    else {$status="failure";}
    $result=delete_record("sys_nav_blocks", "id", $id);
    if ($result===TRUE) {$status="success";}
    else {$status="failure";}
    $arr["status"]=$status;
    echo json_encode($arr);
    break;
    }
  case "list_nav_links" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $sort=isset($_REQUEST['sort']) ? $_REQUEST['sort'] : 'id';
    $order=isset($_REQUEST['order']) ? $_REQUEST['order'] : 'asc';
    if (isset($_REQUEST['search_field'])) { //有 search
      $where="WHERE ".$_REQUEST['search_field']." LIKE '%".
             $_REQUEST['search_what']."%'";
      }
    else {$where="";} //無 search
    if (isset($_REQUEST['sort'])) {
      $orderby="ORDER BY ".$sort." ".$order;
      }
    else {$orderby="ORDER BY block_id,sequence";}
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    $SQL="SELECT COUNT(*) FROM `sys_nav_links`";
    $RS=run_sql($SQL);
    $total=$RS[0][0]; //紀錄總筆數
    $SQL="SELECT * FROM sys_nav_links ".$where." ".$orderby." ".
         "LIMIT ".$start.",".$rows; 
    $RS=run_sql($SQL);
    $nav_links=Array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
        $nav_links[$i]=Array("id" => $RS[$i]["id"],
                             "title" => $RS[$i]["title"],
                             "url" => $RS[$i]["url"],
                             "target" => $RS[$i]["target"],
                             "sequence" => $RS[$i]["sequence"],
                             "block_id" => $RS[$i]["block_id"],
                             "hint" => $RS[$i]["hint"]
                             );
        }
      }
    $arr=array("total" => $total, "rows" => $nav_links);
    echo json_encode($arr);
    break;
    }
  case "add_nav_link" : {
    $data_array["title"]=$_REQUEST["title"];
    $data_array["url"]=$_REQUEST["url"];
    $data_array["target"]=$_REQUEST["target"];
    $sequence=empty($_REQUEST["sequence"])?0:$_REQUEST["sequence"];
    $data_array["sequence"]=$sequence;
    $data_array["block_id"]=$_REQUEST["block_id"];
    $data_array["hint"]=$_REQUEST["hint"];
    $result=insert("sys_nav_links", $data_array);
    if ($result===TRUE) {
      $status="success";
      $msg="ok";
      }
    else {
      $status="failure";
      $msg="資料新增錯誤!";
      }
    $arr["status"]=$status;
    $arr["msg"]=$msg;
    echo json_encode($arr);
    break;
    }
  case "update_nav_link" : {
    $id=$_REQUEST["id"];
    $data_array["title"]=$_REQUEST["title"];
    $data_array["url"]=$_REQUEST["url"];
    $data_array["target"]=$_REQUEST["target"];
    $data_array["sequence"]=$_REQUEST["sequence"];
    $data_array["block_id"]=$_REQUEST["block_id"];
    $data_array["hint"]=$_REQUEST["hint"];
    $result=update("sys_nav_links", $data_array, "id", $id);
    if ($result===TRUE) {
      $status="success";
      $msg="ok";
      }
    else {
      $status="failure";
      $msg="資料更新錯誤!";
      }
    $arr["status"]=$status;
    $arr["msg"]=$msg;
    echo json_encode($arr);
    break;
    }
  case "remove_nav_link" : {
    $id=$_REQUEST["id"];
    $result=delete_record("sys_nav_links", "id", $id);
    if ($result===TRUE) {$status="success";}
    else {$status="failure";}
    $arr["status"]=$status;
    echo json_encode($arr);
    break;
    }
  case "visitors" : {
?>
<div class="tab" title="到訪者">
  <!--到訪者列表-->
  <table id="sys_visitors" title="到訪者列表" style="width:auto" data-options="tools:'#sys_visitors_tools',toolbar:'#sys_visitors_search_bar'"></table>
  <div id="sys_visitors_tools">
    <a href="#" id="remove_visitor" class="icon-remove" title="刪除"></a>
    <a href="#" id="reload_visitors" class="icon-reload" title="重新載入"></a>
  </div>
  <div id="sys_visitors_search_bar" style="text-align:right;padding:2px;">
    <select id="visitors_search_field" class="easyui-combobox" data-options="panelHeight:45">
      <option value="visit_time">到訪時間</option>
      <option value="remote_addr">遠端位址</option>
    </select>
    <input id="visitors_search_what" class="easyui-textbox">
  </div>
</div>
<script>
  $(function(){
    //到訪者 sys_visitors
    $('#sys_visitors').datagrid({
      columns:[[
        {field:'id',title:'id',sortable:true},
        {field:'visit_time',title:'到訪時間',sortable:true},
        {field:'remote_addr',title:'遠端位址',sortable:true},
        {field:'remote_port',title:'遠端埠號',align:'right',sortable:true},
        {field:'user_agent',title:'使用者代理',sortable:true}
        ]],
      url:"sys.php",
      queryParams:{op:"list_visitors"},
      fitColumns:true,
      singleSelect:true,
      pagination:true,
      pageSize:10,
      rownumbers:true
      });
    $("#visitors_search_what").textbox({
      icons:[{
        iconCls:"icon-search",
        handler:function(e){
          $('#sys_visitors').datagrid("load",{
            op:"list_visitors",
            search_field:$("#visitors_search_field").combobox("getValue"),
            search_what:$("#visitors_search_what").textbox("getValue")
            });          
          }
        }]
      });
    $("#reload_visitors").bind("click",function(){
      $("#sys_visitors").datagrid("load",{op:"list_visitors"});
      });
    $("#remove_visitor").bind("click",function(){
      var row=$("#sys_visitors").datagrid("getSelected");
      if (row) {
        $.messager.confirm("確認","確定要刪除這筆到訪紀錄嗎?",function(btn){
          if (btn){
            var params={op:"remove_visitors",id:row.id};
            var callback=function(data){
              if (data.status==="success"){
                $("#sys_visitors").datagrid("reload",{op:"list_visitors"});
                }
              else {$.messager.alert("訊息","刪除到訪紀錄失敗!","error");}            
              };                
            $.post("sys.php",params,callback,"json");
            }
          })
        }
      });
    });
<?php
    break;
    }
  case "list_visitors" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $sort=isset($_REQUEST['sort']) ? $_REQUEST['sort'] : 'visit_time';
    $order=isset($_REQUEST['order']) ? $_REQUEST['order'] : 'desc';
    if (isset($_REQUEST['search_field'])) { //有 search
      $where="WHERE ".$_REQUEST['search_field']." LIKE '%".
             $_REQUEST['search_what']."%'";
      }
    else {$where="";} //無 search
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    $SQL="SELECT COUNT(*) FROM `sys_visitors`";
    $RS=run_sql($SQL);
    $total=$RS[0][0]; //紀錄總筆數
    $SQL="SELECT * FROM sys_visitors ".$where." ORDER BY ".
         $sort." ".$order." LIMIT ".$start.",".$rows; 
    $RS=run_sql($SQL);
    $visitors=Array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
        $visitors[$i]=Array("id" => $RS[$i]["id"],
                            "visit_time" => $RS[$i]["visit_time"],
                            "remote_addr" => $RS[$i]["remote_addr"],
                            "remote_port" => $RS[$i]["remote_port"],
                            "user_agent" => $RS[$i]["user_agent"]
                            );
        }
      }
    $arr=array("total" => $total, "rows" => $visitors);
    echo json_encode($arr);
    break;
    }
  case "remove_visitors" : {
    $id=$_REQUEST["id"];
    $result=delete_record("sys_visitors", "id", $id);
    if ($result===TRUE) {$status="success";}
    else {$status="failure";}
    $arr["status"]=$status;
    echo json_encode($arr);
    break;
    }
  case "apps" : {
?>
<div class="tab" title="應用程式">
  <!--應用程式 sys_apps 列表-->
  <table id="sys_apps" title="應用程式列表" style="width:auto" data-options="tools:'#apps_tools',toolbar:'#apps_toolbar'"></table>
  <div id="apps_tools"> 
    <a href="#" id="reload_apps" class="icon-reload" title="重新載入"></a>
  </div>
  <div id="apps_toolbar" style="text-align:right;padding:2px;">
    <a href="#" id="upload_app" class="easyui-linkbutton" data-options="iconCls:'icon-add'">上傳</a>
    <a href="#" id="install_app" class="easyui-linkbutton" data-options="iconCls:'icon-ok'">安裝</a>
    <a href="#" id="remove_app" class="easyui-linkbutton" data-options="iconCls:'icon-remove'">移除</a>
  </div>   
  <!--上傳應用程式表單對話框-->
  <div id="upload_app_dialog" class="easyui-dialog" title="上傳應用程式" style="width:420px;height:200px;"  data-options="closed:'true',buttons:'#upload_app_buttons'">
    <form id="upload_app_form" style="padding:15px" method="post" enctype="multipart/form-data" target="upload_target">
      <div style="margin:10px">
        <label style="width:60px;display:inline-block;">主檔案 : </label>
        <input name="uploader[]" id="main" class="easyui-filebox"  data-options="missingMessage:'此欄位為必填',required:true,buttonText:'選擇主檔案',prompt:'app.php'" style="width:270px">
      </div>
      <div style="margin:10px">
        <label style="width:60px;display:inline-block;">安裝檔 : </label>
        <input name="uploader[]" id="install" class="easyui-filebox"  data-options="missingMessage:'此欄位為必填',required:true,buttonText:'選擇安裝檔',prompt:'app_install.php'" style="width:270px">
      </div>
      <div>
        <iframe id="upload_target" name="upload_target" src="#"           style="width:0;height:0;border:0px solid #ffffff;">
        </iframe>
      </div>
    </form>
  </div>
  <div id="upload_app_buttons" style="padding-right:15px;">
    <a href="#" id="clear_app" class="easyui-linkbutton" iconCls="icon-clear" style="width:90px">重設</a>
    <a href="#" id="upload_app_go" class="easyui-linkbutton" iconCls="icon-ok" style="width:90px">上傳</a>
  </div>
</div> 
<script>
  $(function(){
    //應用程式 sys_apps
    $('#sys_apps').datagrid({
      columns:[[
        {field:'id',title:'id',sortable:true},
        {field:'app_name',title:'名稱',sortable:true},
        {field:'installed',title:'已安裝',sortable:true},
        {field:'show_tabs',title:'顯示頁籤',sortable:true},
        {field:'tab_names',title:'頁籤名稱',sortable:true},
        {field:'table_names',title:'資料表名稱',sortable:true},
        {field:'remark',title:'備註',sortable:true}
        ]],
      url:"sys.php",
      queryParams:{op:"list_apps"},
      fitColumns:true,
      singleSelect:true,
      pagination:true,
      pageSize:10,
      rownumbers:true
      });
    $("#clear_app").bind("click",function(){
      $("#upload_app_form")[0].reset();
      });
    $("#upload_app_go").bind("click",function(){
      var main=$("#main").filebox("getText");
      main=main.substr(main.lastIndexOf("\\") + 1, main.length);
      var app_main=main.split(".")[0]; //主檔名
      var install=$("#install").filebox("getText");
      install=install.substr(install.lastIndexOf("\\") + 1, install.length);
      var install_main=install.split("_")[0]; //安裝主檔名
      var reg=/.php$/i; //副檔名均為 .php
      if (!reg.test(main) || !reg.test(install)) {
        var msg="主程式與其安裝檔必須均為 .php 檔!<br> 請重新選取.";
        $.messager.alert("訊息",msg,"error");
        return;
        } 
      reg=/_install.php$/i; //過濾出安裝檔
      if (!reg.test(install)) {
        var msg="安裝檔檔名格式不正確!<br>格式 : APP_install.php<br>";
        $.messager.alert("訊息",msg,"error");
        return;      
        }      
      if (app_main != install_main) { //主檔名不同
        msg="此兩檔案並非同一組應用程式! <br>" +
            "主程式與其安裝檔之檔名格式 : " +
            "APP.php 與 APP_install.php<br>請重新選取.<br>"; 
        $.messager.alert("訊息",msg,"error");
        return;  
        } //end of if
      reg=/\W/g; //非英數字與底線
      if (reg.test(app_main) || reg.test(install_main)) {
        var msg="應用程式及其安裝檔檔名必須均為英數字或底線!<br>" +
                "請重新選取.<br>"; ;
        $.messager.alert("訊息",msg,"error");
        return;      
        } 
      $("#upload_app_form").form("submit",{
        url:"sys.php?op=upload_app&app_main=" + app_main
        });
      });
    $("#upload_app").bind("click",function(){
      $("#upload_app_dialog").dialog("open").dialog("setTitle","上傳應用程式");
      $("#upload_app_form").form("clear");
      });
    $("#reload_apps").bind("click",function(){
      $("#sys_apps").datagrid("load",{op:"list_apps"});
      });
    $("#install_app").bind("click",function(){
      var row=$("#sys_apps").datagrid("getSelected");
      if (row) {
        if (row.installed=="N") {
          var url="apps/" + row.app_name + "_install.php";
          $.ajax({
            type:"POST",
            url:url,
            cache:false,
            dataType:"json",
            success:function(data) {
              $("#sys_apps").datagrid("reload",{op:"list_apps"});
              if (data.result=="success") {
                $.messager.alert("訊息","應用程式安裝成功!","info"); 
                }
              else {$.messager.alert("訊息",data.error,"error");}                
              },
            error:function(xhr, thrownError) { 
              var msg='<p>應用程式安裝失敗!<br>狀態 : ' +
                      xhr.status + " - " + thrownError + '</p>';
              $.messager.alert("訊息",msg,"error");                        
              }
            }); 
          }
        else {$.messager.alert("訊息","此應用程式已安裝過了!","warning");}
        }
      else {$.messager.alert("訊息","請選擇要安裝的應用程式!","info");}
      });
    $("#remove_app").bind("click",function(){
      var row=$("#sys_apps").datagrid("getSelected");
      if (row) {
        $.messager.confirm("確認","確定要刪除這個應用程式嗎?",function(btn){
          if (btn){
            var params={op:"remove_app",id:row.id};
            var callback=function(data){
              if (data.status==="success"){
                $("#sys_apps").datagrid("reload",{op:"list_apps"});
                }
              else {$.messager.alert("訊息",data.msg,"error");}            
              };                
            $.post("sys.php",params,callback,"json");
            }
          })
        }
      else {$.messager.alert("訊息","請選擇要刪除的應用程式!","info");}
      });
    }); //end of jQuery
</script>
<?php
    break;
    }
  case "list_apps" : {
    $page=isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
    $rows=isset($_REQUEST['rows']) ? intval($_REQUEST['rows']) : 10;
    $sort=isset($_REQUEST['sort']) ? $_REQUEST['sort'] : 'id';
    $order=isset($_REQUEST['order']) ? $_REQUEST['order'] : 'asc';
    if (isset($_REQUEST['search_field'])) { //有 search
      $where="WHERE ".$_REQUEST['search_field']." LIKE '%".
             $_REQUEST['search_what']."%'";
      }
    else {$where="";} //無 search
    $start=($page-1) * $rows;  //本頁第一個列索引 (0 起始)
    $SQL="SELECT COUNT(*) FROM `sys_apps`";
    $RS=run_sql($SQL);
    $total=$RS[0][0]; //紀錄總筆數
    $SQL="SELECT * FROM sys_apps ".$where." ORDER BY ".
         $sort." ".$order." LIMIT ".$start.",".$rows; 
    $RS=run_sql($SQL);
    $apps=Array();
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
        $apps[$i]=Array("id" => $RS[$i]["id"],
                        "app_name" => $RS[$i]["app_name"],
                        "installed" => $RS[$i]["installed"],
                        "show_tabs" => $RS[$i]["show_tabs"],
                        "tab_names" => $RS[$i]["tab_names"],
                        "table_names" => $RS[$i]["table_names"],
                        "remark" => $RS[$i]["remark"]
                        );
        }
      }
    $arr=array("total" => $total, "rows" => $apps);
    echo json_encode($arr);
    break;
    }
  case "upload_app" : { //ajax:處理 app 檔案上傳用
    $status="success";       //預設上傳成功
    $msg="";                 //執行結果字串
    $upload_dir="./apps/";   //設定上傳目錄
    $result=upload_files("uploader", $upload_dir);
    if (is_array($result)) { //成功傳回陣列
      for ($i=0; $i<count($result); $i++) {
        $msg .= $result[$i]["name"]." 上傳成功(".$result[$i]["size"].
                " bytes)<br>";
        }
      //登錄於 sys_apps 資料表
      $data_array["app_name"]=$_REQUEST["app_main"];
      $data_array["installed"]="N";
      $data_array["show_tabs"]="N";    //安裝時更新
      $data_array["tab_names"]="";     //安裝時填入
      $data_array["table_names"]="";   //安裝時填入
      $data_array["remark"]="";        //安裝時更新
      $result=insert("sys_apps", $data_array);
      }
    else { //上傳失敗
      $msg .= "檔案上傳失敗 : <br>".$result;
      $status="failure";
      } //end of else
    $para='"'.$status.'","'.$msg.'"'; //回傳回呼函式之參數
?>
<!-- 輸出 script 到 $op=apps 中的 iframe 並執行其中的回呼函式 -->
<script language="javascript" type="text/javascript">
  window.top.window.upload_app_callback(<?php echo $para; ?>);
</script>
<?php
    break;
    }
  case "remove_app" : {
    $id=$_REQUEST["id"];
    $RS=search("sys_apps","id",$id);
    $status="success";
    $msg="";
    if (is_array($RS)) { //有登錄
      //刪除此 app 所有資料表
      $app_name=$RS[0]["app_name"];
      $installed=$RS[0]["installed"];
      if ($installed=="Y") { //已安裝
        $tables=explode(",",$RS[0]["table_names"]);
        for ($i=0; $i<count($tables); $i++) {
          $result=drop_table($tables[$i]);
          if ($result===FALSE) {
            $status="failure";
            $msg .= "刪除資料表 ".$tables[$i]." 失敗<br>";
            } 
          }
        //從 sys_header_links 刪除此 app 超連結
        $result=delete_record("sys_header_links","title",$app_name);
        if ($result===FALSE) {
          $status="failure";
          $msg .= "刪除應用程式在 sys_header_links 之超連結失敗<br>";
          } 
        //從 sys_nav_links 刪除此 app 所建立之超連結
        $result=delete_record("sys_nav_links","app",$app_name);
        if ($result===FALSE) {
          $status="failure";
          $msg .= "刪除應用程式在 sys_nav_links 之超連結失敗<br>";
          } 
        //從 sys_nav_blocks 刪除此 app 所建立之超連結
        $result=delete_record("sys_nav_blocks","app",$app_name);
        if ($result===FALSE) {
          $status="failure";
          $msg .= "刪除應用程式在 sys_nav_blocks 之超連結失敗<br>";
          } 
        } //installed
      //從 sys_apps 刪除此 app 登錄
      $result=delete_record("sys_apps","id",$id);
      if ($result===FALSE) {
        $status="failure";
        $msg .= "刪除應用程式在 sys_apps 之登錄失敗<br>";
        } 
      //刪除應用程式檔案
      $result=delete_file("./apps/".$app_name.".php");
      if ($result==FALSE) {
        $status="failure";
        $msg .= $app_name.".php 刪除失敗<br>";
        }
      $result=delete_file("./apps/".$app_name."_install.php");
      if ($result==FALSE) {
        $status="failure";
        $msg .= $app_name."_install.php 刪除失敗<br>";
        }
      } //registered
    else { //未上傳登錄
      $status="failure";
      $msg="刪除失敗 : 應用程式不存在!";
      }
    $arr["status"]=$status;
    $arr["msg"]=$msg;
    echo json_encode($arr);
    break;
    }
  default : { 
?>
<div id="sys_tabs" class="easyui-tabs" data-options="fit:'true'">
<?php
    $SQL="SELECT * FROM sys_tabs"; //預設為管理員
    if ($_SESSION["user_level"] != 9) {$SQL .= " WHERE tab_level < 9";}
    $RS=run_sql($SQL);  
    if (is_array($RS)) {
      for ($i=0; $i<count($RS); $i++) {
?>
  <div class="tab" title="<?php echo $RS[$i]["tab_label"] ?>" data-options="href:'<?php echo $RS[$i]["tab_link"] ?>',loadingMessage:'載入中 ... '">
  </div>
<?php
        } //for
      } //if
?>
</div>
<?php
    } //default
  } //switch
?>