<?php
/*-----------------------------------------------------------------------------
Title        : Statistics
Translator   : Tony
Version      : v1.0.0
Prototype    : 2013/08/03
Last Updated : 2013/08/04
Usage        : PHP 統計函式庫
Reference    :
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
get_regression($X, $Y)
功能 : 
  傳入兩個陣列數據 $X, $Y, 傳回其線性迴歸方程式 Y=a+bX 中的常數 a 與斜率 b.
參數 :                                   
  $X : 數據陣列 X
  $Y : 數據陣列 Y
傳回值 :
  成功 : 傳回關聯式陣列 $reg["a"] 與 $reg["b"]
  失敗 : 傳回 FALSE
範例 : 
  $X=Array(25,23,27,35,30);
  $Y=Array(35,27,36,45,42);
  $reg=get_regression($X, $Y);
  echo "線性迴歸方程式 : Y=".$reg["a"]."+".$reg["b"]."X"; //Y=-2.2+1.4X
-----------------------------------------------------------------------------*/
function get_regression($X, $Y) { 
  if ((count($X) != count($Y)) || count($X)==0 || count($Y)==0) { //錯誤情況
      return FALSE; //兩陣列元素個數不相等, 或陣列元素個數為0
      } //end of if
  else { //可計算   
      $xavg=array_sum($X)/count($X); //X 平均值
      $yavg=array_sum($Y)/count($Y); //Y 平均值
      $XMD=Array();         //X 離均差
      $YMD=Array();         //Y 離均差
      $mdcross_sum=0;       //X,Y 離均差交乘積和
      $xdif_square_sum=0;   //X 離均差平方和
      $count=count($X);
      for ($i=0; $i<count($X); $i++) { 
           $xdif=(float)$X[$i]-$xavg; //X 離均差
           $ydif=(float)$Y[$i]-$yavg; //Y 離均差
           $XMD[$i]=$xdif;
           $YMD[$i]=$ydif;
           $mdcross_sum += $xdif*$ydif;       //X,Y 離均差交乘積和
           $xdif_square_sum += pow($xdif, 2); //X 離均差平方和
           } //end of for
      if ($xdif_square_sum==0) {return FALSE;} //分母為 0
      else { //分母不為 0
          $b=round($mdcross_sum/$xdif_square_sum, 2);  //計算斜率 b
          $a=round($yavg-$b*$xavg,2);                  //計算常數項 a
          $reg=Array("a" => $a,"b" => $b);             //關聯式陣列
          return $reg;
          } //end of else
      } //end of else
  }
/*-----------------------------------------------------------------------------
get_correlation($X, $Y)
功能 : 
  傳入兩個元素個數相同之陣列數據 $X, $Y, 傳回其相關係數.
參數 :                           
  $X : 數據陣列 X
  $Y : 數據陣列 Y 
傳回值 :
  成功 : 傳回相關係數 (浮點數)
  失敗 : 傳回 FALSE
範例 : 
  $X=Array(25,23,27,35,30);
  $Y=Array(35,27,36,45,42);
  $cor=get_correlation($X, $Y);
  echo "相關係數=".$cor; //0.94
-----------------------------------------------------------------------------*/
function get_correlation($X, $Y) {
  if ((count($X)!=count($Y)) || count($X)==0 || count($Y)==0) { //錯誤情況
      return FALSE; //兩陣列元素個數不相等, 或陣列元素個數為0
      } //end of if
  else { //可計算   
      $xavg=array_sum($X)/count($X); //X 平均值
      $yavg=array_sum($Y)/count($Y); //Y 平均值
      $xsum=array_sum($X);           //X 總和
      $ysum=array_sum($Y);           //Y 總和
      $x_square_sum=0;               //X 平方和累計
      $y_square_sum=0;               //Y 平方和累計
      $XMD=Array();                  //X 離均差
      $YMD=Array();                  //Y 離均差
      $mdcross_sum=0;                //X,Y 離均差交乘積和
      $count=count($X);              //元素個數
      for ($i=0; $i<count($X); $i++) { 
           $xdif=(float)$X[$i]-$xavg; //X 離均差
           $ydif=(float)$Y[$i]-$yavg; //Y 離均差
           $XMD[$i]=$xdif;
           $YMD[$i]=$ydif;
           $mdcross_sum += $xdif*$ydif;       //X,Y 離均差交乘積和
           $xdif_square_sum += pow($xdif, 2); //X 離均差平方和
           $x_square_sum += pow($X[$i], 2);   //X 平方和累計
           $y_square_sum += pow($Y[$i], 2);   //Y 平方和累計
           } //end of for
      //計算樣本標準差 & 乘積
      $xstd=sqrt(($x_square_sum-pow($xsum,2)/$count)/($count-1)); 
      $ystd=sqrt(($y_square_sum-pow($ysum,2)/$count)/($count-1)); 

      //$xstd=sqrt(($x_square_sum-pow($xsum,2)/$count)/($count)); 
      //$ystd=sqrt(($y_square_sum-pow($ysum,2)/$count)/($count)); 
      $xystd=$xstd*$ystd; //兩標準差乘積
      //計算共變異數
      $covar=$mdcross_sum/($count-1);
      echo "";
      //計算相關係數
      if ($xystd==0) {return FALSE;} //分母為 0
      else { //分母不為 0
          $corr=$covar/$xystd;
          return $corr;
          } //end of else
      } //end of else
  }
